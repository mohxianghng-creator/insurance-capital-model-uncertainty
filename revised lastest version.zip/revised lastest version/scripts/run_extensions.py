"""Norwegian influence diagnostics and constrained finite-layer decisions."""
import json
import hashlib
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
import numpy as np
import pandas as pd
from cmu import data, data_norfire as N, aggregate as A, frequency as F, severity as S
from cmu import decision as D, validation as V, research as R, reinsurance as RI


def norwegian(out):
    df = N.load_norfire()
    rows = []
    with R.grid_context(.5, 2**17, 2**19):
        for origin in range(1988, 1992):
            train = df[df.year <= origin]
            test = df[df.year == origin + 1]
            all_counts = V.annual_counts(train, range(1985, origin + 1))
            for scenario in ('full_history', 'remove_largest', 'remove_largest_three',
                             'recent_severity_three_years', 'recent_frequency_three_years'):
                xs = train.loss.to_numpy()
                counts = all_counts
                if scenario == 'remove_largest':
                    xs = np.sort(xs)[:-1]
                elif scenario == 'remove_largest_three':
                    xs = np.sort(xs)[:-3]
                elif scenario == 'recent_severity_three_years':
                    xs = train[train.year >= origin-2].loss.to_numpy()
                elif scenario == 'recent_frequency_three_years':
                    counts = all_counts[-3:]
                fits = [m.fit(xs) for m in S.default_model_set()]
                aics = [m.aic(xs) for m in fits]
                best = fits[int(np.argmin(aics))].name
                for m in fits:
                    for fname in F.FREQ_NAMES:
                        f = F.make(fname).fit(counts)
                        d = A.aggregate(m.cdf, f.forecast(1), r=f.r)
                        rows.append(dict(origin=origin, test_year=origin+1, scenario=scenario,
                                         severity=m.name, freq=fname, selected_model=best,
                                         n_train=len(xs), max_train=float(xs.max()),
                                         lam=f.forecast(1), V995=d.var(.995), mean_S=d.mean_S,
                                         realised_S=float(test.loss.sum()),
                                         pit_S=float(d.cdf_at(test.loss.sum())),
                                         xi=getattr(m, 'xi', np.nan)))
    pd.DataFrame(rows).to_csv(out / 'norwegian_diagnostics.csv', index=False)
    print('Norwegian influence diagnostics complete', flush=True)


def treaties(out):
    df = data.load_danish()
    x = df.loss.to_numpy()
    counts = V.annual_counts(df, range(1980, 1991))
    fits = [m.fit(x) for m in S.default_model_set()]
    keep = D.plausible_mask([m.aic(x) for m in fits])
    risk = [m for m, k in zip(fits, keep) if k]
    pricing = {m.name: m for m in fits if m.name in ('Spliced10', 'Spliced5')}
    actions = [('none', None, None), ('50_xs_50', 50, 50), ('100_xs_50', 50, 100),
               ('50_xs_20', 20, 50), ('100_xs_20', 20, 100), ('20_xs_10', 10, 20),
               ('250_xs_50', 50, 250), ('500_xs_20', 20, 500)]
    lam_quote = float(np.mean(counts))
    raw = []
    for model in risk:
        for fname in F.FREQ_NAMES:
            f = F.make(fname).fit(counts)
            for action, retention, limit in actions:
                net = model if retention is None else RI.LayerRetained(model, retention, limit)
                d = A.aggregate(net.cdf, f.forecast(1), r=f.r)
                recovery = 0 if retention is None else f.forecast(1) * RI.layer_recovery(model, retention, limit)
                for pn, pm in pricing.items():
                    expected_quote = 0 if retention is None else lam_quote * RI.layer_recovery(pm, retention, limit)
                    for loading in (.1, .3, .5):
                        premium = (1 + loading) * expected_quote
                        for rate in (.03, .06, .12):
                            raw.append(dict(severity=model.name, freq=fname, action=action,
                                            retention=retention, limit=limit, pricing_model=pn,
                                            loading=loading, funding_rate=rate, V995=d.var(.995),
                                            EL=d.mean_S, K_econ=d.var(.995)-d.mean_S,
                                            premium=premium, expected_recovery=recovery,
                                            upfront_resource=d.var(.995)+premium,
                                            annual_cost=rate*(d.var(.995)-d.mean_S)+premium-recovery))
    raw = pd.DataFrame(raw)
    raw.to_csv(out / 'finite_treaty_costs.csv', index=False)
    summaries = []
    for (pn, loading, rate), g in raw.groupby(['pricing_model', 'loading', 'funding_rate']):
        for budget in (1250., 1750., 2500.):
            # An action is feasible only if every risk view can fund its net VaR
            # plus the up-front premium. State-specific or clairvoyant actions
            # must not be used to satisfy this robust capital constraint.
            feasibility = g.groupby('action').upfront_resource.max() <= budget
            admissible = list(feasibility[feasibility].index)
            eligible = g[g.action.isin(admissible)].copy()
            if eligible.empty:
                summaries.append(dict(pricing_model=pn, loading=loading, funding_rate=rate,
                                      resource_budget=budget, selected_action='NO_FEASIBLE_ACTION',
                                      feasible_actions=0, worst_regret=np.nan, worst_annual_cost=np.nan))
                continue
            best_by_view = eligible.groupby(['severity', 'freq']).annual_cost.transform('min')
            eligible['regret'] = eligible.annual_cost - best_by_view
            score = eligible.groupby('action').agg(worst_regret=('regret', 'max'),
                         worst_annual_cost=('annual_cost', 'max'),
                         max_upfront_resource=('upfront_resource', 'max')).reset_index()
            winner = score.sort_values(['worst_regret', 'worst_annual_cost', 'action']).iloc[0]
            summaries.append(dict(pricing_model=pn, loading=loading, funding_rate=rate,
                                  resource_budget=budget, selected_action=winner.action,
                                  feasible_actions=len(admissible), worst_regret=winner.worst_regret,
                                  worst_annual_cost=winner.worst_annual_cost,
                                  max_upfront_resource=winner.max_upfront_resource))
    pd.DataFrame(summaries).to_csv(out / 'finite_treaty_decisions.csv', index=False)
    boundaries = []
    for (pn, action), g in raw[(raw.loading == .3) & (raw.funding_rate == .06)].groupby(['pricing_model','action']):
        if action == 'none':
            continue
        quote = float((g.premium/1.3).iloc[0])
        none = raw[(raw.pricing_model == pn)&(raw.action == 'none')&
                   (raw.loading == .3)&(raw.funding_rate == .06)][['severity','freq','K_econ']]
        comparison = g.merge(none, on=['severity','freq'], suffixes=('', '_none'), validate='one_to_one')
        cost_loading = ((.06*(comparison.K_econ_none-comparison.K_econ)+comparison.expected_recovery)/quote-1).min()
        for budget in (1250., 1750., 2500.):
            boundaries.append(dict(pricing_model=pn, action=action, resource_budget=budget,
                max_loading_feasible_all_views=(budget-g.V995.max())/quote-1,
                max_loading_cost_no_greater_than_none_all_views=cost_loading))
    pd.DataFrame(boundaries).to_csv(out / 'finite_treaty_boundaries.csv', index=False)
    print('Finite-layer constrained decisions complete', flush=True)


def stress_boundaries(out):
    """Check achieved strict exceedance probabilities at saved lattice boundaries."""
    df = data.load_danish()
    x = df.loss.to_numpy()
    counts = V.annual_counts(df, range(1980,1991))
    fits = {m.name:m.fit(x) for m in S.default_model_set()}
    saved = pd.read_csv(ROOT/'results/E4_reverse_stress.csv')
    rows = []
    for row in saved.itertuples():
        m = fits[row.severity]
        f = F.make(row.freq).fit(counts)
        for tag,target in [('p05',.05),('p50',.5)]:
            for kind in ('phi','s','dxi'):
                z = getattr(row,f'{kind}_star_{tag}')
                if np.isnan(z):
                    continue
                if not np.isfinite(z):
                    rows.append(dict(severity=row.severity,freq=row.freq,kind=kind,target=target,
                        stress=z,achieved_strict_breach=np.nan,preceding_cell_breach=np.nan,
                        lattice_atom=np.nan,target_gap=np.nan,already_at_lower_bound=False,
                        status='unreached_in_search_range'))
                    continue
                shifted = m.with_tail_shift(z) if kind == 'dxi' else m
                d = A.aggregate(shifted.cdf,f.forecast(1)*(z if kind == 'phi' else 1),
                                scale=z if kind == 's' else 1,r=f.r)
                achieved = d.breach_prob(row.K0)
                previous_cell = d.breach_prob(row.K0-A.H)
                at_lower_bound = z <= (1e-8 if kind == 'dxi' else 1+1e-8)
                rows.append(dict(severity=row.severity,freq=row.freq,kind=kind,target=target,
                                 stress=z,achieved_strict_breach=achieved,
                                 preceding_cell_breach=previous_cell,
                                 lattice_atom=previous_cell-achieved,
                                 target_gap=achieved-target,
                                 already_at_lower_bound=at_lower_bound,
                                 status='already_at_lower_bound' if at_lower_bound else 'resolved'))
    pd.DataFrame(rows).to_csv(out/'stress_target_diagnostics.csv',index=False)
    print('Reverse-stress strict-exceedance diagnostics complete',flush=True)


def main():
    out = ROOT / 'results/current'
    out.mkdir(exist_ok=True)
    norwegian(out)
    treaties(out)
    stress_boundaries(out)
    (out / 'extensions_metadata.json').write_text(json.dumps(dict(
        scope='Illustrative assumptions; no actual insurance quotation or real capital budget',
        treaty='per-occurrence finite limit, no aggregate limit or reinstatement; full recoverability assumed',
        decision='minimax regret over commonly feasible actions; fixed quote across all nine risk views',
        budget='net loss VaR99.5 plus premium paid upfront; expected retained loss is included in VaR',
        diagnostics='claim deletion and recent-window refits are sensitivity experiments, not causal estimates'), indent=2))
    metadata = json.loads((out/'extensions_metadata.json').read_text())
    metadata['source_sha256'] = {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in
        ['scripts/run_extensions.py','src/cmu/reinsurance.py','data/raw/danish.rda','data/raw/norfire.rda']}
    (out/'extensions_metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
