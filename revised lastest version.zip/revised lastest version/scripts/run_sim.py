"""Simulation study runner (SYNTHETIC data). usage: run_sim.py R T out.csv [world ...]  (resumable, seeded per world/rep)."""
import sys, time, os
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "src"))
import numpy as np, pandas as pd
from cmu import data, severity as S, simulation as SIM
from cmu.config import *

R, T, out = int(sys.argv[1]), int(sys.argv[2]), ROOT / "results" / sys.argv[3]
from simulation_run_metadata import guard
guard(out, ROOT, T=T, B=30, seed=SEED, kind='bootstrap')
want = sys.argv[4:]
x = data.load_danish().loss.to_numpy()
real = {}
for m in S.default_model_set():
    real[m.name] = m.fit(x)
worlds = SIM.make_worlds(real)
done = set()
if out.exists():
    old = pd.read_csv(out)
    if old.duplicated(['world', 'rep', 'rule']).any() or not old.groupby(['world', 'rep']).size().eq(
            old.groupby(['world', 'rep']).world.first().map(lambda w: 10 if w.startswith('W4_') else 11)).all():
        raise ValueError('duplicate or incomplete simulation replications; do not append to this file')
    done = set(zip(old.world, old.rep))
rows = []
t0 = time.time()
for wi, (wname, w) in enumerate(worlds.items()):
    if want and wname not in want:
        continue
    d_true, v_true = SIM.truth_summary(w)
    for rep in range(R):
        if (wname, rep) in done:
            continue
        rng = np.random.default_rng(np.random.SeedSequence([SEED, wi, T, rep]))
        counts = rng.poisson(w["lam"], T)
        xs = SIM.draw_claims(w["truth"], counts.sum(), rng)
        res = SIM.decide(xs, counts, rng, B=30, oracle=w["oracle"])
        for rule, v in res.items():
            if rule.startswith("_"):
                continue
            sc = SIM.score(v, d_true, v_true)
            rows.append(dict(world=wname, T=T, rep=rep, rule=rule, V=v, V_true=v_true, n_plausible=res["_n_plausible"],
                             best_model=res["_best"], **sc))
        if len(rows) >= 200 or rep == R - 1:
            pd.DataFrame(rows).to_csv(out, mode="a", header=not out.exists(), index=False); rows = []
            print(wname, rep, f"{time.time()-t0:.0f}s", flush=True)
if rows:
    pd.DataFrame(rows).to_csv(out, mode="a", header=not out.exists(), index=False)
print("done", time.time() - t0)
