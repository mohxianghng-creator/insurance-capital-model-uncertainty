"""Summarise fresh validation; uncertainty intervals describe Monte Carlo error."""
from pathlib import Path
import json
import re
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
import numpy as np
import pandas as pd
from cmu.research import wilson


def summaries(out):
    d = pd.read_csv(out / 'decision_raw.csv')
    if d.duplicated(['world', 'T', 'rep', 'rule']).any():
        raise ValueError('duplicate decision keys')
    rows, paired = [], []
    rng = np.random.default_rng(2030)
    for (world, T, rule), g in d.groupby(['world', 'T', 'rule']):
        n = len(g)
        lo, hi = wilson(int(g.shortfall.sum()), n)
        r = dict(world=world, T=T, rule=rule, n=n, p_shortfall=g.shortfall.mean(),
                 shortfall_ci_lo=lo, shortfall_ci_hi=hi, capped_share=g.capped.mean(),
                 expanded_share=g.expanded.mean(), median_capital_ratio=np.median(g.V / g.V_true),
                 max_refinement_change=g.refinement_change.max())
        for ratio in (1, 3, 10):
            loss = ratio*g.rel_under + g.rel_over
            upper = ratio*g.rel_under + g.rel_over_upper
            r[f'loss_r{ratio}'] = loss.mean()
            r[f'loss_r{ratio}_upper'] = upper.mean()
            r[f'loss_r{ratio}_empirical_mcse'] = loss.std(ddof=1)/np.sqrt(n) if not g.capped.any() else np.nan
        rows.append(r)
    summary = pd.DataFrame(rows)
    summary.to_csv(out / 'decision_summary.csv', index=False)
    for (world, T), g in d.groupby(['world', 'T']):
        base = g[g.rule == 'D0_aic_plugin'].set_index('rep')
        for rule, gg in g.groupby('rule'):
            if rule == 'D0_aic_plugin':
                continue
            gg = gg.set_index('rep')
            if not gg.index.equals(base.index):
                gg = gg.reindex(base.index)
            if gg.V.isna().any():
                raise ValueError('incomplete paired samples')
            for ratio in (1, 3, 10):
                low = (ratio*gg.rel_under+gg.rel_over)-(ratio*base.rel_under+base.rel_over_upper)
                high = (ratio*gg.rel_under+gg.rel_over_upper)-(ratio*base.rel_under+base.rel_over)
                identified = np.isfinite(low).all() and np.isfinite(high).all()
                if identified:
                    diff = low.to_numpy()
                    means = rng.choice(diff, size=(2000, len(diff)), replace=True).mean(axis=1)
                    ci = np.quantile(means, [.025, .975])
                else:
                    ci = [np.nan, np.nan]
                paired.append(dict(world=world, T=T, rule=rule, ratio=ratio, n=len(gg),
                                   mean_diff_lower=low.mean(), mean_diff_upper=high.mean(),
                                   ci_lo=ci[0], ci_hi=ci[1], identified=identified))
    pd.DataFrame(paired).to_csv(out / 'decision_paired.csv', index=False)
    c = pd.read_csv(out / 'coverage_raw.csv')
    if c.duplicated(['world', 'T', 'rep', 'method']).any():
        raise ValueError('duplicate coverage keys')
    rows = []
    for (world, method), g in c.groupby(['world', 'method']):
        lo, hi = wilson(int(g.covered.sum()), len(g))
        rows.append(dict(world=world, method=method, n=len(g), B=int(g.B.iloc[0]),
                         coverage=g.covered.mean(), ci_lo=lo, ci_hi=hi,
                         nominal_inside_mc_interval=bool(lo <= .9 <= hi),
                         infinite_upper_share=g.infinite_upper.mean(),
                         median_width_ratio=g.width_ratio.median(),
                         mean_unresolved_draw_share=g.unresolved_share.mean(),
                         failed_draws=int(g.n_failed.sum())))
    pd.DataFrame(rows).to_csv(out / 'coverage_summary.csv', index=False)
    inner = pd.read_csv(out / 'inner_raw.csv')
    paired = inner.merge(d[d['T'] == 11], on=['world', 'T', 'rep', 'rule'], suffixes=('_high', '_base'), validate='one_to_one')
    rows = []
    for (world, rule), g in paired.groupby(['world', 'rule']):
        good = np.isfinite(g.V_high) & np.isfinite(g.V_base)
        delta = (g.loc[good, 'V_high']-g.loc[good, 'V_base']).abs()/g.loc[good, 'V_high']
        rows.append(dict(world=world, rule=rule, n_pairs=len(g), finite_pairs=int(good.sum()),
                         B_base=int(g.B_base.iloc[0]), B_high=int(g.B_high.iloc[0]),
                         median_relative_change=delta.median(), p95_relative_change=delta.quantile(.95),
                         maximum_relative_change=delta.max()))
    pd.DataFrame(rows).to_csv(out / 'inner_sensitivity.csv', index=False)
    refined = pd.read_csv(out/'precision_refinement_raw.csv')
    b240 = inner.rename(columns={'V':'V240'})[['world','T','rep','rule','V240']]
    b80 = d[d['T'] == 11].rename(columns={'V':'V80'})[['world','T','rep','rule','V80']]
    triple = refined.merge(b240,on=['world','T','rep','rule'],validate='one_to_one').merge(
        b80,on=['world','T','rep','rule'],validate='one_to_one')
    rows=[]
    for (world,rule),g in triple.groupby(['world','rule']):
        good = np.isfinite(g.V)&np.isfinite(g.V240)&np.isfinite(g.V80)
        a = (g.loc[good,'V80']-g.loc[good,'V']).abs()/g.loc[good,'V']
        b = (g.loc[good,'V240']-g.loc[good,'V']).abs()/g.loc[good,'V']
        rows.append(dict(world=world,rule=rule,n_pairs=len(g),finite_triples=int(good.sum()),
            median_change_80_to_960=a.median(),median_change_240_to_960=b.median(),
            maximum_change_240_to_960=b.max()))
    pd.DataFrame(rows).to_csv(out/'precision_refinement_summary.csv',index=False)


def report(out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figures = ROOT / 'paper/figures'
    c = pd.read_csv(out / 'coverage_summary.csv')
    s = pd.read_csv(out / 'decision_summary.csv')
    p = pd.read_csv(out / 'decision_paired.csv')
    inner = pd.read_csv(out / 'inner_sensitivity.csv')
    refined = pd.read_csv(out/'precision_refinement_summary.csv')
    nd = pd.read_csv(out / 'norwegian_diagnostics.csv')
    finite = pd.read_csv(out / 'finite_treaty_decisions.csv')
    boundaries = pd.read_csv(out / 'finite_treaty_boundaries.csv')
    stress = pd.read_csv(out / 'stress_target_diagnostics.csv')
    p05 = stress[np.isclose(stress.target,.05) & np.isfinite(stress.achieved_strict_breach)]
    settings = json.loads((out / 'run_metadata.json').read_text())['settings']
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
    fig, ax = plt.subplots(figsize=(8, 4))
    for j, method in enumerate(('bootstrap', 'semi_bayesian')):
        g = c[c.method == method].sort_values('world')
        y = np.arange(len(g)) + j*.18
        ax.errorbar(100*g.coverage, y, xerr=np.array([g.coverage-g.ci_lo, g.ci_hi-g.coverage])*100,
                    fmt='o', capsize=4, label=method.replace('_', ' '))
    ax.axvline(90, color='black', linestyle='--', label='nominal 90%')
    ax.set_yticks(np.arange(3)+.09, ['W2: xi~0.5', 'W3: xi=0.8', 'W5: xi=0.25'])
    ax.set_xlabel('Repeated-sample coverage (%) with pointwise 95% Wilson intervals')
    ax.set_title('Current interval algorithm: calibration must be measured')
    ax.legend(fontsize=8); fig.tight_layout(); fig.savefig(figures/'F6_current_coverage.png', dpi=180); plt.close(fig)
    labels = {'D0_aic_plugin':'D0 plug-in', 'D1_bma_mixture':'D1 mixture',
              'D3_hurwicz_0.5':'D3 theta=0.5', 'D3_hurwicz_0.75':'D3 theta=0.75'}
    fig, axes = plt.subplots(1, 2, figsize=(11, 4), sharey=True)
    for ax, T in zip(axes, (11, 40)):
        for j, (rule, label) in enumerate(labels.items()):
            g = s[(s['T'] == T) & (s.rule == rule)].sort_values('world')
            pos = np.arange(5)+(j-1.5)*.12
            ax.errorbar(pos, g.p_shortfall*100,
                        yerr=np.array([g.p_shortfall-g.shortfall_ci_lo, g.shortfall_ci_hi-g.p_shortfall])*100,
                        fmt='o', markersize=4, capsize=2, label=label)
        ax.set_xticks(range(5), ['W1', 'W2', 'W3', 'W4', 'W5'])
        ax.set_title(f'T={T} years; pointwise Monte Carlo intervals')
    axes[0].set_ylabel('P(estimated capital < true quantile), %')
    axes[1].legend(fontsize=8); fig.tight_layout(); fig.savefig(figures/'F7_current_decisions.png', dpi=180); plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
    n = nd[(nd.severity == 'Spliced5') & (nd.freq == 'PoissonConst')]
    scenario_names = {'full_history':'Full history','remove_largest':'Largest claim removed',
                      'remove_largest_three':'Three largest removed',
                      'recent_severity_three_years':'Recent severity (3 years)',
                      'recent_frequency_three_years':'Recent frequency (3 years)'}
    for scenario, g in n.groupby('scenario'):
        axes[0].plot(g.test_year, g.V995, 'o-', label=scenario_names[scenario], markersize=4)
        axes[1].plot(g.test_year, g.pit_S, 'o-', markersize=4)
    observed = n[n.scenario == 'full_history']
    axes[0].plot(observed.test_year, observed.realised_S, 'k--', label='observed annual loss')
    axes[0].set_ylabel('Annual VaR99.5 (500k NOK units)')
    axes[1].set_ylabel('Annual aggregate PIT'); axes[1].set_ylim(0, 1)
    handles, legend_labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, legend_labels, loc='lower center', ncol=3, fontsize=8)
    for ax in axes: ax.set_xticks(sorted(n.test_year.unique()))
    axes[0].set_title('Norwegian Spliced5 influence diagnostics')
    axes[1].set_title('Deletion experiments are not causal estimates')
    fig.tight_layout(rect=(0,.14,1,1)); fig.savefig(figures/'F8_norwegian_diagnostics.png', dpi=180); plt.close(fig)
    lines = ['# Current-engine validation and decision evidence', '',
             'This report is generated from `results/current/`. Historical simulation files are not used in these tables.', '',
             '## Experimental design', '',
             f"Five synthetic worlds, {settings['reps']} independently seeded samples per world at each of T=11 and T=40; "
             f"B={settings['B']} refits per plausible model. All rules share the same sample within a replication. "
             f"A separate T=11 coverage experiment uses {settings['coverage_reps']} samples per world in W2/W3/W5 "
             f"and B={settings['coverage_B']}. The first {settings['inner_reps']} decision samples per world are also "
             f"fitted with B={3*settings['B']} to assess inner simulation sensitivity. "
             'Coverage and decision experiments reuse matching T=11 data-sample IDs; the additional coverage '
             'IDs supply further samples. Reported counts are analysis cases, not disjoint datasets across experiments. '
             'Random streams are recorded in `run_metadata.json`; failed tasks abort rather than disappear.', '',
             'Initial aggregation uses a 0.5 grid and a compact, exponentially tilted aggregate domain. '
             'The circular alias mass bound is below 1.13e-7; compact-versus-padded CDF and quantile tests pass. '
             'Predictive spectra are averaged before a single inverse FFT, which is equivalent by linearity to '
             'mixing conditional distributions. Unresolved predictive quantiles are recomputed on expanded '
             'domains up to 2,097,152. A halved grid step must change a resolved expanded quantile by no more than 0.5%. '
             'Unresolved outputs retain their final evaluated ceiling and unbounded cost. DGP quantiles are independently '
             'checked on a finer, larger grid. Finite initial-grid points rely on the existing fitted-grid checks; '
             'the inner bootstrap study does not establish convergence for every possible sample.', '',
             f"Reverse-stress boundaries target 5%/50% using lattice quantiles. Achieved strict probabilities "
             f"at the 5% target range from {p05.achieved_strict_breach.min():.3%} to "
             f"{p05.achieved_strict_breach.max():.3%}; adjacent-cell masses explain the difference. "
             f"{int((stress.status == 'unreached_in_search_range').sum())} searches do not reach the requested "
             'target within the prescribed stress range and retain that explicit status. See `stress_target_diagnostics.csv`.', '',
             '## Current interval coverage', '',
             '| World | Method | Coverage | Pointwise 95% Monte Carlo interval | Infinite upper endpoint | Median width ratio |',
             '|---|---|---:|---:|---:|---:|']
    for r in c.itertuples():
        lines.append(f'| {r.world.split("_")[0]} | {r.method} | {r.coverage:.1%} | [{r.ci_lo:.1%}, {r.ci_hi:.1%}] | {r.infinite_upper_share:.1%} | {r.median_width_ratio:.2f} |')
    lines += ['', 'Wilson intervals describe finite-replication error. Inclusion of 90% is not proof of calibration. '
              'Every known true quantile in this experiment is below the base 16,384 ceiling. Thus the coverage '
              'event remains identified when an endpoint is right-censored above that ceiling: an upper endpoint '
              'still exceeds the truth, and a censored lower endpoint still excludes it. Width is then only '
              'partially identified; an infinite marker does not imply an infinite model quantile. Semi-Bayesian credible '
              'intervals and bootstrap intervals have different interpretations. These repeated-sample results evaluate '
              'both as procedures under the stated worlds, without giving either a universal frequentist guarantee.', '',
              '## Decision costs and estimation shortfalls', '',
              'Loss is 3 × relative capital shortfall + relative capital excess. It is an illustrative asymmetric '
              'decision cost, distinct from realised annual loss and from a regulatory capital requirement.', '',
              '| T | World | Rule | P(estimate below truth) | Mean loss r=3 | Censored | Expanded |',
              '|---:|---|---|---:|---:|---:|---:|']
    for r in s[s.rule.isin(labels)].itertuples():
        lines.append(f'| {r.T} | {r.world.split("_")[0]} | {labels[r.rule]} | {r.p_shortfall:.1%} | {r.loss_r3:.3f}{" (lower bound)" if r.capped_share else ""} | {r.capped_share:.1%} | {r.expanded_share:.1%} |')
    lines += ['', 'Paired bootstrap intervals and loss bounds for cost ratios 1, 3 and 10 are in '
              '`decision_paired.csv`. They are pointwise, simulation-conditional intervals, with no multiplicity '
              'adjustment. They resample finite paired losses and can miss rare extremes; their coverage is '
              'not established when loss moments are uncontrolled. Finite grid quantiles do not establish '
              'existence of population mean or variance of decision cost. Empirical MCSE columns are '
              'descriptive finite-sample calculations. These diagnostics do not select an optimal actual-insurer rule.', '',
              '## Inner refit sensitivity', '',
              '| World | Rule | Median relative change B=80 to B=240 | Maximum | Finite paired samples |',
              '|---|---|---:|---:|---:|']
    for r in inner[inner.rule.isin(labels)].itertuples():
        lines.append(f'| {r.world.split("_")[0]} | {labels[r.rule]} | {r.median_relative_change:.1%} | {r.maximum_relative_change:.1%} | {r.finite_pairs}/{r.n_pairs} |')
    lines += ['', 'This deliberately small paired diagnostic is a precision warning, not a claim that B=80 is '
              'adequate for production. Rule differences comparable to this variation should not drive a decision. '
              'Data samples are held fixed across B; random streams after the first model are not fully nested.', '',
              '### Targeted B=960 refinement', '',
              'W1 and W4 were selected after inspecting the B=80/B=240 diagnostic. The same first 12 '
              'training samples/world were refitted with B=960. This post-analysis diagnostic supplements '
              'the main experiment; it does not replace selected rows or establish an unbiased new rule ranking.', '',
              '| World | Rule | Median change B=80 to B=960 | Median change B=240 to B=960 | Maximum B=240 to B=960 | Finite triples |',
              '|---|---|---:|---:|---:|---:|']
    for r in refined[refined.rule.isin(labels)].itertuples():
        lines.append(f'| {r.world.split("_")[0]} | {labels[r.rule]} | {r.median_change_80_to_960:.1%} | {r.median_change_240_to_960:.1%} | {r.maximum_change_240_to_960:.1%} | {r.finite_triples}/{r.n_pairs} |')
    lines += ['', 'Relative changes condition on finite triples; their counts prevent unresolved outputs '
              'from silently disappearing. The B=80 capital-rule comparisons remain exploratory. Higher-B stability on a small '
              'selected subset does not validate production precision in every world. The finite-treaty '
              'analysis uses deterministic fitted distributions and has a separate decision objective.', '',
              '## Norwegian failure analysis', '',
              'The following table holds the Spliced5/constant-Poisson model family fixed. Removing the largest '
              'claims changes severity fitting only; annual counts remain unchanged to isolate an influence diagnostic. '
              'It is not a legitimate alternative dataset or evidence that extreme claims should be discarded.', '',
              '| Scenario | Median predicted VaR / realised annual loss | Annual PIT range |',
              '|---|---:|---:|']
    for scenario, g in n.groupby('scenario'):
        lines.append(f'| {scenario} | {(g.V995/g.realised_S).median():.2f} | {g.pit_S.min():.4f}–{g.pit_S.max():.4f} |')
    lines += ['', 'Recent-window severity and frequency refits are separated. This helps attribute sensitivity, '
              'but cannot identify exposure growth, inflation, threshold changes or the true extreme quantile. '
              'The raw results also include alternative severity/frequency models and the AIC-selected family in '
              'each refit. Four forecast years cannot establish stable predictive calibration.', '',
              '## Finite-layer actions under a resource constraint', '',
              'Eight fixed actions include no cover and seven finite per-occurrence layers. A notation such as '
              '`100_xs_20` means a 100m limit above a 20m DKK retention; losses above 120m return to the insurer. '
              'Premiums use either Spliced10 or Spliced5, with 10%/30%/50% loading; annual funding rates are '
              '3%/6%/12%. Quotes are assumptions held fixed across nine plausible risk views. Resource budgets '
              'of 1,250/1,750/2,500m DKK fund net annual VaR plus premium paid upfront.', '',
              'An action is admissible only when the budget holds in every risk view. Minimax regret is then '
              'computed over this common feasible set. The clairvoyant comparator can choose the best feasible '
              'action in each risk view, but cannot use an action outside that common set.', '',
              '| Pricing view | Loading | Funding | Budget | Feasible actions | Conditional minimax-regret action | Worst regret |',
              '|---|---:|---:|---:|---:|---|---:|']
    for r in finite[finite.funding_rate == .06].itertuples():
        lines.append(f'| {r.pricing_model} | {r.loading:.0%} | {r.funding_rate:.0%} | {r.resource_budget:.0f} | {r.feasible_actions} | {r.selected_action} | {r.worst_regret:.2f} |')
    lines += ['', '**Decision-change boundaries at 6% funding cost.** Negative feasibility boundaries mean even '
              'a zero-loading quotation would exceed the budget in at least one risk view. The cost boundary '
              'compares a layer with no cover in every risk view; it does not establish optimality against all layers.', '',
              '| Pricing view | Layer | Resource budget | Maximum loading feasible in all views | Maximum loading no more costly than no cover in all views |',
              '|---|---|---:|---:|---:|']
    for r in boundaries[(boundaries.action.isin(['500_xs_20','250_xs_50'])) & (boundaries.resource_budget.isin([1750,2500]))].itertuples():
        lines.append(f'| {r.pricing_model} | {r.action} | {r.resource_budget:.0f} | {r.max_loading_feasible_all_views:.1%} | {r.max_loading_cost_no_greater_than_none_all_views:.1%} |')
    lines += ['', 'A conditional action is a quotation-screening result, not an instruction to buy insurance. '
              'Treaty exclusions, aggregate limits, reinstatements, counterparty default, claims development '
              'and recovery delays remain outside this calculation. A finite layer can have a finite price '
              'even when gross mean loss is infinite; it does not make the retained mean finite in that case.', '',
              '## What the evidence supports', '',
              '- Compare capital rules jointly on estimation shortfalls, decision costs and numerical resolution.',
              '- Report calibration failures and inner-refit sensitivity alongside point estimates.',
              '- Use finite-layer and budget sensitivity to structure requests for actual quotations.',
              '- Retain regime-break stress as an explicit limitation of candidate-model robustness.', '',
              'It does not establish regulatory compliance, a calibrated actual-insurer capital policy, '
              'a universal winning rule, or independent institutional validation.', '',
              '![Current coverage](figures/F6_current_coverage.png)', '',
              '![Current decisions](figures/F7_current_decisions.png)', '',
              '![Norwegian diagnostics](figures/F8_norwegian_diagnostics.png)', '']
    (ROOT/'paper/current_validation.md').write_text('\n'.join(lines), encoding='utf-8')
    update_paper(settings, c, s, inner)
    print('Fresh validation summaries, figures and report generated')


def update_paper(settings, coverage, decisions, inner):
    path = ROOT/'paper/paper.md'
    text = path.read_text(encoding='utf-8')
    text = text.replace('pip install -r requirements.txt','pip install -r requirements-lock.txt')
    status_start = text.index('Empirical outputs come from') if 'Empirical outputs come from' in text else -1
    if status_start >= 0:
        status_end = text.index('\n\n---', status_start)
        text = text[:status_start]+(
            'Version 0.5 empirical outputs are regenerated from the current fitting engine. Fresh seeded '
            'decision, coverage and inner-refit experiments are in `results/current/`; their generated '
            'technical report is `paper/current_validation.md`. Historical simulation and coverage outputs '
            'are retained as explicitly labelled version-comparison evidence. Figures are in `paper/figures/`.')+text[status_end:]
    boot_cov=coverage[coverage.method == 'bootstrap'].coverage
    post_cov=coverage[coverage.method == 'semi_bayesian'].coverage
    largest_censor=coverage[coverage.method == 'semi_bayesian'].infinite_upper_share.max()
    abstract = (
        'We study defensible capital and reinsurance decisions when plausible risk models disagree. '
        'The setting is a stylised large-fire-loss portfolio, with annual VaR at 99.5% defined as a total '
        'resource level and capital above expected loss reported separately. Five severity and three '
        'frequency models on Danish claims give resource levels of roughly 1.14–2.30 billion DKK; '
        'a Norwegian replication reverses the relative conservatism of the selected baseline. '
        f"Fresh synthetic experiments use {settings['reps']} samples in each of five known worlds at "
        f"11- and 40-year horizons, B={settings['B']} bootstrap refits, and a separate {settings['coverage_reps']}-sample "
        f"coverage study in three tail worlds with B={settings['coverage_B']}. "
        'The experiments compare estimation shortfalls, asymmetric decision costs and parameter-interval '
        'coverage; pointwise Monte Carlo uncertainty and inner-refit sensitivity remain visible. '
        f'Nominal-90% bootstrap coverage is {boot_cov.min():.1%}–{boot_cov.max():.1%}; '
        f'semi-Bayesian coverage is {post_cov.min():.1%}–{post_cov.max():.1%}, with up to '
        f'{largest_censor:.1%} of upper endpoints beyond the base numerical grid. '
        'Inner-refit sensitivity makes B=80 rule comparisons exploratory. '
        'Unresolved predictive quantiles trigger expanded grids and step refinement, with any remaining '
        'censored costs retained as bounds. Norwegian claim-influence and recent-window diagnostics '
        'investigate forecast over-prediction without treating valid extremes as data errors. A finite-layer '
        'reinsurance extension uses fixed hypothetical quotes and a common feasible action set under '
        'resource budgets; the conditional decision can be no cover or no feasible action. Neither '
        'numerical stability nor four to six annual backtest observations establishes extreme-tail '
        'calibration. Capital-rule and action preferences remain conditional on the candidate set, '
        'synthetic worlds, prices and decision costs. The contribution is reproducible implementation, '
        'explicit failure analysis and transparent decision comparison; no methodological novelty or '
        'institutional model approval is claimed.')
    text = re.sub(r'(## Abstract\n\n).*?(\n\n## 1\.)', lambda m:m[1]+abstract+m[2], text, count=1, flags=re.S)
    text = text.replace('### 6.5 Simulation study (SYNTHETIC;', '### 6.5 Historical simulation study (SYNTHETIC;')
    text = text.replace('No general support: cost-ratio dependent; comparisons with censored outputs have unidentified upper losses',
        'No general support: cost-ratio dependent and inner-refit sensitive; historical censored comparisons have unidentified upper losses')
    historical = pd.read_csv(ROOT/'results/SIM_loss_bounds.csv')
    tail = historical[historical.world.str.startswith('W4') & (historical.ratio == 3)]
    historical_range = f'{100*tail.p_estimate_below_truth.min():.0f}–{100*tail.p_estimate_below_truth.max():.0f}%'
    if 'Historical saved tail-break cells' not in text:
        text = re.sub(r'(^### 6\.5[^\n]*\n)',lambda m:m[0]+'\nHistorical saved tail-break cells span '
            +historical_range+' estimation shortfalls across the archived rule/horizon results. '
            'Current-engine evidence is in §6.10.\n',text,count=1,flags=re.M)
    old = 'The revised implementation retains them and uses empirical-CDF quantiles; its repeated-sampling coverage has not yet been rerun.'
    text = text.replace(old, 'The revised implementation retains them and uses empirical-CDF quantiles; fresh repeated-sampling results are reported in §6.10. The figures in this subsection remain historical.')
    text = text.replace('its causal role in over-prediction was not tested, nor were inflation drift and the subsequent fall in claim counts.',
        'largest-claim influence and recent-window frequency/severity sensitivity are investigated in §6.10. These diagnostics do not identify causal effects or resolve inflation and exposure confounding.')
    text = text.replace('4. Revised capital intervals retain unresolved draws, but repeated-sampling calibration after this change has not been established. Historical coverage estimates must not be treated as a validated repair.',
        '4. Current capital-interval coverage is measured in three synthetic tail worlds with Monte Carlo intervals. These experiments do not confer universal calibration; infinite endpoints, interval width and finite inner-refit precision must be considered together. Historical coverage estimates are version-comparison evidence.')
    text = text.replace('6. Historical simulation fits were not rerun under the revised engine. Censored decision costs have unbounded upper endpoints; some decision rankings remain unidentified. T=40 has only 30 replications/world.',
        '6. Historical simulation fits remain separate from the fresh current-engine study. Current T=11/T=40 experiments have 150 samples/world and a small B=80/B=240 precision diagnostic. Synthetic worlds share Poisson frequency and a Danish anchor. Any remaining censored costs have unbounded upper endpoints; finite heavy-tailed costs can still be imprecisely estimated.')
    text = text.replace('Repeated-sampling coverage of the revised interval algorithm remains open.',
        'Fresh repeated-sampling coverage and inner-refit sensitivity are reported in §6.10 and `paper/current_validation.md`. They evaluate the stated experiments rather than certifying institution-specific calibration.')
    stress_note = ('\n\n**Lattice precision.** Reverse-stress search uses `VaR_alpha(stressed) >= V0`. '
        'On a discrete lattice this approximates, rather than exactly equals, the strict-exceedance target '
        '`P(S > V0) = 1-alpha`. Achieved strict probabilities and the adjacent-cell masses are saved in '
        '`results/current/stress_target_diagnostics.csv`; verification allows the lattice/root-search tolerance.')
    if '**Lattice precision.**' not in text:
        text = text.replace('## 6. Results', stress_note+'\n\n## 6. Results')
    text = text.replace('`python scripts/reproduce.py empirical` regenerates the two real-data experiments, E5 explorer data, figures and sensitivity evidence, then verifies them.',
        '`python scripts/reproduce.py all` regenerates the two real-data experiments, E5 explorer data, fresh current simulations, extension studies, figures and reports before verification. The `empirical` and `research` modes rebuild the respective subsets; source provenance prevents mixing incompatible current-study engines.')
    rows = ['### 6.10 Current-engine validation and decision extensions', '',
        '<!-- CURRENT_STUDY_START -->',
        f"The version-0.5 study uses {settings['reps']} fresh samples per world at each of T=11 and T=40 "
        f"and B={settings['B']}. A separate coverage study uses {settings['coverage_reps']} samples in "
        f"W2/W3/W5 with B={settings['coverage_B']}. All reported results below come from `results/current/`, "
        'with source/dependency hashes and independent task seeds. Historical tables above do not serve as current-engine evidence.', '',
        '**Coverage of nominal-90% parameter intervals.** Wilson intervals quantify finite-replication error.', '',
        '| World | Method | Coverage | 95% Monte Carlo interval | Infinite upper endpoint |',
        '|---|---|---:|---:|---:|']
    for r in coverage.itertuples():
        rows.append(f'| {r.world.split("_")[0]} | {r.method} | {r.coverage:.1%} | [{r.ci_lo:.1%}, {r.ci_hi:.1%}] | {r.infinite_upper_share:.1%} |')
    rows += ['', '**Numerical resolution.** Predictive mixtures average conditional spectra before inversion. '
        'The compact tilted aggregate domain has circular alias mass bound <1.13e-7 and passes padded-domain comparisons. '
        'Unresolved capitals are expanded up to 2,097,152 and accepted only after a halved-step change of at most 0.5%. '
        f"Across all current rule outputs, {decisions.capped_share.max():.1%} is the largest world/horizon/rule censored share. "
        'Censored outputs retain their actual final ceiling and unbounded upper cost. Finite quantiles do not establish calibration or precise mean decision costs.', '',
        '**Decision precision.** Same-sample paired costs for ratios 1/3/10 and Wilson intervals for estimation '
        'shortfalls are saved in `decision_paired.csv` and `decision_summary.csv`. The first '
        f"{settings['inner_reps']} data samples/world are compared at B={settings['B']} and B={3*settings['B']}. "
        'W1/W4 additionally receive a targeted B=960 refit on those fixed samples after the initial diagnostic. '
        'These are precision diagnostics, not production convergence certificates; B=80 rankings remain exploratory. The full generated report '
        'retains all worlds and adverse findings; no automatic capital-rule winner is inferred.', '',
        '**Norwegian influence.** Largest-claim and top-three-claim deletions hold counts fixed; recent '
        'severity and recent frequency windows are changed separately. Removing extremes changes capital, '
        'but does not justify discarding valid claims or establish the true annual tail. Full scenario/model '
        'outputs and PIT diagnostics are in `norwegian_diagnostics.csv`.', '',
        '**Finite-layer decisions.** Eight actions, fixed quotations from two pricing views, three loadings '
        'and funding rates, and three resource budgets are compared across nine plausible risk views. '
        'Resources fund net VaR plus premium upfront. Feasibility is imposed across all views before '
        'minimax regret is computed over the common feasible set. `finite_treaty_boundaries.csv` gives '
        'conditional loading boundaries for budget feasibility and comparison with no cover. Actual '
        'quotes, terms, recovery delays and counterparty risk remain outside the case study.', '',
        'See **[the generated current-validation report](current_validation.md)** and '
        '**[the offline evidence report](../app/evidence_report.html)** for tables, charts and interpretation.',
        '<!-- CURRENT_STUDY_END -->', '']
    section = '\n'.join(rows)
    if '### 6.10 Current-engine' in text:
        text = re.sub(r'### 6\.10 Current-engine.*?(?=## 7\. Limitations)', section+'\n', text, flags=re.S)
    else:
        text = text.replace('## 7. Limitations', section+'\n## 7. Limitations')
    path.write_text(text, encoding='utf-8')


if __name__ == '__main__':
    out = ROOT/'results/current'
    summaries(out)
    report(out)
