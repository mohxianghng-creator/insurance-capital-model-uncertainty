"""Real-data experiments E0-E4 on the Danish fire losses. Writes results/*.csv|json. Deterministic (seeded)."""
import sys, json, time, os, platform
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import numpy as np, pandas as pd
from cmu import data, severity as S, aggregate as A, frequency as F, uncertainty as U, decision as D, stress as ST, validation as V
from cmu.config import *

RES = Path(os.environ.get("CMU_RESULTS_DIR", ROOT / "results")); RES.mkdir(exist_ok=True)
B = int(sys.argv[1]) if len(sys.argv) > 1 else 200
rng_master = np.random.SeedSequence(SEED)
t0 = time.time()

df = data.load_danish(); card = data.validate(df)
years = list(range(1980, 1991)); counts = V.annual_counts(df, years); x = df.loss.to_numpy()
fits = U.fit_all(S.default_model_set(), x)
aics = np.array([m.aic(x) for m in fits]); dA, wA = D.akaike_weights(aics)
plaus = D.plausible_mask(aics, DELTA_AIC_PLAUSIBLE)

# ---------------- E0: diagnostics (stationarity, tail behaviour)
diag = {}
lx = np.log(x)
first, second = df.year <= 1985, df.year > 1985
diag["spearman_time_logloss_all"] = card["spearman_time_vs_logloss"]
for lo in (1.0, 5.0, 10.0):
    sel = x >= lo
    t = (df.date - df.date.iloc[0]).dt.days.to_numpy()[sel]
    from scipy import stats
    r, p = stats.spearmanr(t, np.log(x[sel])); diag[f"spearman_time_logloss_ge{lo:g}"] = {"rho": float(r), "p": float(p), "n": int(sel.sum())}
for lo, hi in ((1980, 1985), (1986, 1990)):
    xs = x[(df.year >= lo) & (df.year <= hi)]
    diag[f"period_{lo}_{hi}"] = {"n": int(len(xs)), "median": float(np.median(xs)), "share_gt10": float((xs > 10).mean()),
                                 "share_gt20": float((xs > 20).mean())}
# Hill estimator for the top-k order statistics (tail index xi=1/alpha); instability illustrates estimation limits
xs_sorted = np.sort(x)[::-1]
hill = {int(k): float(np.mean(np.log(xs_sorted[:k]) - np.log(xs_sorted[k]))) for k in (20, 40, 60, 100, 150, 250)}
diag["hill_xi_by_k"] = hill
diag["counts_per_year"] = {int(y): int(c) for y, c in zip(years, counts)}
diag["poisson_dispersion_index"] = float(np.var(counts, ddof=1) / np.mean(counts))
trend = F.PoissonTrend().fit(counts); diag["trend_slope_per_year"] = float(trend.beta[1])
diag["forecast_lambda_const"] = F.PoissonConst().fit(counts).forecast(1); diag["forecast_lambda_trend"] = trend.forecast(1)
(RES / "E0_diagnostics.json").write_text(json.dumps(diag, indent=1))
print("E0 done", time.time() - t0)

# ---------------- E1: capital estimates, parameter vs model uncertainty
rows, boot_store, point_v = [], {}, {}
freq_fit = {f: F.make(f).fit(counts) for f in F.FREQ_NAMES}
freq_aic = {f: 2 * freq_fit[f].n_params() - 2 * freq_fit[f].loglik(counts) for f in F.FREQ_NAMES}
(RES / "E1_frequency_models.json").write_text(json.dumps({
    "AIC_counts": freq_aic, "AIC_note": "NegBinConst uses moment estimates, so its score is an AIC-style diagnostic, not maximised-likelihood AIC", "lambda_forecast_1991": {f: freq_fit[f].forecast(1) for f in F.FREQ_NAMES},
    "nb_r": freq_fit["NegBinConst"].r,
    "dispersion_test_chi2_df10": float((len(counts) - 1) * np.var(counts, ddof=1) / np.mean(counts)),
    "dispersion_test_p": float(__import__("scipy.stats").stats.chi2.sf((len(counts) - 1) * np.var(counts, ddof=1) / np.mean(counts), len(counts) - 1))}, indent=1))
for fname in F.FREQ_NAMES:
    lam = freq_fit[fname].forecast(1); rr = freq_fit[fname].r
    for m, a_, d_, w_, pl in zip(fits, aics, dA, wA, plaus):
        agg = A.aggregate(m.cdf, lam, r=rr)
        v = agg.var(ALPHA_VAR); tv, ok = agg.tvar(ALPHA_TVAR)
        rng = np.random.default_rng(rng_master.spawn(1)[0])
        bt = U.bootstrap_capital(m, x, counts, fname, B, rng)
        vb = bt["var"]; fin = np.isfinite(vb)
        boot_store[(m.name, fname)] = vb; point_v[(m.name, fname)] = v
        rows.append(dict(severity=m.name, freq=fname, lam=lam, AIC=a_, dAIC=d_, akaike_w=w_, plausible=bool(pl),
                         V995=v, EL=agg.mean_S, K_econ=v - agg.mean_S, TVaR99=tv, tvar_reliable=ok,
                         V_boot_p05=float(U.capital_quantiles(vb, .05)), V_boot_p50=float(U.capital_quantiles(vb, .50)),
                         V_boot_p95=float(U.capital_quantiles(vb, .95)), boot_inf_share=float(1 - fin.mean()),
                         V_boot_ci_ratio=float(U.capital_quantiles(vb, .95) / U.capital_quantiles(vb, .05)),
                         boot_success=bt["n_success"], boot_failed=bt["n_failed"], EL_grid=agg.mean_S_grid,
                         overflow_prob=agg.overflow_prob, **{f"par_{k}": val for k, val in m.params().items()}))
e1 = pd.DataFrame(rows); e1.to_csv(RES / "E1_capital_by_model.csv", index=False)
dec = {}
for fname in F.FREQ_NAMES:
    pv = {k[0]: v for k, v in point_v.items() if k[1] == fname}; bv = {k[0]: v for k, v in boot_store.items() if k[1] == fname}
    dec[f"severity_models__{fname}"] = U.decompose(pv, bv)
pv = {f"{k[0]}|{k[1]}": v for k, v in point_v.items()}; bv = {f"{k[0]}|{k[1]}": v for k, v in boot_store.items()}
dec["all_combinations"] = U.decompose(pv, bv)
for fname in F.FREQ_NAMES:
    names = {m.name for m, keep in zip(fits, plaus) if keep}
    pv = {k[0]: v for k, v in point_v.items() if k[1] == fname and k[0] in names}
    bv = {k[0]: v for k, v in boot_store.items() if k[1] == fname and k[0] in names}
    dec[f"plausible_only__{fname}"] = U.decompose(pv, bv)
(RES / "E1_decomposition.json").write_text(json.dumps(dec, indent=1))
np.savez(RES / "E1_bootstrap_var.npz", **{f"{k[0]}|{k[1]}": v for k, v in boot_store.items()})
print("E1 done", time.time() - t0)

# ---------------- E2: rolling-origin validation + power
ro = V.rolling_origin(df); ro.to_csv(RES / "E2_rolling_origin.csv", index=False)
sev_score = ro[ro.freq == "PoissonConst"].groupby("severity").agg(
    logscore=("logscore", "sum"), censored_logscore=("censored_logscore", "sum"),
    exceed_q99=("exceed_q99", "sum"), exceed_q999=("exceed_q999", "sum"), n_test=("n_test", "sum"),
    breaches=("breach", "sum")).reset_index()
sev_score["kupiec_p_q99"] = [V.kupiec_pof(int(r.n_test), int(r.exceed_q99), 0.01)[1] for r in sev_score.itertuples()]
sev_score["kupiec_p_q999"] = [V.kupiec_pof(int(r.n_test), int(r.exceed_q999), 0.001)[1] for r in sev_score.itertuples()]
sev_score.to_csv(RES / "E2_scores_by_model.csv", index=False)
pw = pd.concat([V.breach_test_power(n) for n in (6, 11, 50)]); pw.to_csv(RES / "E2_power_breach_test.csv", index=False)
yn = {f"p_true={p}": V.years_needed_for_power(p) for p in (0.01, 0.02, 0.05, 0.1)}
(RES / "E2_years_needed_80pct_power.json").write_text(json.dumps(yn, indent=1))
print("E2 done", time.time() - t0)

# ---------------- E3: management actions (excess-of-loss retention) and rank stability
lam_ref = freq_fit["PoissonConst"].forecast(1)
actions = [("A0_none", None), ("A1_R50", 50.0), ("A2_R20", 20.0), ("A3_R10", 10.0), ("A4_R5", 5.0)]
e3 = []
for ref_name in ("Spliced10", "Spliced5"):                      # reinsurer's pricing view (exogenous assumption)
    ref = next(m for m in fits if m.name == ref_name)
    for loading in (0.2, 0.5):
        prem = {a: (0.0 if R is None else (1 + loading) * lam_ref * A.expected_recovery_per_claim(ref.cdf, R)) for a, R in actions}
        for m, pl in zip(fits, plaus):
            for f in F.FREQ_NAMES:
                lam, rr = freq_fit[f].forecast(1), freq_fit[f].r
                for a, R in actions:
                    agg = A.aggregate(m.cdf, lam, retention=R, r=rr)
                    v = agg.var(ALPHA_VAR); K = v - agg.mean_S
                    rec = 0.0 if R is None else lam * A.expected_recovery_per_claim(m.cdf, R)
                    e3.append(dict(pricing_model=ref_name, loading=loading, severity=m.name, freq=f, plausible=bool(pl), action=a,
                                   V995=v, K_econ=K, premium=prem[a], exp_recovery=rec, annual_cost=COST_OF_CAPITAL * K + prem[a] - rec))
e3 = pd.DataFrame(e3); e3.to_csv(RES / "E3_action_costs.csv", index=False)
print("E3 done", time.time() - t0)

# ---------------- E4: reverse stress test around the conventional capital level
d0 = fits[int(np.argmin(aics))]
K0 = A.aggregate(d0.cdf, freq_fit["PoissonConst"].forecast(1)).var(ALPHA_VAR)
xi_sd = {}
for m in fits:
    if m.has_gpd_tail:
        xs_b = [p["xi"] for p in U.bootstrap_capital(m, x, counts, "PoissonConst", B, np.random.default_rng(SEED + 7))["params"]]
        xi_sd[m.name] = float(np.std(xs_b, ddof=1))
e4 = []
for m, pl in zip(fits, plaus):
    for f in F.FREQ_NAMES:
        lam, rr = freq_fit[f].forecast(1), freq_fit[f].r
        agg = A.aggregate(m.cdf, lam, r=rr)
        bp = agg.breach_prob(K0)
        xs_, ann = ST.single_loss_scenario(m, lam, K0, agg.mean_S, r=rr)
        rec = dict(severity=m.name, freq=f, plausible=bool(pl), K0=K0, own_V995=agg.var(ALPHA_VAR), breach_prob_at_K0=bp,
                   return_period_yrs=(1 / bp if bp > 0 else np.inf), single_loss_x_star=xs_, single_loss_annual_prob=ann,
                   xi_hat=(m.xi if m.has_gpd_tail else np.nan), xi_boot_sd=xi_sd.get(m.name, np.nan))
        for tag, al in (("p05", 0.95), ("p50", 0.50)):          # stress s.t. P(S>K0) reaches 5% / 50%
            rec[f"phi_star_{tag}"] = ST.breakeven(m, lam, K0, "phi", alpha=al, r=rr)
            rec[f"s_star_{tag}"] = ST.breakeven(m, lam, K0, "s", alpha=al, r=rr)
            rec[f"dxi_star_{tag}"] = ST.breakeven(m, lam, K0, "dxi", alpha=al, r=rr) if m.has_gpd_tail else np.nan
        bv = boot_store[(m.name, f)]
        rec["boot_prob_V_exceeds_K0"] = float(np.mean(~np.isfinite(bv) | (bv >= K0)))
        e4.append(rec)
e4 = pd.DataFrame(e4); e4.to_csv(RES / "E4_reverse_stress.csv", index=False)
Kf = K0 * 1.25
phis = np.linspace(0.8, 2.0, 13)
fr = {"K": Kf, "baseline_model": d0.name, "phi": phis.tolist(),
      "s_star_baseline": ST.frontier(d0, lam_ref, Kf, phis, alpha=0.95).tolist()}
for m, pl in zip(fits, plaus):
    if pl:
        fr[f"s_star_{m.name}"] = ST.frontier(m, lam_ref, Kf, phis, alpha=0.95).tolist()
(RES / "E4_frontier.json").write_text(json.dumps(fr, indent=1))
meta = {"B": B, "seed": SEED, "baseline_model": d0.name, "K0": K0, "runtime_s": time.time() - t0, "n_claims": int(len(x)), "python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__,
        "interval_method": "inverse empirical CDF; retain unresolved +inf draws", "mean_method": "uncapped severity stop-loss",
        "grid": {"h": A.H, "nx": A.NX, "ns": A.NS}, "severity_aic_scope": "conditional on five fixed candidate models"}
(RES / "run_meta.json").write_text(json.dumps(meta, indent=1))
print("E4 done", time.time() - t0, meta)
