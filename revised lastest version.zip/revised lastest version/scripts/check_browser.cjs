const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const root=path.resolve(__dirname,'..');
process.env.PLAYWRIGHT_BROWSERS_PATH ||= path.join(root,'work/pw-browsers');
const modules=process.env.CMU_BROWSER_MODULES || path.join(root,'work/browser-check/node_modules');
const { chromium } = require(path.join(modules,'playwright'));
const AxeBuilder = require(path.join(modules,'@axe-core/playwright')).default;
function csv(name){
  // These generated scientific tables contain no quoted comma-bearing fields.
  const lines=fs.readFileSync(path.join(root,'results/current',name),'utf8').trim().split(/\r?\n/);
  const header=lines.shift().split(',');
  return lines.map(line=>Object.fromEntries(line.split(',').map((v,i)=>[header[i],v])));
}
(async()=>{
  const browser = await chromium.launch({headless:true});
  const context = await browser.newContext({viewport:{width:1280,height:900}});
  const page = await context.newPage();
  const errors=[];
  page.on('pageerror', e=>errors.push(e.message));
  await page.goto(pathToFileURL(path.join(root,'app/decision_explorer.html')).href);
  await page.waitForSelector('#rules .rule');
  let scenarios=0;
  for(const freq of ['PoissonConst','NegBinConst','PoissonTrend'])
    for(const cut of ['2','4','10'])
      for(const meth of ['boot','post']){
        await page.selectOption('#freq',freq);await page.selectOption('#cut',cut);await page.selectOption('#meth',meth);
        await page.locator('#ratio').evaluate(el=>{el.value='3';el.dispatchEvent(new Event('input',{bubbles:true}))});
        const text=await page.locator('#rules').innerText();
        if(/NaN|undefined/.test(text))throw new Error('Invalid capital rendering');
        scenarios++;
      }
  const current = await page.evaluate(()=>!!DATA.current);
  if(current){
    const treaties=csv('finite_treaty_decisions.csv'),raw=csv('decision_raw.csv');
    for(const q of ['Spliced10','Spliced5'])for(const l of ['0.1','0.3','0.5'])
      for(const f of ['0.03','0.06','0.12'])for(const b of ['1250','1750','2500']){
        await page.selectOption('#quoteView',q);await page.selectOption('#loading',l);
        await page.selectOption('#funding',f);await page.selectOption('#budget',b);
        if(!/Conditional action|No feasible action/.test(await page.locator('#treatyDecision').innerText()))throw new Error('Missing treaty decision');
        const saved=treaties.find(t=>t.pricing_model===q&&+t.loading===+l&&+t.funding_rate===+f&&+t.resource_budget===+b);
        const result=await page.locator('#treatyDecision').innerText();
        if(+saved.feasible_actions===0?!result.includes('No feasible action'):!result.includes(saved.selected_action.replaceAll('_',' ')))throw new Error('Treaty choice differs from saved evidence');
        scenarios++;
      }
    for(const t of ['11','40'])for(const ratio of ['0.5','3','10','20']){
      await page.selectOption('#horizon',t);await page.locator('#ratio').evaluate((el,v)=>{el.value=v;el.dispatchEvent(new Event('input',{bubbles:true}))},ratio);
      if(await page.locator('#currentDecisions tr').count()!==21)throw new Error('Incomplete current decision table');
      const body=await page.locator('#currentDecisions tr').allTextContents();
      const worlds=[...new Set(raw.map(r=>r.world))].sort();
      const rules=['D0_aic_plugin','D1_bma_mixture','D3_hurwicz_0.5','D3_hurwicz_0.75'];
      for(let wi=0;wi<worlds.length;wi++)for(let ri=0;ri<rules.length;ri++){
        const samples=raw.filter(r=>r.world===worlds[wi]&&+r.T===+t&&r.rule===rules[ri]);
        const loss=samples.reduce((sum,r)=>sum+(+ratio)*(+r.rel_under)+(+r.rel_over),0)/samples.length;
        if(!body[1+wi*rules.length+ri].includes(loss.toFixed(3)))throw new Error('Displayed decision loss differs from raw-sample arithmetic');
      }
      scenarios++;
    }
  }
  await page.screenshot({path:path.join(root,'work/explorer_desktop.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});
  if(await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+1))throw new Error('Mobile page overflow');
  await page.screenshot({path:path.join(root,'work/explorer_mobile.png'),fullPage:true});
  const accessibility=[];
  for(const scheme of ['light','dark']){
    await page.emulateMedia({colorScheme:scheme});
    const result=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa']).analyze();
    accessibility.push({page:'explorer',scheme,violations:result.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.length}))});
  }
  await page.emulateMedia({colorScheme:'light'});
  const report = path.join(root,'app/evidence_report.html');
  if(fs.existsSync(report)){
    await page.goto(pathToFileURL(report).href);
    if(await page.locator('h1').count()!==1)throw new Error('Report lacks a single title');
    if(await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+1))throw new Error('Mobile report overflow');
    await page.setViewportSize({width:1280,height:900});
    await page.screenshot({path:path.join(root,'work/evidence_report.png'),fullPage:true});
    const result=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa']).analyze();
    accessibility.push({page:'report',violations:result.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.length}))});
  }
  if(errors.length)throw new Error(errors.join('\n'));
  const result={scenarios,current,report:fs.existsSync(report),javascriptErrors:errors.length,accessibility};
  fs.writeFileSync(path.join(root,'work/browser_verification.json'),JSON.stringify(result,null,2));
  console.log(JSON.stringify(result));
  if(accessibility.some(a=>a.violations.length))throw new Error('Accessibility violations');
  await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
