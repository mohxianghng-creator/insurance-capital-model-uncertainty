"""SHA-256 artefact inventory. Hashes detect file changes; they do not certify history or independent review."""
import argparse
import hashlib
import json
import platform
import os
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'results/artifact_manifest.json'


def inventory():
    files = []
    ignored = {'__pycache__', '.pytest_cache', '.git', '.venv', 'venv', '.cache', 'work'}
    for folder, dirs, names in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in ignored and not d.endswith(('.egg-info', '.dist-info'))]
        for name in names:
            p = Path(folder) / name
            if p != MANIFEST and p.suffix not in ('.pyc', '.log'):
                files.append(p)
    return {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--write', action='store_true', help='explicitly replace inventory after reviewing regenerated files')
    args = p.parse_args()
    current = inventory()
    if args.write:
        out = dict(created_utc=datetime.now(timezone.utc).isoformat(), python=platform.python_version(),
                   scope='file integrity only; historical simulation provenance is recorded separately', sha256=current)
        MANIFEST.write_text(json.dumps(out, indent=2), encoding='utf-8')
        print(f'Wrote inventory of {len(current)} files')
        return
    old = json.loads(MANIFEST.read_text(encoding='utf-8'))['sha256']
    changed = sorted(k for k in set(old) | set(current) if old.get(k) != current.get(k))
    if changed:
        print('Changed/missing/new files: ' + ', '.join(changed))
        raise SystemExit(1)
    print(f'PASS: {len(current)} file hashes match the saved inventory')


if __name__ == '__main__':
    main()
