"""Targeted B=960 diagnostic on fixed W1/W4 samples after material B sensitivity.

This supplements the prespecified B=80 experiment. It does not replace selected
rows, retune a capital rule, or establish convergence from a small sample.
"""
import argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
import hashlib
import json
from pathlib import Path
import time
import pandas as pd
import run_research as engine

ROOT=Path(__file__).resolve().parents[1]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--workers',type=int,default=4)
    args=p.parse_args()
    if args.workers < 1: p.error('workers must be positive')
    settings=dict(study='targeted inner-refit diagnostic',worlds=['W1_LN','W4_TailBreak_v100_xi1.0'],T=11,reps=12,B=960)
    meta=engine.provenance(settings)
    meta['targeted_script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    folder=ROOT/'results/current'
    sidecar=folder/'precision_refinement_metadata.json'
    if sidecar.exists() and json.loads(sidecar.read_text()) != meta:
        raise ValueError('Targeted precision settings/source changed; preserve the existing run')
    sidecar.write_text(json.dumps(meta,indent=2),encoding='utf-8')
    signature=hashlib.sha256(json.dumps(meta,sort_keys=True).encode()).hexdigest()[:16]
    cache=ROOT/'work'/('precision_'+signature)
    cache.mkdir(exist_ok=True)
    engine.initialise()
    jobs=[('inner',wn,wi,11,rep,960) for wi,wn in enumerate(engine.WORLDS)
          if wn in settings['worlds'] for rep in range(12)]
    def path(job):return cache/('_'.join(map(str,job))+'.json')
    pending=[j for j in jobs if not path(j).exists()]
    start=time.monotonic()
    print(f'Targeted precision: {len(pending)} pending tasks',flush=True)
    with ProcessPoolExecutor(max_workers=args.workers,initializer=engine.initialise) as pool:
        futures={pool.submit(engine.task,j):j for j in pending}
        for n,future in enumerate(as_completed(futures),1):
            result=future.result()
            tmp=path(futures[future]).with_suffix('.tmp')
            tmp.write_text(json.dumps(result,allow_nan=True),encoding='utf-8')
            tmp.replace(path(futures[future]))
            print(f'{n}/{len(pending)} tasks; {time.monotonic()-start:.0f}s',flush=True)
    rows=[r for j in jobs for r in json.loads(path(j).read_text())]
    pd.DataFrame(rows).to_csv(folder/'precision_refinement_raw.csv',index=False)
    print('Targeted precision diagnostic complete',flush=True)


if __name__=='__main__':
    main()
