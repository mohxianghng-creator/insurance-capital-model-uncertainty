"""E5: decision-rule inputs on the real Danish data, for the interactive interface.
For each frequency model and severity model: plug-in V, bootstrap-predictive V, posterior-predictive V (+ 5-95% intervals);
mixtures (D1) for dAIC cut-offs 2/4/10. Everything the interface shows is read from results/E5_decisions.json."""
import sys, json, time, os, platform
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "src"))
import numpy as np
from cmu import data, severity as S, aggregate as A, frequency as F, uncertainty as U, decision as D, validation as V
from cmu.config import *
RES = Path(os.environ.get("CMU_RESULTS_DIR", ROOT / "results")); RES.mkdir(parents=True, exist_ok=True)
B = int(sys.argv[1]) if len(sys.argv) > 1 else 300
df = data.load_danish(); x = df.loss.to_numpy(); counts = V.annual_counts(df, list(range(1980, 1991)))
fits = U.fit_all(S.default_model_set(), x); aics = np.array([m.aic(x) for m in fits]); dA, wA = D.akaike_weights(aics)
out = {"meta": {"B": B, "seed": SEED, "alpha": ALPHA_VAR, "units": "million DKK", "data": "Danish fire large losses 1980-1990 (evir)", "interval_method": "inverse empirical CDF, including unresolved draws", "grid_ceiling": A.CAP, "python": platform.python_version()}, "freq": {}}
t0 = time.time()
for fname in F.FREQ_NAMES:
    fr = F.make(fname).fit(counts); lam, r = fr.forecast(1), fr.r
    entry = {"lambda": lam, "models": {}}
    mix_boot, mix_post = {}, {}
    for i, m in enumerate(fits):
        rng = np.random.default_rng(np.random.SeedSequence([SEED, 5, i, len(fname)]))
        agg = A.aggregate(m.cdf, lam, r=r)
        bt = U.bootstrap_capital(m, x, counts, fname, B, rng, keep_dists=True)
        pp = U.posterior_capital(m, x, counts, fname, B, rng)
        def q(v): return [float(z) if np.isfinite(z) else None for z in U.capital_quantiles(v)]
        entry["models"][m.name] = dict(AIC=float(aics[i]), dAIC=float(dA[i]), akaike_w=float(wA[i]), plug=float(agg.var(ALPHA_VAR)),
                                       EL=float(agg.mean_S), TVaR99=float(agg.tvar(ALPHA_TVAR)[0]),
                                       boot_pred=float(bt["mixture"].var(ALPHA_VAR)), post_pred=float(pp["mixture"].var(ALPHA_VAR)),
                                       boot_q=q(bt["var"]), post_q=q(pp["var"]),
                                       boot_unresolved_share=float(np.isinf(bt["var"]).mean()), post_unresolved_share=float(np.isinf(pp["var"]).mean()))
        mix_boot[m.name], mix_post[m.name] = bt["mixture"], pp["mixture"]
    entry["D1"] = {}
    for cut in (2.0, 4.0, 10.0):
        idx = [i for i in range(len(fits)) if dA[i] <= cut]; w = wA[idx]
        entry["D1"][f"dAIC{cut:g}"] = dict(boot=float(A.mix([mix_boot[fits[i].name] for i in idx], w).var(ALPHA_VAR)),
                                          post=float(A.mix([mix_post[fits[i].name] for i in idx], w).var(ALPHA_VAR)),
                                          models=[fits[i].name for i in idx])
    out["freq"][fname] = entry; print(fname, time.time() - t0, flush=True)
def json_finite(obj):
    if isinstance(obj, dict): return {k: json_finite(v) for k, v in obj.items()}
    if isinstance(obj, list): return [json_finite(v) for v in obj]
    if isinstance(obj, float) and not np.isfinite(obj): return None
    return obj
(RES / "E5_decisions.json").write_text(json.dumps(json_finite(out), indent=1, allow_nan=False), encoding="utf-8")
