"""Check completeness, provenance and arithmetic of current published evidence."""
import hashlib
import json
import math
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
import numpy as np
import pandas as pd
from cmu.research import wilson
from cmu import data


def main():
    folder = ROOT/'results/current'
    meta = json.loads((folder/'run_metadata.json').read_text())
    checks = []
    def check(name, good):
        checks.append(bool(good))
        print(('PASS ' if good else 'FAIL ') + name)
    for path, digest in meta['sources'].items():
        check('current source: ' + path, hashlib.sha256((ROOT/path).read_bytes()).hexdigest() == digest)
    check('current Danish source hash', hashlib.sha256((ROOT/'data/raw/danish.rda').read_bytes()).hexdigest() == meta['raw_sha256'])
    raw_data = data.load_danish()
    processed = pd.read_csv(ROOT/'data/processed/danish_fire_losses.csv',parse_dates=['date'])
    check('processed Danish data matches validated raw data', len(processed) == len(raw_data) and
          np.array_equal(processed.date.to_numpy(dtype='datetime64[ns]'),raw_data.date.to_numpy(dtype='datetime64[ns]')) and np.allclose(processed.loss,raw_data.loss,rtol=0,atol=1e-12) and
          np.array_equal(processed.year,raw_data.year))
    settings = meta['settings']
    ext_meta = json.loads((folder/'extensions_metadata.json').read_text())
    check('extension sources and both raw datasets', all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest() == h
          for p,h in ext_meta['source_sha256'].items()))
    d = pd.read_csv(folder/'decision_raw.csv')
    c = pd.read_csv(folder/'coverage_raw.csv')
    inner = pd.read_csv(folder/'inner_raw.csv')
    cache_record = folder/'accepted_guard_cache_provenance.json'
    if cache_record.exists():
        migration = json.loads(cache_record.read_text())
        old = migration['old_metadata']
        source = (ROOT/'src/cmu/research.py').read_bytes()
        delta = migration['added_guard_utf8'].encode()
        compatible = source.count(delta) == 1 and hashlib.sha256(source.replace(delta,b'')).hexdigest() == old['sources']['src/cmu/research.py']
        compatible &= all(h == meta['sources'][p] for p,h in old['sources'].items() if p != 'src/cmu/research.py')
        compatible &= migration['new_metadata_sha256'] == hashlib.sha256(json.dumps(meta,sort_keys=True).encode()).hexdigest()
        keys = [k for record in migration['checkpoints'].values() for k in record['keys']]
        published = pd.concat([d,inner],ignore_index=True)
        migrated = pd.DataFrame(keys).merge(published,on=['world','T','rep','B','kind','rule'],suffixes=('_cached','_published'),validate='one_to_one')
        compatible &= len(migrated) == len(keys) and not migrated.capped.any() and (migrated.refinement_change <= .005).all()
        compatible &= np.allclose(migrated.V_cached,migrated.V_published,rtol=1e-14,atol=1e-10)
        check('accepted-cache reuse has exact guard-only equivalence and unchanged finite results', compatible)
    check('decision keys unique', not d.duplicated(['world', 'T', 'rep', 'rule']).any())
    check('all five worlds, both horizons and seven rules', len(d) == settings['reps']*5*2*7 and
          d.groupby(['world','T','rule']).size().eq(settings['reps']).all() and
          d.world.nunique() == 5 and set(d['T']) == {11, 40} and d.rule.nunique() == 7)
    check('truth resolved in every sample', np.isfinite(d.V_true).all() and (d.V_true > 0).all())
    check('censored values retain last ceiling', np.isinf(d.loc[d.capped, 'V']).all() and
          np.isinf(d.loc[d.capped, 'rel_over_upper']).all() and
          np.allclose(d.loc[d.capped, 'rel_over'], np.maximum(d.loc[d.capped, 'ceiling']/d.loc[d.capped, 'V_true']-1, 0)))
    check('accepted expansions meet refinement tolerance', (d.loc[d.expanded & ~d.capped, 'refinement_change'] <= .005).all())
    check('finite breach probabilities valid', d.loc[~d.capped, 'p_breach'].between(0, 1).all())
    check('coverage sample grid complete', len(c) == settings['coverage_reps']*3*2 and
          c.groupby(['world','method']).size().eq(settings['coverage_reps']).all() and
          not c.duplicated(['world','rep','method']).any())
    check('coverage endpoints and event agree', (c.lo <= c.hi).all() and
          (c.covered == ((c.lo <= c.V_true) & (c.V_true <= c.hi))).all())
    check('coverage events identified below censoring ceiling', c.V_true.between(0,16384,inclusive='neither').all())
    check('coverage failures remain visible', ((c.n_success+c.n_failed) == settings['coverage_B']).all() and
          (c.n_success >= np.ceil(.9*settings['coverage_B'])).all())
    cs = pd.read_csv(folder/'coverage_summary.csv')
    coverage_ok = len(cs) == 6
    for r in cs.itertuples():
        g = c[(c.world == r.world)&(c.method == r.method)]
        lo,hi = wilson(int(g.covered.sum()),len(g))
        coverage_ok &= np.allclose([r.coverage,r.ci_lo,r.ci_hi,r.infinite_upper_share],
                                   [g.covered.mean(),lo,hi,g.infinite_upper.mean()])
    check('coverage summary recalculates including Monte Carlo intervals', coverage_ok)
    check('inner sensitivity paired samples complete', len(inner) == settings['inner_reps']*5*7 and
          inner.groupby(['world','rule']).size().eq(settings['inner_reps']).all() and
          inner.B.eq(3*settings['B']).all())
    precision_meta = json.loads((folder/'precision_refinement_metadata.json').read_text())
    precision = pd.read_csv(folder/'precision_refinement_raw.csv')
    check('targeted precision source provenance',
          precision_meta['sources'] == meta['sources'] and
          precision_meta['dependencies'] == meta['dependencies'] and precision_meta['raw_sha256'] == meta['raw_sha256'] and
          precision_meta['targeted_script_sha256'] == hashlib.sha256((ROOT/'scripts/run_precision_refinement.py').read_bytes()).hexdigest())
    check('targeted B960 diagnostic complete',len(precision) == 2*12*7 and precision.B.eq(960).all() and
          precision.groupby(['world','rule']).size().eq(12).all() and
          not precision.duplicated(['world','rep','rule']).any())
    baseline = precision[precision.rule == 'D0_aic_plugin'].merge(d[(d.rule == 'D0_aic_plugin')&(d['T'] == 11)],
          on=['world','T','rep','rule'],suffixes=('_high','_base'),validate='one_to_one')
    check('targeted refits preserve fixed-data plugin baseline',len(baseline) == 24 and np.array_equal(baseline.V_high,baseline.V_base))
    precision_summary = pd.read_csv(folder/'precision_refinement_summary.csv')
    triples = precision.merge(inner[['world','T','rep','rule','V']].rename(columns={'V':'V240'}),
          on=['world','T','rep','rule'],validate='one_to_one').merge(
          d[d['T'] == 11][['world','T','rep','rule','V']].rename(columns={'V':'V80'}),
          on=['world','T','rep','rule'],validate='one_to_one')
    precise = len(precision_summary) == 14
    for r in precision_summary.itertuples():
        g = triples[(triples.world == r.world)&(triples.rule == r.rule)]
        good = np.isfinite(g.V)&np.isfinite(g.V240)&np.isfinite(g.V80)
        a = (g.loc[good,'V80']-g.loc[good,'V']).abs()/g.loc[good,'V']
        b = (g.loc[good,'V240']-g.loc[good,'V']).abs()/g.loc[good,'V']
        precise &= r.finite_triples == int(good.sum()) and r.n_pairs == len(g)
        precise &= np.allclose([r.median_change_80_to_960,r.median_change_240_to_960,r.maximum_change_240_to_960],
                               [a.median(),b.median(),b.max()],equal_nan=True)
    check('targeted precision summary recalculates',precise)
    s = pd.read_csv(folder/'decision_summary.csv')
    check('decision summary complete', len(s) == 70)
    summary_ok = True
    for r in s.itertuples():
        g = d[(d.world == r.world) & (d['T'] == r.T) & (d.rule == r.rule)]
        lo, hi = wilson(int(g.shortfall.sum()), len(g))
        summary_ok &= np.allclose([r.p_shortfall, r.loss_r3, r.shortfall_ci_lo, r.shortfall_ci_hi],
                                  [g.shortfall.mean(), (3*g.rel_under+g.rel_over).mean(), lo, hi])
    check('summary recalculates from raw samples', summary_ok)
    costs = pd.read_csv(folder/'finite_treaty_costs.csv')
    check('finite-layer mean and cost arithmetic', np.allclose(costs.annual_cost,
          costs.funding_rate*costs.K_econ+costs.premium-costs.expected_recovery) and
          np.allclose(costs.upfront_resource, costs.V995+costs.premium))
    action_ok = True
    actions = pd.read_csv(folder/'finite_treaty_decisions.csv')
    for r in actions.itertuples():
        g = costs[(costs.pricing_model == r.pricing_model) & np.isclose(costs.loading,r.loading) & np.isclose(costs.funding_rate,r.funding_rate)]
        allowed = g.groupby('action').upfront_resource.max()
        allowed = allowed[allowed <= r.resource_budget].index
        action_ok &= len(allowed) == r.feasible_actions
        if r.selected_action == 'NO_FEASIBLE_ACTION':
            action_ok &= len(allowed) == 0
        else:
            feasible = g[g.action.isin(allowed)].copy()
            feasible['regret'] = feasible.annual_cost-feasible.groupby(['severity','freq']).annual_cost.transform('min')
            score = feasible.groupby('action').agg(worst_regret=('regret','max'),worst_annual_cost=('annual_cost','max')).reset_index()
            winner = score.sort_values(['worst_regret','worst_annual_cost','action']).iloc[0]
            action_ok &= r.selected_action == winner.action and np.isclose(r.worst_regret,winner.worst_regret)
    check('finite-layer constrained minimax regret independently recalculates', action_ok)
    bounds = pd.read_csv(folder/'finite_treaty_boundaries.csv')
    boundary_ok = len(bounds) == 2*7*3
    for r in bounds.itertuples():
        g = costs[(costs.pricing_model == r.pricing_model)&(costs.action == r.action)&
                  np.isclose(costs.loading,.3)&np.isclose(costs.funding_rate,.06)]
        quote = float(g.premium.iloc[0]/1.3)
        boundary_ok &= np.isclose(g.V995.max()+(1+r.max_loading_feasible_all_views)*quote,r.resource_budget)
    check('finite-layer budget boundaries recalculate', boundary_ok)
    nd = pd.read_csv(folder/'norwegian_diagnostics.csv')
    check('Norwegian diagnostics complete and uniquely keyed', len(nd) == 4*5*5*3 and
          not nd.duplicated(['origin','scenario','severity','freq']).any())
    stress = pd.read_csv(folder/'stress_target_diagnostics.csv')
    interior = stress[~stress.already_at_lower_bound & np.isfinite(stress.achieved_strict_breach)]
    check('reverse-stress strict exceedance agrees within lattice/root tolerance', len(stress) == 84 and
          (interior.achieved_strict_breach <= interior.target+1e-3).all() and
          (interior.preceding_cell_breach >= interior.target-1e-3).all())
    check('generated report and figures present', all((ROOT/p).exists() for p in [
        'paper/current_validation.md','paper/figures/F6_current_coverage.png',
        'paper/figures/F7_current_decisions.png','paper/figures/F8_norwegian_diagnostics.png']))
    def clean(obj):
        if isinstance(obj,dict): return {k:clean(v) for k,v in obj.items()}
        if isinstance(obj,list): return [clean(v) for v in obj]
        if isinstance(obj,float) and not math.isfinite(obj): return None
        return obj
    html = (ROOT/'app/decision_explorer.html').read_text(encoding='utf-8')
    embedded = json.loads(html.split('const DATA=',1)[1].split(';\nconst $=',1)[0]).get('current')
    expected = dict(settings=settings,coverage=cs.to_dict('records'),
                    decisions=s.to_dict('records'),treaties=actions.to_dict('records'))
    check('explorer current evidence exactly matches saved summaries',embedded == clean(expected))
    report = (ROOT/'app/evidence_report.html').read_text(encoding='utf-8')
    check('offline report contains every current coverage estimate',all(f'{r.coverage:.1%}' in report for r in cs.itertuples()))
    print(f'{sum(checks)}/{len(checks)} current-evidence checks passed')
    return int(not all(checks))


if __name__ == '__main__':
    raise SystemExit(main())
