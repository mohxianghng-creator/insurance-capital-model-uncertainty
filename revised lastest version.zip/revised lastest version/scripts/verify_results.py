"""Cross-check artefacts against source data, the current engine and the explorer.
Integrity and reproducibility checks do not establish statistical calibration.
"""
import hashlib, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
import numpy as np
import pandas as pd
from cmu import data, data_norfire as N, severity as S, frequency as F, aggregate as A, validation as V
R = ROOT / 'results'

def main():
    checks = []
    def check(label, value):
        checks.append((label, bool(value)))
        print(('PASS ' if value else 'FAIL ') + label)
    original = (A.H, A.NX, A.NS)
    e5 = json.loads((R / 'E5_decisions.json').read_text(encoding='utf-8'))
    try:
        for name, loader, filename, grid in (
                ('danish', data.load_danish, 'E1_capital_by_model.csv', (.5, 2**15, 2**17)),
                ('norfire', N.load_norfire, 'E6_capital_by_model.csv', (.5, 2**17, 2**19))):
            A.set_grid(*grid)
            df = loader()
            check(name + ' raw data', len(df) == (2167 if name == 'danish' else 5433))
            counts = V.annual_counts(df, range(int(df.year.min()), int(df.year.max())+1))
            fits = {m.name: m.fit(df.loss.to_numpy()) for m in S.default_model_set()}
            saved = pd.read_csv(R / filename)
            check(name + ' complete model grid', len(saved) == 15 and not saved.duplicated(['severity', 'freq']).any())
            ve, me, ue = [], [], []
            for row in saved.itertuples():
                f = F.make(row.freq).fit(counts)
                d = A.aggregate(fits[row.severity].cdf, f.forecast(1), r=f.r)
                ve.append(abs(row.V995-d.var(.995)))
                me.append(abs(row.EL-d.mean_S))
                if name == 'danish':
                    ue.append(abs(e5['freq'][row.freq]['models'][row.severity]['plug']-row.V995))
            check(name + ' recomputed capital', max(ve) < 1e-8)
            check(name + ' uncapped expected losses', max(me) < 1e-7)
            if name == 'danish':
                check('explorer plugin capital', max(ue) < 1e-8)
                meta = json.loads((R / 'run_meta.json').read_text())
                check('paper baseline 1298 and B300', meta['K0'] == 1298 and meta['B'] == 300)
                e4 = pd.read_csv(R / 'E4_reverse_stress.csv')
                errors = []
                for row in e4.itertuples():
                    f = F.make(row.freq).fit(counts)
                    d = A.aggregate(fits[row.severity].cdf, f.forecast(1), r=f.r)
                    errors.append(abs(row.breach_prob_at_K0-d.breach_prob(row.K0)))
                check('reverse stress probabilities', max(errors) < 1e-8)
            else:
                meta = json.loads((R / 'E6_meta.json').read_text())
                best = min(fits.values(), key=lambda m: m.aic(df.loss.to_numpy()))
                check('Norwegian AIC baseline', meta['baseline'] == best.name == 'Spliced5')
    finally:
        A.set_grid(*original)
    intervals_ok = True
    for e in e5['freq'].values():
        for m in e['models'].values():
            for method in ('boot', 'post'):
                q = [np.inf if x is None else x for x in m[method+'_q']]
                intervals_ok &= all(a <= b for a, b in zip(q, q[1:]))
                intervals_ok &= 0 <= m[method+'_unresolved_share'] <= 1
    check('explorer intervals retain unresolved draws', intervals_ok)
    html = (ROOT / 'app/decision_explorer.html').read_text(encoding='utf-8')
    embedded = json.loads(html.split('const DATA=', 1)[1].split(';\nconst $=', 1)[0])
    check('explorer matches current E5', embedded['freq'] == e5['freq'] and embedded['meta'] == e5['meta'])
    check('no automatic recommendation', 'function recommend(' not in html and 'evidence-based default' not in html)
    provenance = json.loads((R / 'simulation_provenance.json').read_text())
    for name, n in [('sim2_T11.csv', 150), ('sim2_T40.csv', 30), ('sim3_post_T11.csv', 60)]:
        p = R / name; d = pd.read_csv(p)
        good = not d.duplicated(['world', 'T', 'rep', 'rule']).any()
        good &= d.groupby(['world', 'rule']).size().eq(n).all() and d.world.nunique() == 5
        good &= hashlib.sha256(p.read_bytes()).hexdigest() == provenance[name]['sha256']
        check(name + ' samples and provenance', good)
    bounds = pd.read_csv(R / 'SIM_loss_bounds.csv')
    check('censored losses have unbounded upper endpoints', np.isinf(bounds.loc[bounds.censored_share > 0, 'loss_upper']).all())
    check('uncensored losses have matching endpoints', np.allclose(bounds.loc[bounds.censored_share == 0, 'loss_lower'], bounds.loc[bounds.censored_share == 0, 'loss_upper']))
    grid = pd.read_csv(R / 'numerical_convergence.csv')
    dev = grid.filter(like='relative_change').to_numpy()
    check('30 fitted quantiles converge within 1 percent', len(grid) == 30 and np.isfinite(dev).all() and np.max(dev) <= .01)
    prior = pd.read_csv(R / 'prior_sensitivity.csv')
    check('prior/grid sensitivity complete', len(prior) == 16 and prior.groupby(['dataset', 'severity']).size().eq(4).all())
    paper = (ROOT / 'paper/paper.md').read_text(encoding='utf-8')
    danish_section = paper.split('### 6.2', 1)[1].split('### 6.3', 1)[0]
    nor_section = paper.split('### 6.7', 1)[1].split('### 6.8', 1)[0]
    fmt = lambda x: f'{x:,.0f}'
    dr = pd.read_csv(R / 'E2_rolling_origin.csv')
    dc = dr[dr.freq == 'PoissonConst']
    nr = pd.read_csv(R / 'E6_rolling_origin.csv')
    nb = nr[(nr.freq == 'PoissonConst') & (nr.severity == 'Spliced5')]
    check('paper Danish OOS scope and range', f'{fmt(dc.V995.min())}–{fmt(dc.V995.max())}' in danish_section)
    check('paper Norwegian baseline OOS range', f'{fmt(nb.V995.min())}–{fmt(nb.V995.max())}' in nor_section)
    ec = pd.read_csv(R / 'E6_capital_by_model.csv')
    sp20 = ec[(ec.freq == 'PoissonConst') & (ec.severity == 'Spliced20')].iloc[0]
    check('paper unresolved-preserving posterior interval', f'{fmt(sp20.post_p05)}–{fmt(sp20.post_p95)}' in nor_section)
    tail_break = bounds[(bounds.world.str.startswith('W4')) & (bounds.ratio == 3)]
    range_text = f'{100*tail_break.p_estimate_below_truth.min():.0f}–{100*tail_break.p_estimate_below_truth.max():.0f}%'
    check('paper tail-break range includes every saved rule', range_text in paper)
    failed = [name for name, good in checks if not good]
    print(f'{len(checks)-len(failed)}/{len(checks)} integrity checks passed')
    return int(bool(failed))

if __name__ == '__main__':
    sys.exit(main())
