"""Build an offline HTML evidence report using saved current-study outputs."""
import base64
from html import escape
import json
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
R = ROOT/'results/current'


def table(df):
    label = escape('Evidence table: '+', '.join(str(c) for c in list(df.columns)[:2]))
    return '<div class="scroll" tabindex="0" role="region" aria-label="'+label+'">'+df.to_html(index=False, border=0, escape=True, na_rep='Unresolved')+'</div>'


def figure(name, caption):
    content = base64.b64encode((ROOT/'paper/figures'/name).read_bytes()).decode()
    return '<figure><img alt="'+escape(caption)+'" src="data:image/png;base64,'+content+'"><figcaption>'+escape(caption)+'</figcaption></figure>'


def main():
    meta = json.loads((R/'run_metadata.json').read_text())
    settings = meta['settings']
    danish = pd.read_csv(ROOT/'results/E1_capital_by_model.csv')
    norwegian_capital = pd.read_csv(ROOT/'results/E6_capital_by_model.csv')
    nc = norwegian_capital[norwegian_capital.freq == 'PoissonConst']
    danish_range = danish.V995.max()/danish.V995.min()
    norwegian_range = nc.V995.max()/nc.V995.min()
    coverage = pd.read_csv(R/'coverage_summary.csv')
    decisions = pd.read_csv(R/'decision_summary.csv')
    paired = pd.read_csv(R/'decision_paired.csv')
    inner = pd.read_csv(R/'inner_sensitivity.csv')
    refined = pd.read_csv(R/'precision_refinement_summary.csv')
    norwegian = pd.read_csv(R/'norwegian_diagnostics.csv')
    treaty = pd.read_csv(R/'finite_treaty_decisions.csv')
    boundaries = pd.read_csv(R/'finite_treaty_boundaries.csv')
    cov = pd.DataFrame({'World':coverage.world.str.split('_').str[0], 'Method':coverage.method,
        'Coverage':coverage.coverage.map(lambda x:f'{x:.1%}'),
        '95% Monte Carlo interval':[f'[{a:.1%}, {b:.1%}]' for a,b in zip(coverage.ci_lo,coverage.ci_hi)],
        'Infinite upper endpoint':coverage.infinite_upper_share.map(lambda x:f'{x:.1%}'),
        'Median width ratio':coverage.median_width_ratio.map(lambda x:f'{x:.2f}' if pd.notna(x) and x != float('inf') else 'Unresolved (censored)')})
    selected = paired[(paired['T'] == 11)&(paired.ratio == 3)&paired.rule.isin(['D1_bma_mixture','D3_hurwicz_0.5','D3_hurwicz_0.75'])]
    pair_table = pd.DataFrame({'World':selected.world.str.split('_').str[0], 'Rule':selected.rule,
        'Mean relative loss difference vs D0':[f'{lo:.3f}' if ok else f'[{lo:.3f}, {hi:.3f}] (bounds)'
            for lo,hi,ok in zip(selected.mean_diff_lower,selected.mean_diff_upper,selected.identified)],
        '95% paired resampling interval':[f'[{a:.3f}, {b:.3f}]' if ok else 'Unidentified: censored' for a,b,ok in zip(selected.ci_lo,selected.ci_hi,selected.identified)]})
    inn = inner[inner.rule.isin(['D1_bma_mixture','D3_hurwicz_0.5','D3_hurwicz_0.75'])].copy()
    inn = pd.DataFrame({'World':inn.world.str.split('_').str[0], 'Rule':inn.rule,
                       'Median capital change':inn.median_relative_change.map(lambda x:f'{x:.1%}'),
                       'Largest change':inn.maximum_relative_change.map(lambda x:f'{x:.1%}')})
    refine_table = refined[refined.rule.isin(['D1_bma_mixture','D3_hurwicz_0.5','D3_hurwicz_0.75'])].copy()
    refine_table = pd.DataFrame({'World':refine_table.world.str.split('_').str[0],'Rule':refine_table.rule,
        'Median B80 to B960':refine_table.median_change_80_to_960.map(lambda x:f'{x:.1%}'),
        'Median B240 to B960':refine_table.median_change_240_to_960.map(lambda x:f'{x:.1%}'),
        'Maximum B240 to B960':refine_table.maximum_change_240_to_960.map(lambda x:f'{x:.1%}'),
        'Finite triples':[f'{a}/{b}' for a,b in zip(refine_table.finite_triples,refine_table.n_pairs)]})
    n = norwegian[(norwegian.severity == 'Spliced5')&(norwegian.freq == 'PoissonConst')]
    nr = []
    for scenario,g in n.groupby('scenario'):
        label={'full_history':'Full history','remove_largest':'Largest claim removed',
               'remove_largest_three':'Three largest removed','recent_severity_three_years':'Recent severity (3 years)',
               'recent_frequency_three_years':'Recent frequency (3 years)'}[scenario]
        nr.append({'Diagnostic':label,'Median forecast VaR / annual loss':round((g.V995/g.realised_S).median(),2),
                   'Annual PIT range':f'{g.pit_S.min():.4f}–{g.pit_S.max():.4f}'})
    t = treaty[treaty.funding_rate == .06].copy()
    t = t[['pricing_model','loading','resource_budget','feasible_actions','selected_action','worst_regret']]
    t['loading'] = t.loading.map(lambda x:f'{x:.0%}')
    t['worst_regret'] = t.worst_regret.map(lambda x:f'{x:.2f}' if pd.notna(x) else 'Not applicable')
    t['selected_action'] = t.selected_action.map(lambda x:'No feasible action' if x == 'NO_FEASIBLE_ACTION' else 'No cover' if x == 'none' else x.replace('_xs_','m xs ')+'m')
    t['resource_budget'] = t.resource_budget.map(lambda x:f'{x:,.0f}')
    t.columns = ['Pricing view','Loading','Resource budget','Feasible actions','Conditional action','Worst regret']
    html = '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Capital decisions — evidence and limits</title><style>
:root{color-scheme:light;--ink:#182c42;--muted:#536475;--teal:#076d74;--line:#d9e1e8;--bg:#f5f7fa}*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.65 system-ui,-apple-system,"Segoe UI",sans-serif}main{max-width:1120px;margin:auto;padding:32px 24px 70px}
header{padding:34px;background:#182c42;color:white;border-radius:12px}header p{max-width:820px;color:#dbe6ef}h1{font-size:clamp(28px,4vw,44px);line-height:1.15;margin:10px 0 18px;letter-spacing:-.025em}h2{font-size:24px;margin-top:0}h3{font-size:17px}
.eyebrow{font-size:12px;letter-spacing:.12em;text-transform:uppercase}.status{display:inline-block;border:1px solid #8197a9;border-radius:20px;padding:4px 12px;font-size:12px}
nav{display:flex;flex-wrap:wrap;gap:18px;margin:22px 0}a{color:var(--teal)}section{background:white;border:1px solid var(--line);border-radius:12px;padding:26px;margin:20px 0;scroll-margin-top:20px}
.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:20px}.metric{padding:18px;background:#edf4f6;border-radius:8px}.metric strong{display:block;font-size:28px;color:var(--teal)}.metric span,figcaption,.small{font-size:13px;color:var(--muted)}
.notice{border-left:4px solid #ae7431;padding:12px 18px;background:#fff8ec}.scroll{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:12px;line-height:1.45;font-variant-numeric:tabular-nums}th,td{padding:10px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap}th{background:#edf3f6;color:var(--ink)}th:first-child,td:first-child{text-align:left}figure{margin:22px 0}img{max-width:100%;height:auto}code{font-size:.88em;background:#edf2f6;padding:2px 5px;border-radius:3px}li{margin:8px 0}
@media(max-width:650px){main{padding:14px}header,section{padding:20px}.cards{grid-template-columns:1fr}h2{font-size:21px}}@media print{body{background:white}main{padding:0}header{background:white;color:var(--ink);border:1px solid var(--line)}header p{color:var(--ink)}section{break-inside:avoid}nav{display:none}table{font-size:9px}a{color:inherit}}
</style></head><body><main>'''
    html += f'''<header><div class="eyebrow">Decision-focused actuarial research · version 0.5</div>
<h1>Capital decisions when credible models disagree</h1><p>Two real fire-loss datasets, fresh synthetic validation, and finite-layer reinsurance decisions under explicit resource constraints.</p>
<span class="status">Portfolio case study · no institutional approval claimed</span></header>
<nav aria-label="Report sections"><a href="decision_explorer.html">Interactive explorer</a><a href="#coverage">Calibration</a><a href="#decisions">Decision evidence</a><a href="#diagnostics">Norwegian diagnostics</a><a href="#actions">Reinsurance actions</a><a href="#reproduce">Reproduce</a></nav>
<div class="cards"><div class="metric"><strong>{danish_range:.2f}×</strong><span>Danish capital range across 15 severity / frequency choices</span></div>
<div class="metric"><strong>{norwegian_range:.1f}×</strong><span>Norwegian capital range across five severity choices</span></div>
<div class="metric"><strong>{len(treaty)}</strong><span>pricing / funding / resource-budget decision cases</span></div></div>
<section><h2>The decision and the evidence boundary</h2><p>The annual resource level is VaR at 99.5%. Economic capital above expected retained loss is reported separately. Public large-loss records support a transparent case study; they do not reconstruct a complete insurer or regulatory SCR.</p>
<p>The central trade-off is the cost of capital shortfalls versus excess capital. Predictive mixtures and conservative rules can move both outcomes. AIC weights, candidate cutoffs, prices and cost preferences remain stated assumptions.</p>
<div class="notice">A numerically resolved quantile is not a statistically calibrated capital policy. B=80 capital-rule comparisons remain exploratory because inner-refit sensitivity is material in some samples. Read coverage, precision, censoring and costs together. There is no automatic winning capital rule.</div></section>'''
    html += '<section id="coverage"><h2>1. Current interval calibration</h2><p>The revised interval algorithm retains unresolved draws. Coverage is measured under three known synthetic tail worlds; infinite endpoints and interval width remain visible.</p>'+table(cov)
    largest_censor=coverage[coverage.method=='semi_bayesian'].infinite_upper_share.max()
    html += '<p>Bootstrap under-coverage remains visible in the two heavier-tail worlds. For the semi-Bayesian method, up to '+f'{largest_censor:.1%}'+' of upper endpoints exceed the base grid; the heaviest-world median interval width is therefore unresolved. Nominal coverage alone does not establish a useful or stable interval.</p>'
    html += figure('F6_current_coverage.png','Nominal coverage is 90%. Error bars quantify finite-replication uncertainty, not uncertainty about a real insurer.')
    html += '<p class="small">Every known true quantile lies below the base numerical ceiling, so the coverage event remains identified even when an endpoint is censored above it; interval width then remains partially identified. The infinite marker denotes unresolved numerical capital. Semi-Bayesian credible intervals and bootstrap intervals have different interpretations. A nominal rate lying inside a Monte Carlo interval does not certify calibration.</p></section>'
    html += '<section id="decisions"><h2>2. Decision costs and shortfall risk</h2><p>All rules use the same training sample within a replication. The figure shows the probability an estimated capital is below the known true quantile; this is distinct from an annual claim-loss breach.</p>'
    html += figure('F7_current_decisions.png','T=11 and T=40; five known worlds. W4 changes the tail regime beyond the sample-supported region.')
    html += '<h3>Paired cost comparisons: T=11, shortfall/excess cost ratio 3</h3><p>Negative differences favour the indicated rule relative to D0 under this particular cost. Intervals resample the finite paired losses, are pointwise and have no multiplicity adjustment. They can miss rare extremes; coverage is not established when loss moments are uncontrolled. Finite quantiles do not establish existence of population mean or variance of decision cost. These are exploratory diagnostics.</p>'+table(pair_table)
    html += '<h3>Inner refit precision</h3><p>These fixed samples compare B='+str(settings['B'])+' with B='+str(3*settings['B'])+'. Twelve paired samples per world are a diagnostic. Differences of similar magnitude should not drive a recommendation; heavy-tailed mean costs may require substantially more simulation.</p>'+table(inn)
    html += '<h3>Targeted B=960 check</h3><p>W1/W4 were selected after inspecting the initial precision diagnostic. The same twelve samples per world receive B=960. This supplements the main experiment; it does not replace selected rows or establish an unbiased new ranking. Relative changes use only finite triples, with their count shown. B=80 cost comparisons remain exploratory. Finite-treaty costs below use deterministic fitted distributions and a separate objective.</p>'+table(refine_table)+'</section>'
    html += '<section id="diagnostics"><h2>3. Explaining the Norwegian failure case</h2><p>The Spliced5/constant-Poisson family is held fixed. Largest-claim deletion changes severity only; annual counts are preserved. Recent severity and frequency windows are changed separately.</p>'+table(pd.DataFrame(nr))
    html += figure('F8_norwegian_diagnostics.png','Claim deletion measures influence. It does not establish causality or justify excluding valid extreme losses.')
    html += '<p>Four forecast years cannot validate the 0.5% annual tail. Exposure, inflation and reporting-threshold effects remain unidentified. The diagnostic documents a failure to explain fully, rather than hiding it.</p></section>'
    html += '<section id="actions"><h2>4. Finite-layer actions and capital feasibility</h2><p>Eight actions include no cover and seven finite per-occurrence layers. Losses above exhaustion return to the insurer. A resource budget funds net VaR plus premium paid upfront in every one of nine plausible severity/frequency views.</p><p>The common feasible action set is formed first; a minimax-regret action is then selected within it. The table holds the annual funding cost at 6%; the explorer also covers 3% and 12%.</p>'+table(t)
    b = boundaries[(boundaries.action.isin(['500_xs_20','250_xs_50']))&(boundaries.resource_budget.isin([1750,2500]))].copy()
    b['action'] = b.action.map(lambda x:x.replace('_xs_','m xs ')+'m')
    b['resource_budget'] = b.resource_budget.map(lambda x:f'{x:,.0f}')
    b['max_loading_feasible_all_views'] = b.max_loading_feasible_all_views.map(lambda x:f'{x:.1%}' if x >= 0 else 'None at loading ≥ 0')
    b['max_loading_cost_no_greater_than_none_all_views'] = b.max_loading_cost_no_greater_than_none_all_views.map(lambda x:f'{x:.1%}' if x >= 0 else 'None at loading ≥ 0')
    b.columns = ['Pricing view','Layer','Resource budget','Maximum loading: budget feasible','Maximum loading: cost <= no cover in all views']
    html += '<h3>What quotation would change the decision?</h3><p>The boundaries below make pricing sensitivity actionable. A negative budget boundary means even a zero-loading quotation exceeds available resources in at least one risk view. Comparing a layer with no cover does not establish optimality against all other layers.</p>'+table(b)
    html += '<p class="notice">These are conditional quotation-screening decisions. Quotes are assumed; actual terms, recovery delays, default, reinstatements and aggregate limits must be assessed before a real purchase.</p></section>'
    html += f'''<section id="reproduce"><h2>5. Reproducibility and remaining work</h2><p>The fresh study contains {settings['reps']*5*2:,} decision samples across five worlds and two horizons, plus {settings['coverage_reps']*3:,} coverage samples evaluated by both interval methods. Python {escape(meta['python'])}; pinned dependencies and seeded independent process tasks. Expanded predictive quantiles are recomputed up to a ceiling of 2,097,152 and must pass a halved-step comparison within 0.5%. Source hashes and raw-data hashes are checked.</p>
<p>Coverage and decision experiments reuse matching T=11 data-sample IDs; the counts describe analysis cases rather than disjoint datasets across experiments. Inner-refit sensitivity also holds the training samples fixed.</p>
<p><code>python scripts/reproduce.py verify</code> checks tests, current and empirical evidence, and the file inventory. <code>python scripts/reproduce.py all</code> rebuilds both empirical and synthetic studies; this is a substantial compute job.</p>
<ul><li>All synthetic decision worlds use Poisson frequency and are anchored to one dataset.</li><li>Claim-level iid bootstrap does not reconstruct event clustering or changing exposure.</li><li>Candidate-set robustness cannot insure against every unseen tail regime.</li><li>Real pricing, actual portfolio data, independent challenge and an agreed decision objective remain necessary for institutional use.</li></ul>
<p><a href="../paper/current_validation.md">Generated technical report</a> · <a href="../paper/paper.md">Research paper</a> · <a href="../docs/VALIDATION.md">Validation criteria</a> · <a href="../docs/MODEL_CARD.md">Model card</a></p></section>
<footer class="small">Generated from saved current-engine outputs. Historical simulation files remain separately labelled. No external reviewer, client sign-off or employment outcome is implied.</footer></main></body></html>'''
    (ROOT/'app/evidence_report.html').write_text(html, encoding='utf-8')
    print('Offline evidence report built')


if __name__ == '__main__':
    main()
