"""E6: the same engine on a second, independent real dataset (Norwegian fire 1985-92)."""
import sys, json, time, os, platform
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "src"))
import numpy as np, pandas as pd
from cmu import data_norfire as N, severity as S, aggregate as A, frequency as F, uncertainty as U, decision as D, stress as ST, validation as V
from cmu.config import ALPHA_VAR, ALPHA_TVAR, SEED, DELTA_AIC_PLAUSIBLE
B = int(sys.argv[1]) if len(sys.argv) > 1 else 150
RES = Path(os.environ.get("CMU_RESULTS_DIR", ROOT / "results")); t0 = time.time(); RES.mkdir(parents=True, exist_ok=True)
cap = A.set_grid(0.5, 2 ** 17, 2 ** 19)
d = N.load_norfire(); card = N.validate(d); (RES / "E6_data_card.json").write_text(json.dumps(
    {"source": N.SOURCE_URL, "md5": N.EXPECTED_MD5, "licence": "GPL>=2 (CASdatasets)", "retrieved": "2026-10-18",
     "units": "threshold units (1 unit = 500k NOK nominal)", "cap_units": cap, "validation": card,
     "limitations": ["unknown company; priority 500k NOK nominal", "nominal losses: inflation drift (median 1000->~1100)", "no exposure",
                     "8 annual observations in the window", "tail heavy: xi~0.6-0.8, capital approaches the aggregation cap for some models"]}, indent=1))
x = d.loss.to_numpy(); years = list(range(1985, 1993)); counts = V.annual_counts(d, years)
fits = U.fit_all(S.default_model_set(), x); aics = np.array([m.aic(x) for m in fits]); dA, wA = D.akaike_weights(aics); pl = D.plausible_mask(aics, DELTA_AIC_PLAUSIBLE)
rows = []
for fname in F.FREQ_NAMES:
    fr = F.make(fname).fit(counts); lam, r = fr.forecast(1), fr.r
    for i, m in enumerate(fits):
        rng = np.random.default_rng(np.random.SeedSequence([SEED, 6, i, len(fname)]))
        agg = A.aggregate(m.cdf, lam, r=r); v = agg.var(ALPHA_VAR)
        bt = U.bootstrap_capital(m, x, counts, fname, B, rng, keep_dists=True); pp = U.posterior_capital(m, x, counts, fname, B, rng)
        def q(a, p): return float(U.capital_quantiles(a, p))
        rows.append(dict(severity=m.name, freq=fname, lam=lam, AIC=aics[i], dAIC=dA[i], akaike_w=wA[i], plausible=bool(pl[i]), V995=v,
                         EL=agg.mean_S, EL_grid=agg.mean_S_grid, TVaR99=agg.tvar(ALPHA_TVAR)[0], tvar_reliable=agg.tvar(ALPHA_TVAR)[1], boot_p05=q(bt["var"], .05), boot_p95=q(bt["var"], .95), boot_pred=bt["mixture"].var(ALPHA_VAR),
                         post_p05=q(pp["var"], .05), post_p95=q(pp["var"], .95), post_pred=pp["mixture"].var(ALPHA_VAR),
                         boot_inf_share=float(1 - np.isfinite(bt["var"]).mean()), post_inf_share=float(1 - np.isfinite(pp["var"]).mean())))
    print(fname, f"{time.time()-t0:.0f}s", flush=True)
e6 = pd.DataFrame(rows); e6.to_csv(RES / "E6_capital_by_model.csv", index=False)
# reverse stress at the conventional capital (AIC-best, Poisson const)
best = fits[int(np.argmin(aics))]; fr0 = F.PoissonConst().fit(counts); lam0 = fr0.forecast(1)
K0 = A.aggregate(best.cdf, lam0).var(ALPHA_VAR); st = []
for m, plb in zip(fits, pl):
    agg = A.aggregate(m.cdf, lam0); bp = agg.breach_prob(K0) if np.isfinite(K0) else np.nan
    st.append(dict(severity=m.name, plausible=bool(plb), K0=K0, breach_prob_at_K0=bp, return_period=(1 / bp if bp and bp > 0 else np.inf),
                   phi_p05=ST.breakeven(m, lam0, K0, "phi", alpha=0.95), s_p05=ST.breakeven(m, lam0, K0, "s", alpha=0.95),
                   dxi_p05=(ST.breakeven(m, lam0, K0, "dxi", alpha=0.95) if m.has_gpd_tail else np.nan)))
pd.DataFrame(st).to_csv(RES / "E6_reverse_stress.csv", index=False)
# rolling origin (expanding window), origins 1988-1991
ro = V.rolling_origin(d.rename(columns={"loss": "loss"}), first_origin=1988, last_origin=1991, censor_u=10.0)
ro.to_csv(RES / "E6_rolling_origin.csv", index=False)
sc = ro[ro.freq == "PoissonConst"].groupby("severity").agg(logscore=("logscore", "sum"), censored_logscore=("censored_logscore", "sum"),
        exceed_q99=("exceed_q99", "sum"), exceed_q999=("exceed_q999", "sum"), n_test=("n_test", "sum"), breaches=("breach", "sum")).reset_index()
sc["kupiec_p_q99"] = [V.kupiec_pof(int(r.n_test), int(r.exceed_q99), .01)[1] for r in sc.itertuples()]
sc["kupiec_p_q999"] = [V.kupiec_pof(int(r.n_test), int(r.exceed_q999), .001)[1] for r in sc.itertuples()]
sc.to_csv(RES / "E6_scores_by_model.csv", index=False)
(RES / "E6_meta.json").write_text(json.dumps({"B": B, "baseline": best.name, "K0": K0, "runtime_s": time.time() - t0, "cap": cap, "python": platform.python_version(), "interval_method": "inverse empirical CDF; retain +inf", "grid": {"h": A.H, "nx": A.NX, "ns": A.NS}}, indent=1))
print("E6 done", time.time() - t0)
