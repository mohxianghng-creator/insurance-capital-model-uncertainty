"""Fresh, resumable validation with process workers and atomic checkpoints.

python scripts/run_research.py --workers 4
Every task has its own seed; scheduling cannot change samples or fitted draws.
Outputs never append to historical simulation files.
"""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time
from importlib.metadata import version

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
import numpy as np
import pandas as pd
from cmu import aggregate as A, data, severity as S, simulation as SIM, uncertainty as U
from cmu import research as R
from cmu.config import SEED

WORLDS = None
TRUTHS = {}


def initialise():
    global WORLDS
    x = data.load_danish().loss.to_numpy()
    fits = {m.name: m.fit(x) for m in S.default_model_set()}
    WORLDS = SIM.make_worlds(fits)


def task(job):
    # With exponential tilting, circular alias mass is bounded by
    # exp(-16)/(1-exp(-16)) < 1.13e-7. A compact aggregate domain therefore
    # preserves below-ceiling CDFs while avoiding 4x padding in nested runs.
    # Tests compare compact and padded VaRs, including heavier fitted tails.
    with R.grid_context(.5, 2**15, 2**15):
        return evaluate_task(job)


def evaluate_task(job):
    kind, wn, wi, T, rep, B = job
    w = WORLDS[wn]
    key = wn
    if key not in TRUTHS:
        d, vt = SIM.truth_summary(w)
        with R.grid_context(.25, 2**17, 2**19):
            refined = A.aggregate(w['truth'].cdf, w['lam'])
        vf = refined.var(.995)
        if not np.isfinite(vf) or abs(vf - vt) / vf > .005:
            raise RuntimeError('DGP quantile fails grid refinement')
        TRUTHS[key] = (refined, vf)
    dtrue, vt = TRUTHS[key]
    rng = np.random.default_rng(np.random.SeedSequence([SEED, 2026, wi, T, rep]))
    counts = rng.poisson(w['lam'], T)
    x = SIM.draw_claims(w['truth'], int(counts.sum()), rng)
    fit_rng = np.random.default_rng(np.random.SeedSequence([SEED, 2027, wi, T, rep]))
    if kind in ('decision', 'inner'):
        values, diags = R.current_decisions(x, counts, fit_rng, B=B)
        rows = []
        for rule, v in values.items():
            diag = diags[rule]
            finite = bool(np.isfinite(v))
            lower = v if finite else diag['ceiling']
            # A censored result beyond the old grid must not be rescored at 16,384.
            under = max(vt - lower, 0) / vt
            over = max(lower - vt, 0) / vt
            if finite:
                if v >= dtrue.cap:
                    nx = 2**18
                    cap = max(2**18, 2**np.ceil(np.log2(v + 1)))
                    with R.grid_context(cap / nx, nx, 4 * nx):
                        truth_for_v = A.aggregate(w['truth'].cdf, w['lam'])
                    breach = truth_for_v.breach_prob(v)
                else:
                    breach = dtrue.breach_prob(v)
            else:
                breach = np.nan
            rows.append(dict(kind=kind, world=wn, T=T, rep=rep, B=B, rule=rule,
                             V=v, V_true=vt, rel_under=under, rel_over=over,
                             rel_over_upper=over if finite else np.inf,
                             p_breach=breach, shortfall=bool(lower < vt), capped=not finite,
                             expanded=diag['expanded'], ceiling=diag['ceiling'],
                             refinement_change=diag['relative_refinement_change']))
        return rows
    m = S.Spliced(10).fit(x)
    boot = U.bootstrap_capital(m, x, counts, 'PoissonConst', B, fit_rng, keep_dists=True)
    post_rng = np.random.default_rng(np.random.SeedSequence([SEED, 2028, wi, T, rep]))
    post = U.posterior_capital(m, x, counts, 'PoissonConst', B, post_rng)
    rows = []
    for method, result in [('bootstrap', boot), ('semi_bayesian', post)]:
        lo, hi = U.capital_quantiles(result['var'], [.05, .95])
        rows.append(dict(world=wn, T=T, rep=rep, B=B, method=method, V_true=vt,
                         lo=lo, hi=hi, covered=bool(lo <= vt <= hi),
                         width_ratio=hi / lo, infinite_upper=bool(np.isinf(hi)),
                         unresolved_share=float(np.isinf(result['var']).mean()),
                         n_success=result['n_success'], n_failed=result['n_failed']))
    return rows


def provenance(settings):
    sources = sorted((ROOT / 'src/cmu').glob('*.py')) + [Path(__file__)]
    return dict(settings=settings, python=platform.python_version(),
                dependencies={k: version(k) for k in ('numpy', 'scipy', 'pandas', 'rdata')},
                sources={p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
                raw_sha256=hashlib.sha256(data.RAW.read_bytes()).hexdigest(),
                seed_scheme='SeedSequence([SEED, stream, world_index, T, rep]); streams 2026/2027/2028',
                numerical_policy='tilt16 compact NS=NX; alias mass bound <1.13e-7; unresolved quantiles expand to 2^21, halve step, require <=0.5% change')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--workers', type=int, default=4)
    p.add_argument('--reps', type=int, default=150)
    p.add_argument('--coverage-reps', type=int, default=200)
    p.add_argument('--B', type=int, default=80)
    p.add_argument('--coverage-B', type=int, default=200)
    p.add_argument('--inner-reps', type=int, default=12)
    p.add_argument('--output', default='results/current')
    args = p.parse_args()
    if min(v for v in vars(args).values() if isinstance(v, int)) < 1:
        p.error('all settings must be positive')
    settings = {k: v for k, v in vars(args).items() if k not in ('workers', 'output')}
    meta = provenance(settings)
    out = (ROOT / args.output).resolve()
    if not out.is_relative_to(ROOT):
        raise ValueError('research outputs must stay inside the project')
    out.mkdir(parents=True, exist_ok=True)
    sidecar = out / 'run_metadata.json'
    if sidecar.exists() and json.loads(sidecar.read_text()) != meta:
        raise ValueError('Current-study engine/settings changed. Preserve this run and choose a new results directory.')
    sidecar.write_text(json.dumps(meta, indent=2), encoding='utf-8')
    signature = hashlib.sha256(json.dumps(meta, sort_keys=True).encode()).hexdigest()[:16]
    cache = ROOT / 'work' / ('checkpoints_' + signature)
    cache.mkdir(parents=True, exist_ok=True)
    initialise()
    jobs = []
    for wi, wn in enumerate(WORLDS):
        for T in (11, 40):
            jobs += [('decision', wn, wi, T, rep, args.B) for rep in range(args.reps)]
        if wn.startswith(('W2', 'W3', 'W5')):
            jobs += [('coverage', wn, wi, 11, rep, args.coverage_B) for rep in range(args.coverage_reps)]
        jobs += [('inner', wn, wi, 11, rep, 3 * args.B) for rep in range(args.inner_reps)]
    def path(job):
        return cache / ('_'.join(str(j) for j in job) + '.json')
    pending = [j for j in jobs if not path(j).exists()]
    start = time.monotonic()
    print(f'{len(jobs)} tasks, {len(pending)} pending, {args.workers} workers', flush=True)
    with ProcessPoolExecutor(max_workers=args.workers, initializer=initialise) as pool:
        futures = {pool.submit(task, j): j for j in pending}
        for n, future in enumerate(as_completed(futures), 1):
            j = futures[future]
            result = future.result()  # Never silently discard a failed replication.
            temp = path(j).with_suffix('.tmp')
            temp.write_text(json.dumps(result, allow_nan=True), encoding='utf-8')
            temp.replace(path(j))
            if n % 10 == 0 or n == len(pending):
                print(f'{n}/{len(pending)} completed, {time.monotonic()-start:.0f}s', flush=True)
    groups = {'decision': [], 'coverage': [], 'inner': []}
    for job in jobs:
        groups[job[0]].extend(json.loads(path(job).read_text()))
    for name, rows in groups.items():
        pd.DataFrame(rows).to_csv(out / f'{name}_raw.csv', index=False)
    print('Current validation study complete', flush=True)


if __name__ == '__main__':
    main()
