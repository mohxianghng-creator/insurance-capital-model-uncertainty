#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 scripts/run_sim.py 150 11 sim_current_T11.csv >> results/sim_current.log 2>&1
python3 scripts/run_sim.py 30 40 sim_current_T40.csv >> results/sim_current.log 2>&1
python3 scripts/run_coverage.py >> results/sim2.log 2>&1
