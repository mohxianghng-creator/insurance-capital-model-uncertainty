"""Aggregate simulation results (SYNTHETIC). Paired comparisons against D0 with bootstrap CIs."""
import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
import numpy as np, pandas as pd
fn = sys.argv[1] if len(sys.argv) > 1 else "sim2_T11.csv"
d = pd.read_csv(ROOT / "results" / fn)
if d.duplicated(["world", "T", "rep", "rule"]).any():
    raise ValueError("duplicate simulation keys; do not mix or partially resume runs")
if "rel_over_upper" not in d:
    d["rel_over_upper"] = np.where(d.capped, np.inf, d.rel_over)
print("Capital outputs beyond the grid are right-censored. Mean loss is a lower bound when capped_share>0; rankings are suppressed.")
rng = np.random.default_rng(0)
rows = []
for (w, rule), g in d.groupby(["world", "rule"]):
    uncensored = not g.capped.any()
    r = dict(world=w, rule=rule, n=len(g), p_breach_mean=(g.p_breach.mean() if uncensored else np.nan), p_breach_median=(g.p_breach.median() if uncensored else np.nan),
             p_shortfall=g.shortfall.mean(), rel_under_mean=g.rel_under.mean(), rel_over_mean=g.rel_over.mean(),
             V_rel_median=(g.V.clip(upper=16384) / g.V_true).median(), capped_share=g.capped.mean(), loss_identified=uncensored)
    for ratio in (1, 3, 10):
        r[f"loss_r{ratio}"] = (ratio * g.rel_under + g.rel_over).mean()
        r[f"loss_r{ratio}_upper"] = (ratio * g.rel_under + g.rel_over_upper).mean()
    rows.append(r)
S = pd.DataFrame(rows)
# paired differences vs D0
pair = []
for w, g in d.groupby("world"):
    p = g.pivot(index="rep", columns="rule", values=["rel_under", "rel_over"])
    for rule in g.rule.unique():
        if rule == "D0_aic_plugin":
            continue
        for ratio in (1, 3, 10):
            diff = (ratio * p["rel_under"][rule] + p["rel_over"][rule]) - (ratio * p["rel_under"]["D0_aic_plugin"] + p["rel_over"]["D0_aic_plugin"])
            if g[g.rule.isin([rule, "D0_aic_plugin"])].capped.any():
                continue  # no finite paired-loss CI is identified from censored outputs
            diff = diff.dropna().to_numpy()
            bs = [rng.choice(diff, len(diff)).mean() for _ in range(2000)]
            pair.append(dict(world=w, rule=rule, ratio=ratio, mean_loss_diff_vs_D0=diff.mean(),
                             ci_lo=np.quantile(bs, .025), ci_hi=np.quantile(bs, .975), share_rule_better=float((diff < 0).mean())))
P = pd.DataFrame(pair)
S.to_csv(ROOT / "results" / f"SIM_summary_{fn}", index=False); P.to_csv(ROOT / "results" / f"SIM_paired_{fn}", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
print(S[["world", "rule", "p_breach_median", "p_breach_mean", "p_shortfall", "V_rel_median", "capped_share", "loss_r1", "loss_r3", "loss_r10"]].round(3).to_string())

# ---- meta-analysis: cap-robust median loss, and worst-world regret of each rule (which single rule is least bad across worlds?)
M = []
for (w, rule), g in d.groupby(["world", "rule"]):
    for ratio in (1, 3, 10):
        l = ratio * g.rel_under + g.rel_over
        M.append(dict(world=w, rule=rule, ratio=ratio, mean_loss=l.mean(), median_loss=l.median()))
M = pd.DataFrame(M)
complete = not d.capped.any()
cand = M[~M.rule.str.startswith("Dorc")] if complete else M.iloc[:0]
if not complete:
    print("META-REGRET withheld: unresolved capital outputs prevent identification of the ranking.")
rows = []
for ratio, g in cand.groupby("ratio"):
    piv = g.pivot(index="rule", columns="world", values="mean_loss")
    rel = piv / piv.min(axis=0)                      # loss relative to the best non-oracle rule in that world
    for rule in piv.index:
        rows.append(dict(ratio=ratio, rule=rule, worst_world_relative_loss=rel.loc[rule].max(), mean_relative_loss=rel.loc[rule].mean(),
                         best_in_n_worlds=int((rel.loc[rule] == 1).sum())))
MR = pd.DataFrame(rows)
M.to_csv(ROOT / "results" / f"SIM_medianloss_{fn}", index=False); MR.reindex(columns=["ratio", "rule", "worst_world_relative_loss", "mean_relative_loss", "best_in_n_worlds"]).to_csv(ROOT / "results" / f"SIM_metaregret_{fn}", index=False)
print("\nMETA-REGRET (relative to best non-oracle rule per world; lower is better)")
print(MR.reindex(columns=["ratio", "rule", "worst_world_relative_loss", "mean_relative_loss", "best_in_n_worlds"]).sort_values(["ratio", "worst_world_relative_loss"]).round(2).to_string())
