"""Cross-platform entry point. Uses the active Python interpreter and fails fast.

verify: unit/numerical tests and saved-artefact integrity (no long refits).
empirical: regenerate both datasets, explorer, numerical/prior sensitivity, then verify.
The historical large simulation study is audited separately and is not silently relabelled as a fresh run.
"""
import argparse
import subprocess
import sys
import os
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SCRATCH = ROOT / 'work'
SCRATCH.mkdir(exist_ok=True)
os.environ['TMP'] = os.environ['TEMP'] = str(SCRATCH)
os.environ.setdefault('MPLCONFIGDIR', str(SCRATCH / 'matplotlib'))
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')


def run(*args):
    command = [sys.executable, '-B', '-u', *args]
    print('+', ' '.join(command), flush=True)
    subprocess.run(command, cwd=ROOT, check=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode', choices=['verify', 'empirical', 'research', 'all'], nargs='?', default='verify')
    args = p.parse_args()
    if args.mode in ('empirical', 'all'):
        for script, opts in [('run_real.py', ['300']), ('run_second.py', ['120']),
                             ('run_e5_decisions.py', ['200']), ('validate_numerics.py', []),
                             ('run_prior_sensitivity.py', ['200'])]:
            run('scripts/' + script, *opts)
        run('scripts/audit_saved_simulations.py')
        run('scripts/analyze_sim.py', 'sim2_T11.csv')
        run('scripts/analyze_sim.py', 'sim2_T40.csv')
        run('scripts/make_figures.py')
        run('scripts/build_ui.py')
    if args.mode in ('research', 'all'):
        run('scripts/run_research.py')
        run('scripts/run_precision_refinement.py')
        run('scripts/run_extensions.py')
        run('scripts/analyze_research.py')
        run('scripts/build_ui.py')
        run('scripts/build_report.py')
    run('-m', 'pytest', '-q', '-p', 'no:cacheprovider')
    run('scripts/verify_results.py')
    run('scripts/verify_current.py')
    if args.mode != 'verify':
        run('scripts/check_manifest.py', '--write')
    run('scripts/check_manifest.py')


if __name__ == '__main__':
    main()
