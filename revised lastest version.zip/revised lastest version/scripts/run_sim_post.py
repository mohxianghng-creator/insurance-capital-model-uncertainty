"""Posterior-based rules on the SAME synthetic samples as sim2_T11 (identical seeds). usage: run_sim_post.py R out.csv"""
import sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "src"))
import numpy as np, pandas as pd
from cmu import data, severity as S, simulation as SIM
from cmu.config import *
R, out, T = int(sys.argv[1]), ROOT / "results" / sys.argv[2], 11
from simulation_run_metadata import guard
guard(out, ROOT, T=T, B=40, seed=SEED, kind='posterior')
x = data.load_danish().loss.to_numpy(); real = {m.name: m.fit(x) for m in S.default_model_set()}
worlds = SIM.make_worlds(real); done = set(); rows = []; t0 = time.time()
if out.exists():
    o = pd.read_csv(out)
    if o.duplicated(['world', 'rep', 'rule']).any() or not o.groupby(['world', 'rep']).size().eq(4).all():
        raise ValueError('duplicate or incomplete posterior replications; do not append to this file')
    done = set(zip(o.world, o.rep))
for wi, (wn, w) in enumerate(worlds.items()):
    d_true, v_true = SIM.truth_summary(w)
    for rep in range(R):
        if (wn, rep) in done: continue
        rng = np.random.default_rng(np.random.SeedSequence([SEED, wi, T, rep]))
        counts = rng.poisson(w["lam"], T); xs = SIM.draw_claims(w["truth"], counts.sum(), rng)
        rng2 = np.random.default_rng(np.random.SeedSequence([SEED, 77, wi, rep]))
        res = SIM.decide_post(xs, counts, rng2)
        for rule, v in res.items():
            if rule.startswith("_"): continue
            rows.append(dict(world=wn, T=T, rep=rep, rule=rule, V=v, V_true=v_true, **SIM.score(v, d_true, v_true)))
        if len(rows) >= 100:
            pd.DataFrame(rows).to_csv(out, mode="a", header=not out.exists(), index=False); rows = []; print(wn, rep, f"{time.time()-t0:.0f}s", flush=True)
if rows: pd.DataFrame(rows).to_csv(out, mode="a", header=not out.exists(), index=False)
print("done", time.time() - t0)
