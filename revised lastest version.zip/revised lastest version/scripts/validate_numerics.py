"""Numerical convergence evidence on both real datasets (not a statistical backtest)."""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
import numpy as np
import pandas as pd
from cmu import aggregate as A, data, data_norfire, severity as S, frequency as F, validation as V


def main():
    rows = []
    original = (A.H, A.NX, A.NS)
    try:
        for dataset, df, nx, ns in [('danish', data.load_danish(), 2**15, 2**17),
                                    ('norfire', data_norfire.load_norfire(), 2**17, 2**19)]:
            x = df.loss.to_numpy()
            counts = V.annual_counts(df, range(int(df.year.min()), int(df.year.max()) + 1))
            fits = [m.fit(x) for m in S.default_model_set()]
            for freq in F.FREQ_NAMES:
                f = F.make(freq).fit(counts)
                for m in fits:
                    vals = {}
                    for tag, h, n, s, tilt in [('base', .5, nx, ns, 16),
                                               ('half_step', .25, 2*nx, 2*ns, 16),
                                               ('double_ceiling', .5, 2*nx, 2*ns, 16),
                                               ('untilted', .5, nx, ns, 0)]:
                        A.set_grid(h, n, s)
                        vals[tag] = A.aggregate(m.cdf, f.forecast(1), r=f.r, tilt=tilt).var(.995)
                    base = vals['base']
                    rows.append(dict(dataset=dataset, severity=m.name, freq=freq, **vals,
                                     half_step_relative_change=abs(vals['half_step']/base-1),
                                     ceiling_relative_change=abs(vals['double_ceiling']/base-1),
                                     alias_relative_change=abs(vals['untilted']/base-1)))
    finally:
        A.set_grid(*original)
    d = pd.DataFrame(rows)
    d.to_csv(ROOT / 'results/numerical_convergence.csv', index=False)
    deviations = d[['half_step_relative_change', 'ceiling_relative_change', 'alias_relative_change']]
    print(deviations.max().to_string())
    # This acceptance criterion concerns the 30 fitted 99.5% quantiles only.
    # It says nothing about TVaR, bootstrap extremes, posterior draws or true calibration.
    if not np.isfinite(deviations.to_numpy()).all() or deviations.max().max() > .01:
        raise SystemExit('FAIL: fitted capital changed by more than 1%; inspect grid settings')
    print('PASS: fitted capital numerical sensitivity below 1% on both datasets')


if __name__ == '__main__':
    main()
