"""Common-random-number sensitivity to GPD prior support and quadrature grid.

An empirical sensitivity exercise on two datasets; not a calibration study.
"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
import numpy as np
import pandas as pd
from cmu import data, data_norfire, aggregate as A, severity as S, uncertainty as U, validation as V
from cmu.config import SEED


def main():
    B = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    rows = []
    original = (A.H, A.NX, A.NS)
    try:
        for di, (name, df, nx, ns) in enumerate([
                ('danish', data.load_danish(), 2**15, 2**17),
                ('norfire', data_norfire.load_norfire(), 2**17, 2**19)]):
            A.set_grid(.5, nx, ns)
            counts = V.annual_counts(df, range(int(df.year.min()), int(df.year.max())+1))
            x = df.loss.to_numpy()
            # Two plausible thresholds in Norway; baseline and a heavier plausible tail in Denmark.
            for u in (5., 10.):
                model = S.Spliced(u).fit(x)
                for xi_max, ng in ((1., 110), (2., 110), (4., 110), (2., 220)):
                    rng = np.random.default_rng(np.random.SeedSequence([SEED, 44, di, int(u)]))
                    out = U.posterior_capital(model, x, counts, 'PoissonConst', B, rng, xi_max=xi_max, ng=ng)
                    lo, med, hi = U.capital_quantiles(out['var'])
                    rows.append(dict(dataset=name, severity=model.name, B=B, xi_max=xi_max, ng=ng,
                                     V_pred=out['mixture'].var(.995), V_p05=lo, V_median=med, V_p95=hi,
                                     unresolved_share=float(np.isinf(out['var']).mean()),
                                     **{k: v for k, v in out['posterior_grid'].items() if k not in ('xi_max', 'ng', 'log_beta_support')}))
                print(name, model.name, 'done', flush=True)
    finally:
        A.set_grid(*original)
    d = pd.DataFrame(rows)
    d.to_csv(ROOT / 'results/prior_sensitivity.csv', index=False)
    print(d[['dataset', 'severity', 'xi_max', 'ng', 'V_pred', 'unresolved_share']].to_string(index=False))


if __name__ == '__main__':
    main()
