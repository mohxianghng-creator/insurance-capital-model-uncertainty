"""Embed results/E5_decisions.json + E4 reverse-stress rows into app/template.html -> app/decision_explorer.html"""
import json, pandas as pd
from pathlib import Path
R = Path(__file__).resolve().parents[1]
d = json.loads((R / "results/E5_decisions.json").read_text(encoding="utf-8"))
e4 = pd.read_csv(R / "results/E4_reverse_stress.csv"); e4 = e4[e4.freq == "PoissonConst"]
d["rs"] = {"K0": float(e4.K0.iloc[0]), "rows": [dict(severity=r.severity, plausible=bool(r.plausible), p=float(r.breach_prob_at_K0),
           rp=(float(r.return_period_yrs) if r.return_period_yrs < 1e9 else 1e12)) for r in e4.itertuples()]}
current = R / 'results/current'
if (current / 'decision_summary.csv').exists():
    d['current'] = dict(
        settings=json.loads((current/'run_metadata.json').read_text())['settings'],
        coverage=pd.read_csv(current/'coverage_summary.csv').to_dict('records'),
        decisions=pd.read_csv(current/'decision_summary.csv').to_dict('records'),
        treaties=pd.read_csv(current/'finite_treaty_decisions.csv').to_dict('records'))
def finite_json(obj):
    import math
    if isinstance(obj, dict): return {k: finite_json(v) for k,v in obj.items()}
    if isinstance(obj, list): return [finite_json(v) for v in obj]
    if isinstance(obj, float) and not math.isfinite(obj): return None
    return obj
html = (R / "app/template.html").read_text(encoding="utf-8").replace("__DATA__", json.dumps(finite_json(d), allow_nan=False))
(R / "app/decision_explorer.html").write_text(html, encoding="utf-8"); print("ui ok", len(html))
