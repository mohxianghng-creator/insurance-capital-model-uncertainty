"""Figures from results/*.csv|json only (no recomputation)."""
import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "src"))
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
R = ROOT / "results"; FIG = ROOT / "paper" / "figures"; FIG.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.size": 9, "axes.grid": True, "grid.alpha": .3})

# F1: capital by model with bootstrap 90% intervals (log axis)
e1 = pd.read_csv(R / "E1_capital_by_model.csv")
fig, ax = plt.subplots(figsize=(7, 4.2))
lab = [f"{r.severity}\n{r.freq.replace('Poisson','P-').replace('NegBinConst','NB')}" for r in e1.itertuples()]
y = np.arange(len(e1))
col = np.where(e1.plausible, "tab:blue", "tab:gray")
ax.hlines(y, e1.V_boot_p05, e1.V_boot_p95, color=col, lw=3, alpha=.5)
ax.scatter(e1.V995, y, c=col, zorder=3, s=22)
ax.set_xscale("log"); ax.set_yticks(y); ax.set_yticklabels([l.replace("\n", " ") for l in lab], fontsize=7)
ax.set_xlabel("VaR 99.5% of annual aggregate (m DKK, log scale)  | dot = MLE plug-in, bar = bootstrap 5-95%")
ax.set_title("Capital requirement by model: parameter vs model uncertainty\n(blue = plausible, dAIC<=10; grey = excluded)")
ax.invert_yaxis(); fig.tight_layout(); fig.savefig(FIG / "F1_capital_by_model.png", dpi=160); plt.close()

# F2: diagnostics: annual counts and Hill estimates
d0 = json.loads((R / "E0_diagnostics.json").read_text())
fig, ax = plt.subplots(1, 2, figsize=(7.5, 3))
yrs = sorted(d0["counts_per_year"]); ax[0].bar([int(k) for k in yrs], [d0["counts_per_year"][k] for k in yrs], color="tab:blue")
ax[0].axhline(np.mean(list(d0["counts_per_year"].values())), color="k", ls="--", lw=1)
ax[0].set_title("Claims >= 1m per year (dispersion index %.1f)" % d0["poisson_dispersion_index"]); ax[0].set_ylim(100, 260)
ks = sorted(int(k) for k in d0["hill_xi_by_k"]); ax[1].plot(ks, [d0["hill_xi_by_k"][str(k)] for k in ks], "o-")
ax[1].set_title("Hill estimate of tail index xi vs k"); ax[1].set_xlabel("k top order statistics")
fig.tight_layout(); fig.savefig(FIG / "F2_data_diagnostics.png", dpi=160); plt.close()

# F3: rolling-origin
ro = pd.read_csv(R / "E2_rolling_origin.csv"); g = ro[ro.freq == "PoissonConst"]
fig, ax = plt.subplots(figsize=(6.5, 3.6))
for s, gg in g.groupby("severity"):
    ax.plot(gg.test_year, gg.V995, "o-", ms=3, label=s)
r = g.drop_duplicates("test_year"); ax.plot(r.test_year, r.realised_S, "k*", ms=9, label="realised annual loss")
ax.set_ylabel("m DKK"); ax.legend(fontsize=7, ncol=2); ax.set_title("One-year-ahead VaR99.5 (expanding window) vs realised")
fig.tight_layout(); fig.savefig(FIG / "F3_rolling_origin.png", dpi=160); plt.close()

# F4: reverse-stress frontier
fr = json.loads((R / "E4_frontier.json").read_text())
fig, ax = plt.subplots(figsize=(6, 3.8))
for k, v in fr.items():
    if k.startswith("s_star_"):
        ax.plot(fr["phi"], v, "o-", ms=3, label=k[7:], lw=2.2 if k == "s_star_baseline" else 1)
ax.set_xlabel("frequency multiplier phi"); ax.set_ylabel("severity multiplier s*")
ax.set_title(f"Reverse stress: 5% breach target on the lattice, V={fr['K']:.0f}"); ax.legend(fontsize=7); ax.set_ylim(0, 3)
fig.tight_layout(); fig.savefig(FIG / "F4_reverse_stress_frontier.png", dpi=160); plt.close()

# F5: simulation study
for fn in ("sim2_T11.csv",):
    p = R / f"SIM_summary_{fn}"
    if not p.exists(): continue
    s = pd.read_csv(p); rules = ["D0_aic_plugin", "D1_bma_mixture", "D2_aic_bootpred", "D3_hurwicz_0", "D3_hurwicz_0.5", "D3_hurwicz_1", "Dorc_true_family"]
    s = s[s.rule.isin(rules)]; worlds = list(s.world.unique())
    fig, axs = plt.subplots(1, 2, figsize=(9, 3.8))
    for i, (col, ttl) in enumerate((("p_shortfall", "P(estimate < true 99.5% quantile)"), ("loss_r3", "Mean loss LOWER BOUND where censored (ratio=3)"))):
        w = 0.11
        for j, rr in enumerate(rules):
            v = [s[(s.world == ww) & (s.rule == rr)][col].mean() for ww in worlds]
            axs[i].bar(np.arange(len(worlds)) + j * w, v, w, label=rr)
        axs[i].set_xticks(np.arange(len(worlds)) + 3 * w); axs[i].set_xticklabels([x.split("_")[0] for x in worlds]); axs[i].set_title(ttl)
        if i == 1: axs[i].set_yscale("log")
    axs[0].legend(fontsize=6)
    fig.suptitle('Historical simulation outputs — earlier engine, retained for comparison', fontsize=10)
    fig.tight_layout(rect=(0,0,1,.93)); fig.savefig(FIG / "F5_simulation.png", dpi=160); plt.close()
print("figures ok")
