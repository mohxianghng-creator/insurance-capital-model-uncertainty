"""Coverage of the semi-Bayesian credible interval vs the bootstrap interval (SYNTHETIC; same seeds/worlds as run_coverage.py)."""
import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "src"))
import numpy as np, pandas as pd
from cmu import data, severity as S, simulation as SIM, uncertainty as U, aggregate as A
from cmu.config import *
x = data.load_danish().loss.to_numpy()
real = {m.name: m.fit(x) for m in S.default_model_set()}
W = SIM.make_worlds(real); R, B = 150, 80
rows = []
for wi, wn in enumerate(("W2_Sp10_xi0.50", "W5_Sp10_xi0.25")):
    w = W[wn]; _, vt = SIM.truth_summary(w)
    for rep in range(R):
        rng = np.random.default_rng(np.random.SeedSequence([SEED, 99, wi, rep]))
        counts = rng.poisson(w["lam"], 11); xs = SIM.draw_claims(w["truth"], counts.sum(), rng)
        m = S.Spliced(10.0).fit(xs)
        bt = U.bootstrap_capital(m, xs, counts, "PoissonConst", B, rng, keep_dists=True)   # identical stream to run_coverage.py
        rng2 = np.random.default_rng(np.random.SeedSequence([SEED, 98, wi, rep]))
        pp = U.posterior_capital(m, xs, counts, "PoissonConst", B, rng2)
        row = dict(world=wn, rep=rep, V_true=vt, plug=A.aggregate(m.cdf, np.mean(counts)).var(ALPHA_VAR))
        for tag, o in (("boot", bt), ("post", pp)):
            v = o["var"]; lo, hi = U.capital_quantiles(v, [.05, .95])
            row.update({f"{tag}_lo": lo, f"{tag}_hi": hi, f"{tag}_cov": bool(lo <= vt <= hi), f"{tag}_pred": o["mixture"].var(ALPHA_VAR),
                        f"{tag}_width_ratio": hi / lo})
        row["xi_boundary"] = bool(m.xi <= 1e-5)
        rows.append(row)
d = pd.DataFrame(rows); d.to_csv(ROOT / "results" / "COVERAGE2_raw.csv", index=False)
out = {}
for wn, g in d.groupby("world"):
    out[wn] = dict(n=len(g), plugin_below_true=float((g.plug < g.V_true).mean()),
                   boot_coverage90=float(g.boot_cov.mean()), post_coverage90=float(g.post_cov.mean()),
                   boot_pred_below_true=float((g.boot_pred < g.V_true).mean()), post_pred_below_true=float((g.post_pred < g.V_true).mean()),
                   boot_median_width_ratio=float(g.boot_width_ratio.median()), post_median_width_ratio=float(g.post_width_ratio.median()),
                   boundary_n=int(g.xi_boundary.sum()))
(ROOT / "results" / "COVERAGE2_summary.json").write_text(json.dumps(out, indent=1)); print(json.dumps(out, indent=1))
