"""Derive identified loss bounds and sampling intervals from supplied simulations.

No fitted rule is rerun. Stored V values retain their historical provenance.
An output above the old grid is unknown above that ceiling, not equal to it.
"""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / 'results'


def main():
    rows, provenance = [], {}
    for name in ('sim2_T11.csv', 'sim2_T40.csv', 'sim3_post_T11.csv'):
        path = RES / name
        d = pd.read_csv(path)
        if d.duplicated(['world', 'rep', 'rule']).any():
            raise ValueError(f'duplicate simulation keys: {name}')
        provenance[name] = dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                               status='historical fitted outputs; not regenerated after numerical safeguards',
                               ceiling=16384, loss_interpretation='lower bound where capital is censored',
                               n_rows=len(d))
        for (world, rule), g in d.groupby(['world', 'rule']):
            n = len(g)
            capped = g.capped.to_numpy(dtype=bool)
            low = np.minimum(g.V.to_numpy(), 16384.)
            truth = g.V_true.to_numpy()
            if not np.isfinite(truth).all() or (truth >= 16384).any():
                raise ValueError('truth must be resolved below the original numerical ceiling')
            under = np.maximum(truth-low, 0)/truth
            over = np.maximum(low-truth, 0)/truth
            n_short = int((low < truth).sum())
            ci = stats.binomtest(n_short, n).proportion_ci(.95, method='wilson')
            for ratio in (1, 3, 10):
                losses = ratio*under+over
                rows.append(dict(source=name, world=world, rule=rule, ratio=ratio, n=n,
                                 censored_share=float(capped.mean()),
                                 p_estimate_below_truth=n_short/n,
                                 p_estimate_below_truth_ci_lo=ci.low, p_estimate_below_truth_ci_hi=ci.high,
                                 loss_lower=float(losses.mean()),
                                 loss_upper=(np.inf if capped.any() else float(losses.mean())),
                                 loss_identified=not capped.any()))
    pd.DataFrame(rows).to_csv(RES / 'SIM_loss_bounds.csv', index=False)
    (RES / 'simulation_provenance.json').write_text(json.dumps(provenance, indent=2), encoding='utf-8')
    print('Saved loss bounds, Wilson intervals and historical simulation provenance')


if __name__ == '__main__':
    main()
