"""Prevent resumable simulation files from mixing engines or settings."""
import hashlib
import json
import platform
from importlib.metadata import version
from pathlib import Path


def guard(out, root, **settings):
    paths = sorted((root / 'src/cmu').glob('*.py')) + [Path(__file__)]
    paths += [root / 'scripts/run_sim.py', root / 'scripts/run_sim_post.py']
    digest = hashlib.sha256()
    for p in paths:
        digest.update(p.relative_to(root).as_posix().encode())
        digest.update(p.read_bytes())
    meta = dict(source_sha256=digest.hexdigest(), python=platform.python_version(), settings=settings,
                dependencies={k: version(k) for k in ('numpy', 'scipy', 'pandas', 'rdata')},
                engine='tilted FFT; uncapped means; censored loss bounds')
    sidecar = out.with_suffix('.meta.json')
    if out.exists() and not sidecar.exists():
        raise ValueError(f'{out.name} has no engine metadata. Use a fresh output filename; historical results cannot be resumed safely.')
    if sidecar.exists():
        previous = json.loads(sidecar.read_text(encoding='utf-8'))
        if previous != meta:
            raise ValueError('simulation engine or settings changed; use a fresh output filename')
    else:
        sidecar.write_text(json.dumps(meta, indent=2), encoding='utf-8')
