"""Coverage study (SYNTHETIC): does the bootstrap 90% interval of the model's V contain the TRUE V?
Also: does the bootstrap-predictive V exceed the true V with the right frequency? Worlds in-class for Spliced10."""
import sys, json, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / "src"))
import numpy as np, pandas as pd
from cmu import data, severity as S, simulation as SIM, uncertainty as U, aggregate as A
from cmu.config import *
x = data.load_danish().loss.to_numpy()
real = {m.name: m.fit(x) for m in S.default_model_set()}
W = SIM.make_worlds(real)
R, B = 150, 80
rows = []
for wi, wn in enumerate(("W2_Sp10_xi0.50", "W5_Sp10_xi0.25")):
    w = W[wn]; _, vt = SIM.truth_summary(w)
    for rep in range(R):
        rng = np.random.default_rng(np.random.SeedSequence([SEED, 99, wi, rep]))
        counts = rng.poisson(w["lam"], 11); xs = SIM.draw_claims(w["truth"], counts.sum(), rng)
        m = S.Spliced(10.0).fit(xs)
        bt = U.bootstrap_capital(m, xs, counts, "PoissonConst", B, rng, keep_dists=True)
        v = bt["var"]
        lo, hi = U.capital_quantiles(v, [.05, .95])
        rows.append(dict(world=wn, rep=rep, V_true=vt, lo=lo, hi=hi, covered=bool(lo <= vt <= hi), pred_V=bt["mixture"].var(ALPHA_VAR),
                         xi_hat=m.xi, xi_at_boundary=bool(m.xi <= 1e-5), plug=A.aggregate(m.cdf, np.mean(counts)).var(ALPHA_VAR)))
d = pd.DataFrame(rows); d.to_csv(ROOT / "results" / "COVERAGE_raw.csv", index=False)
g = d.groupby("world").agg(coverage_90=("covered", "mean"), shortfall_plugin=("plug", lambda s: np.nan),
                           boundary_share=("xi_at_boundary", "mean"))
out = {}
for wn, gg in d.groupby("world"):
    out[wn] = dict(n=len(gg), coverage_nominal90=float(gg.covered.mean()), pred_below_true=float((gg.pred_V < gg.V_true).mean()),
                   plugin_below_true=float((gg.plug < gg.V_true).mean()), boundary_share=float(gg.xi_at_boundary.mean()),
                   coverage_when_boundary=float(gg[gg.xi_at_boundary].covered.mean()) if gg.xi_at_boundary.any() else None)
(ROOT / "results" / "COVERAGE_summary.json").write_text(json.dumps(out, indent=1)); print(out)
