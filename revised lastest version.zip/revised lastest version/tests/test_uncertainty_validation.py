import numpy as np, pytest
from cmu import uncertainty as U, validation as V, severity as S, simulation as SIM, frequency as F


def test_bootstrap_reproducible_and_centered():
    rng0 = np.random.default_rng(11)
    xs = S.LN(-0.3, 1.2).ppf(rng0.random(1500)); counts = np.full(11, 130)
    m = S.LN().fit(xs)
    a = U.bootstrap_capital(m, xs, counts, "PoissonConst", 12, np.random.default_rng(5))
    b = U.bootstrap_capital(m, xs, counts, "PoissonConst", 12, np.random.default_rng(5))
    np.testing.assert_array_equal(a["var"], b["var"])
    pt = U.point_estimate(m, 130.0)[1]
    assert 0.6 * pt < np.median(a["var"]) < 1.6 * pt


def test_bootstrap_parameter_spread_shrinks_with_sample_size():
    rng0 = np.random.default_rng(12)
    big = S.Lomax(0.6, 1.0).ppf(rng0.random(6000))
    sd = []
    for xs in (big, big[:600]):
        m = S.Lomax().fit(xs)
        bt = U.bootstrap_capital(m, xs, np.full(11, len(xs) / 11), "PoissonConst", 60, np.random.default_rng(6))
        sd.append(np.std([p["xi"] for p in bt["params"]]))
    assert sd[1] > 1.8 * sd[0]          # theory: sd ~ 1/sqrt(n) -> ratio ~3.2


def test_decompose_shares_in_unit_interval():
    pv = {"a": 1000.0, "b": 1500.0}
    bv = {"a": np.array([900, 1100, 1000.]), "b": np.array([1400, 1600, 1500.])}
    r = U.decompose(pv, bv)
    assert 0 < r["share_model"] < 1 and r["range_ratio_max_min"] == pytest.approx(1.5)


def test_kupiec_known_values():
    lr, p = V.kupiec_pof(1000, 10, 0.01)
    assert lr == pytest.approx(0, abs=1e-9) and p == pytest.approx(1)
    assert V.kupiec_pof(1000, 30, 0.01)[1] < 0.001
    assert V.kupiec_pof(100, 0, 0.01)[0] == pytest.approx(-200 * np.log(0.99))


def test_power_function_properties():
    p6 = V.breach_test_power(6); p50 = V.breach_test_power(50)
    assert p6.power.is_monotonic_increasing and p6.actual_size.iloc[0] <= 0.05 + 1e-12
    assert p6.power.iloc[0] < 0.1                       # cannot detect a 2x understatement of the breach probability
    assert V.years_needed_for_power(0.05) < V.years_needed_for_power(0.02) < V.years_needed_for_power(0.01)
    assert p50.power.iloc[-1] >= p6.power.iloc[-1]


def test_rolling_origin_has_no_lookahead(df):
    ro = V.rolling_origin(df, 1984, 1985, models=[S.LN()])
    assert set(ro.origin) == {1984, 1985} and (ro.test_year == ro.origin + 1).all()
    # changing future data must not change forecasts made at origin 1984
    df2 = df.copy(); df2.loc[df2.year == 1985, "loss"] *= 10
    ro2 = V.rolling_origin(df2, 1984, 1984, models=[S.LN()])
    a = ro[ro.origin == 1984].set_index("freq").V995; b = ro2.set_index("freq").V995
    assert (a == b).all()


def test_simulation_rules_ordering_and_integration():
    rng = np.random.default_rng(3)
    truth = S.Spliced(10.0, -0.5, 1.1, 0.95, 0.5, 7.0)
    counts = rng.poisson(197, 11); xs = truth.ppf(rng.random(counts.sum()))
    out = SIM.decide(xs, counts, rng, B=6, oracle=S.Spliced(10.0))
    th = [min(out[f"D3_hurwicz_{t:g}"], 16384.0) for t in SIM.THETAS]
    assert all(np.diff(th) >= 0) and out["D2_aic_bootpred"] >= min(th)
    assert 1 <= out["_n_plausible"] <= 5 and np.isfinite(out["D0_aic_plugin"])


def test_gpd_posterior_concentrates_on_truth_and_handles_exponential_tail():
    rng = np.random.default_rng(21)
    y = S.gpd_ppf(rng.random(4000), 0.5, 5.0)
    xi, b = U._gpd_posterior_draws(y, 400, rng)
    assert abs(np.median(xi) - 0.5) < 0.05 and abs(np.median(b) - 5.0) < 0.6
    y2 = rng.exponential(7.0, 100)                       # xi=0 truth: posterior near the boundary, beta sane
    xi2, b2 = U._gpd_posterior_draws(y2, 400, rng)
    assert np.median(xi2) < 0.25 and 3.0 < np.median(b2) < 15.0


def test_posterior_capital_runs_and_mixture_dominates_plugin_median():
    rng = np.random.default_rng(22)
    truth = S.Spliced(10.0, -0.5, 1.1, 0.95, 0.5, 7.0)
    counts = rng.poisson(197, 11); xs = truth.ppf(rng.random(counts.sum()))
    m = S.Spliced(10.0).fit(xs)
    out = U.posterior_capital(m, xs, counts, "PoissonConst", 25, rng)
    assert len(out["var"]) >= 20 and np.isfinite(out["mixture"].var(0.995))
    # fallback path for LN
    out2 = U.posterior_capital(S.LN().fit(xs), xs, counts, "PoissonConst", 5, rng)
    assert "mixture" in out2


def test_set_grid_roundtrip():
    from cmu import aggregate as A
    cap = A.set_grid(0.5, 2 ** 16, 2 ** 18)
    try:
        assert cap == 32768.0
        d = A.aggregate(S.Lomax(0.6, 1.0).cdf, 100.0)
        assert np.isfinite(d.var(0.995)) and len(d.g) == 2 ** 18
    finally:
        A.set_grid(0.5, 2 ** 15, 2 ** 17)


def test_full_pipeline_deterministic_given_seed():
    truth = S.Spliced(10.0, -0.5, 1.1, 0.95, 0.5, 7.0)
    def run(seed):
        rng = np.random.default_rng(seed)
        counts = rng.poisson(197, 11); xs = truth.ppf(rng.random(counts.sum()))
        a = SIM.decide(xs, counts, rng, B=5, oracle=S.Spliced(10.0))
        b = SIM.decide_post(xs, counts, rng, B=5)
        return {**a, **b}
    r1, r2, r3 = run(7), run(7), run(8)
    assert r1 == r2 and r1 != r3


def test_norfire_loader_and_checksum(tmp_path):
    import shutil
    from cmu import data_norfire as N
    d = N.load_norfire()
    assert len(d) == 5433 and d.year.min() == 1985 and d.loss.min() >= 1.0
    bad = tmp_path / "norfire.rda"; shutil.copy(N.RAW, bad); bad.write_bytes(bad.read_bytes() + b"x")
    import pytest as _p
    with _p.raises(ValueError):
        N.load_norfire(bad)
