import shutil
import numpy as np, pytest
from cmu import data


def test_row_count_and_range(df):
    assert len(df) == 2167
    assert df.loss.min() >= 1.0 - 1e-12 and np.isfinite(df.loss).all()
    assert df.date.iloc[0].isoformat().startswith("1980-01-03") and df.date.iloc[-1].isoformat().startswith("1990-12-31")


def test_dates_monotone_and_year_counts(df):
    assert df.date.is_monotonic_increasing
    c = df.groupby("year").size()
    assert c.sum() == 2167 and c.loc[1980] == 166 and c.loc[1990] == 218


def test_validate_report(df):
    rep = data.validate(df)
    assert rep["n_claims_gt_100"] == 3 and rep["n_claims_gt_10"] == 109
    assert abs(rep["max_loss"] - 263.250366) < 1e-5


def test_checksum_guard(tmp_path):
    bad = tmp_path / "danish.rda"
    shutil.copy(data.RAW, bad)
    bad.write_bytes(bad.read_bytes()[:-5] + b"xxxxx")
    with pytest.raises(ValueError, match="checksum"):
        data.load_danish(bad)


def test_validate_rejects_bad_data(df):
    d2 = df.copy(); d2.loc[0, "loss"] = 0.5
    with pytest.raises(ValueError):
        data.validate(d2)
    with pytest.raises(ValueError):
        data.validate(df.iloc[:-1])
