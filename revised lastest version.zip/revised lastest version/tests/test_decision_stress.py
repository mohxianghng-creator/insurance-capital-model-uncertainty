import numpy as np, pytest
from cmu import decision as D, stress as ST, aggregate as A, severity as S, frequency as F


def test_hurwicz_equals_numeric_minimax_regret():
    rng = np.random.default_rng(0)
    for _ in range(25):
        v = rng.uniform(100, 5000, size=rng.integers(2, 7))
        cu, co = rng.uniform(0.2, 10, 2)
        closed = D.hurwicz(v, D.theta_from_costs(cu, co))
        num = D.minimax_regret_numeric(v, cu, co, grid=40001)
        assert closed == pytest.approx(num, rel=2e-3)


def test_hurwicz_bounds_and_monotone_in_theta():
    v = [1000, 1500, 4000]
    assert D.hurwicz(v, 0) == 1000 and D.hurwicz(v, 1) == 4000
    assert D.hurwicz(v, .25) < D.hurwicz(v, .5) < D.hurwicz(v, .75)


def test_akaike_weights_and_plausible():
    d, w = D.akaike_weights([100, 102, 130])
    assert w.sum() == pytest.approx(1) and d[0] == 0 and w[0] > w[1] > w[2]
    assert list(D.plausible_mask([100, 109.9, 110.1], 10)) == [True, True, False]


def test_linear_loss_asymmetry():
    assert D.linear_loss(80, 100, 5, 1) == 100 and D.linear_loss(120, 100, 5, 1) == 20


M = S.Spliced(10.0, -0.5, 1.1, 0.95, 0.5, 7.0)
LAM = 100.0


@pytest.mark.parametrize("kind", ["phi", "s", "dxi"])
def test_breakeven_is_the_threshold(kind):
    K = A.aggregate(M.cdf, LAM).var(0.995) * 1.3
    z = ST.breakeven(M, LAM, K, kind)
    assert np.isfinite(z) and z > (0 if kind == "dxi" else 1)
    at = ST._var(M, LAM, **{kind: z})
    below = ST._var(M, LAM, **{kind: (z - 0.02 if kind == "dxi" else z * 0.97)})
    assert at >= K > below


def test_breakeven_already_breached_returns_lower_bound_and_unbreachable_inf():
    K_low = A.aggregate(M.cdf, LAM).var(0.995) * 0.5
    assert ST.breakeven(M, LAM, K_low, "phi") == 1.0
    assert ST.breakeven(S.LN(-0.3, 1.0), LAM, 10000, "phi", hi=3.0) == float("inf")
    with pytest.raises(ValueError, match="ceiling"):
        ST.breakeven(S.LN(-0.3, 1.0), LAM, 1e9, "phi", hi=3.0)


def test_stress_monotone_in_alpha_level():
    K = A.aggregate(M.cdf, LAM).var(0.995)
    z95 = ST.breakeven(M, LAM, K, "phi", alpha=0.95)
    z50 = ST.breakeven(M, LAM, K, "phi", alpha=0.50)
    assert 1.0 < z95 < z50


def test_frontier_decreasing_in_frequency():
    K = A.aggregate(M.cdf, LAM).var(0.995) * 1.4
    fr = ST.frontier(M, LAM, K, [1.0, 1.3, 1.6], alpha=0.995)
    assert fr[0] > fr[1] > fr[2]


def test_single_loss_scenario_probability():
    d = A.aggregate(M.cdf, LAM)
    K = d.var(0.995)
    x_star, ann = ST.single_loss_scenario(M, LAM, K, d.mean_S)
    assert x_star == pytest.approx(K - d.mean_S)
    assert ann == pytest.approx(1 - np.exp(-LAM * (1 - M.cdf(np.array([x_star]))[0])))


def test_frequency_models():
    c = np.array([100, 110, 120, 130, 140, 150])
    tr = F.PoissonTrend().fit(c)
    assert tr.beta[1] > 0 and tr.forecast(1) > c.mean()
    # Poisson-regression score equations: sum(c - mu) = 0 and sum(t*(c-mu)) = 0
    mu = tr.fitted(); t = np.arange(6) - 2.5
    assert np.sum(c - mu) == pytest.approx(0, abs=1e-6) and np.sum(t * (c - mu)) == pytest.approx(0, abs=1e-6)
    nb = F.NegBinConst().fit(np.array([100, 160, 90, 170, 100, 150]))
    assert nb.r < 1e5 and F.NegBinConst().fit(np.array([100, 101, 100, 99])).r == 1e6
