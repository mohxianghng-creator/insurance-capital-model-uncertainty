import numpy as np, pytest
from scipy import integrate
from cmu import severity as S

ALL = lambda: [S.LN(-0.3, 1.2), S.Lomax(0.6, 1.0), S.Spliced(10.0, -0.5, 1.1, 0.95, 0.5, 7.0),
               S.PiecewiseTail(S.Spliced(10.0, -0.5, 1.1, 0.95, 0.5, 7.0), 100.0, 1.0)]


@pytest.mark.parametrize("m", ALL(), ids=lambda m: m.name)
def test_cdf_ppf_roundtrip_and_monotone(m):
    u = np.array([1e-6, 0.01, 0.3, 0.5, 0.9, 0.99, 0.999, 1 - 1e-6])
    q = m.ppf(u)
    assert np.all(np.diff(q) > 0) and q[0] >= 1.0 - 1e-9
    np.testing.assert_allclose(m.cdf(q), u, rtol=1e-6, atol=1e-9)
    xs = np.linspace(1, 500, 4000)
    assert np.all(np.diff(m.cdf(xs)) >= -1e-12)
    assert m.cdf(np.array([0.5]))[0] == 0.0 and m.cdf(np.array([1e9]))[0] > 1 - 1e-5


@pytest.mark.parametrize("m", ALL()[:3], ids=lambda m: m.name)
def test_pdf_consistent_with_cdf(m):
    # density = derivative of cdf (central differences) away from the splice point
    for x0 in (1.7, 3.0, 25.0, 80.0):
        h = 1e-4 * x0
        fd = (m.cdf(np.array([x0 + h]))[0] - m.cdf(np.array([x0 - h]))[0]) / (2 * h)
        assert fd == pytest.approx(float(np.exp(m.logpdf(np.array([x0]))[0])), rel=1e-4)
    # integrates to one
    tot = integrate.quad(lambda t: np.exp(m.logpdf(np.array([t]))[0]), 1, 10, limit=200)[0] \
        + integrate.quad(lambda t: np.exp(m.logpdf(np.array([t]))[0]), 10, np.inf, limit=200)[0]
    assert tot == pytest.approx(1.0, abs=2e-4)


def test_fit_recovers_parameters_large_sample():
    rng = np.random.default_rng(1)
    for truth in (S.LN(-0.3, 1.2), S.Lomax(0.6, 1.0), S.Spliced(10.0, -0.5, 1.1, 0.95, 0.5, 7.0)):
        xs = truth.ppf(rng.random(60000))
        est = type(truth)(*([10.0] if isinstance(truth, S.Spliced) else [])).fit(xs)
        for k, v in truth.params().items():
            assert est.params()[k] == pytest.approx(v, rel=0.08, abs=0.05), (truth.name, k)


def test_gpd_mle_on_exact_gpd_sample():
    rng = np.random.default_rng(2)
    y = S.gpd_ppf(rng.random(50000), 0.4, 3.0)
    xi, beta = S.fit_gpd(y)
    assert xi == pytest.approx(0.4, abs=0.03) and beta == pytest.approx(3.0, rel=0.05)


def test_mle_beats_perturbed_parameters(x):
    m = S.Spliced(10.0).fit(x)
    base = m.loglik(x)
    for dxi in (-0.05, 0.05):
        assert S.Spliced(10.0, m.mu, m.sigma, m.p, m.xi + dxi, m.beta).loglik(x) < base
    for ds in (-0.05, 0.05):
        assert S.Spliced(10.0, m.mu, m.sigma + ds, m.p, m.xi, m.beta).loglik(x) < base


def test_insufficient_data_raises():
    with pytest.raises(ValueError):
        S.Spliced(10.0).fit(np.linspace(1, 9, 200))
    with pytest.raises(ValueError):
        S.fit_gpd(np.array([1.0, 2.0]))


def test_tail_shift_and_no_tail_for_ln():
    m = S.Lomax(0.6, 1.0).with_tail_shift(0.2)
    assert m.xi == pytest.approx(0.8)
    with pytest.raises(NotImplementedError):
        S.LN(0, 1).with_tail_shift(0.1)


def test_piecewise_cdf_continuous_at_break():
    m = ALL()[3]
    eps = 1e-6
    assert m.cdf(np.array([100 - eps]))[0] == pytest.approx(m.cdf(np.array([100 + eps]))[0], abs=1e-7)
    # beyond the break the survival is heavier than the base tail
    assert m.base.sf(np.array([2000.0]))[0] < m.sf(np.array([2000.0]))[0]


def test_aic_uses_param_count(x, fits):
    assert fits["LN"].aic(x) == pytest.approx(2 * 2 - 2 * fits["LN"].loglik(x))
    assert fits["Spliced10"].aic(x) == pytest.approx(2 * 5 - 2 * fits["Spliced10"].loglik(x))
    assert fits["Spliced10"].n_params == 5 and fits["Lomax"].n_params == 2


def test_gpd_fit_boundary_exponential_tail_gives_sane_beta():
    """Regression: light/exponential tails put xi at its lower bound; beta must then equal the mean excess
    (earlier version returned beta ~ 1e3 which inflated bootstrap capital by an order of magnitude)."""
    for seed in range(20):
        y = np.random.default_rng(seed).exponential(7.0, size=120)
        xi, beta = S.fit_gpd(y)
        assert 0 < xi < 0.5 and 3.0 < beta < 15.0
    xi, beta = S.fit_gpd(np.random.default_rng(4).exponential(7.0, size=5000))
    assert xi < 0.05 and beta == pytest.approx(7.0, rel=0.1)
