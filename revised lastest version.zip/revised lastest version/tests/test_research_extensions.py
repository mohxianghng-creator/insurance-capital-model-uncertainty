import numpy as np
import pytest
from scipy import optimize
from cmu import aggregate as A, severity as S, research as R, reinsurance as RI


def test_expanded_quantile_resolves_and_restores_active_grid():
    before = A.H, A.NX, A.NS
    m = S.Lomax(.1, 2)
    with R.grid_context(.5, 128, 512):
        d = A.aggregate(m.cdf, 40)
        assert np.isinf(d.var(.995))
        value, info = R.resolve_capital([(m, 40, None)], initial=d, max_cap=1024)
        assert info['expanded'] and info['resolved']
        with R.grid_context(.125, 8192, 32768):
            reference = A.aggregate(m.cdf, 40).var(.995)
        assert value == pytest.approx(reference, rel=.005)
        assert (A.H, A.NX, A.NS) == (.5, 128, 512)
    assert (A.H, A.NX, A.NS) == before


def test_expanded_quantile_remains_censored_at_actual_last_ceiling():
    m = S.Lomax(3, 500)
    with R.grid_context(1, 32, 128):
        value, info = R.resolve_capital([(m, 100, None)], max_cap=128)
    assert np.isinf(value) and not info['resolved'] and info['ceiling'] == 128


def test_failed_refinement_is_not_misrepresented_as_right_censored_capital(monkeypatch):
    class NumericalResult:
        cap, h = 32, 1
        def __init__(self, q): self.q = q
        def var(self, alpha): return self.q
    values = iter([NumericalResult(50), NumericalResult(60)])
    monkeypatch.setattr(R, 'distribution', lambda *args, **kwargs: next(values))
    with pytest.raises(RuntimeError, match='fails grid refinement'):
        R.resolve_capital([(S.Lomax(.5, 2), 20, None)], initial=NumericalResult(np.inf), max_cap=128)


def test_predictive_reaggregation_matches_independent_weighted_cdf():
    specs = [(S.Lomax(.4, 2), 20, None), (S.LN(-.3, 1.2), 25, 10)]
    d = R.distribution(specs, [.2, .8])
    refs = [A.aggregate(m.cdf, lam, r=r) for m, lam, r in specs]
    reference = .2 * refs[0].g + .8 * refs[1].g
    np.testing.assert_allclose(d.cum[:d.nx], np.cumsum(reference)[:d.nx], atol=1e-10)
    before = A.H, A.NX, A.NS
    with pytest.raises(RuntimeError):
        with R.grid_context(1, 32, 128):
            raise RuntimeError('intentional')
    assert (A.H, A.NX, A.NS) == before


@pytest.mark.parametrize('interval', [(1, np.inf), (1, 5), (1, 20)])
def test_analytic_score_fit_matches_derivative_free_likelihood(interval):
    a, b = interval
    rng = np.random.default_rng(63)
    model = S._TruncLN(-.4, 1.3, a, b)
    x = model.ppf(rng.random(500))
    mu, sigma = S.fit_trunc_ln(x, a, b)
    def nll(p):
        return -S._TruncLN(p[0], np.exp(p[1]), a, b).logpdf(x).sum()
    ref = optimize.minimize(nll, [-.4, np.log(1.3)], method='Nelder-Mead',
                            options={'maxiter': 3000, 'xatol': 1e-9, 'fatol': 1e-9})
    assert ref.success
    assert nll([mu, np.log(sigma)]) <= ref.fun + 1e-6


def test_finite_layer_returns_upper_losses_to_insurer_and_preserves_mean():
    m = S.Lomax(.6, 2)
    net = RI.LayerRetained(m, 10, 20)
    assert float(net.cdf(np.array([10]))[0]) == pytest.approx(float(m.cdf(np.array([30]))[0]))
    assert float(net.cdf(np.array([100]))[0]) == pytest.approx(float(m.cdf(np.array([120]))[0]))
    assert net.stop_loss(0) + RI.layer_recovery(m, 10, 20) == pytest.approx(m.stop_loss(0))
    rng = np.random.default_rng(2026)
    x = m.ppf(rng.random(200000))
    recovery = np.minimum(np.maximum(x-10, 0), 20)
    assert recovery.mean() == pytest.approx(net.recovery, rel=.04)


def test_finite_layer_is_finitely_priced_but_does_not_repair_infinite_gross_mean():
    m = S.Lomax(1.2, 2)
    net = RI.LayerRetained(m, 10, 20)
    assert np.isfinite(net.recovery)
    assert np.isinf(net.stop_loss(0))
    assert np.isinf(A.aggregate(net.cdf, 20).mean_S)
    with pytest.raises(ValueError):
        RI.LayerRetained(m, 10, np.inf)


def test_wilson_interval_respects_boundaries_and_known_reference():
    lo, hi = R.wilson(90, 100)
    assert lo == pytest.approx(.8256343, abs=1e-6)
    assert hi == pytest.approx(.9447709, abs=1e-6)
    assert R.wilson(0, 100)[0] == 0
    assert R.wilson(100, 100)[1] == 1


@pytest.mark.parametrize('model', [S.Lomax(.5, 2), S.Lomax(.95, 5),
                                  S.Spliced(10, -.5, 1.1, .95, .8, 7)])
@pytest.mark.parametrize('r', [None, 20])
def test_compact_tilted_domain_matches_padded_cdf_and_var(model, r):
    padded = A.aggregate(model.cdf, 197, r=r)
    with R.grid_context(A.H, A.NX, A.NX):
        compact = A.aggregate(model.cdf, 197, r=r)
    # Probability of any wrapped block is damped by at least exp(-16).
    np.testing.assert_allclose(compact.cum, padded.cum[:padded.nx], atol=1.2e-7, rtol=0)
    assert compact.var(.995) == pytest.approx(padded.var(.995), abs=.5)


def test_spectral_predictive_uses_same_bootstrap_law_as_original(fits, x, df):
    from cmu import uncertainty as U, validation as V
    counts = V.annual_counts(df, range(1980, 1991))
    a = U.bootstrap_capital(fits['Spliced10'], x, counts, 'PoissonConst', 8,
                            np.random.default_rng(91), keep_dists=True, keep_specs=True)
    specs = R.bootstrap_specs(fits['Spliced10'], x, counts, 8, np.random.default_rng(91))
    assert [(m.params(), lam, r) for m, lam, r in specs] == [(m.params(), lam, r) for m, lam, r in a['specs']]
    d = R.distribution(specs)
    np.testing.assert_allclose(d.cum[:d.nx], a['mixture'].cum[:d.nx], atol=1e-10)
    assert d.var(.995) == a['mixture'].var(.995)
