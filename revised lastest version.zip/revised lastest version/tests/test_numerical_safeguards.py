"""Independent boundary checks for capital and reinsurance decisions."""
import numpy as np
import pytest
from scipy import integrate, stats
from cmu import aggregate as A, severity as S, decision as D, uncertainty as U, simulation as SIM, stress as ST


@pytest.mark.parametrize('m', [S.LN(-0.3, 1.2), S.Lomax(0.7, 2),
                              S.Spliced(10, -0.5, 1.1, 0.95, 0.7, 7)])
@pytest.mark.parametrize('r', [0, 5, 20])
def test_uncapped_stop_loss_matches_independent_infinite_integral(m, r):
    ref = integrate.quad(lambda x: float(1 - m.cdf(np.array([x]))[0]),
                         r, np.inf, epsabs=1e-7, limit=500)[0]
    assert m.stop_loss(r) == pytest.approx(ref, rel=3e-6)


def test_infinite_mean_is_not_reported_as_finite_by_grid_truncation():
    m = S.Lomax(1.2, 2)
    assert A.expected_recovery_per_claim(m.cdf, 20) == np.inf
    gross = A.aggregate(m.cdf, 30)
    assert gross.mean_S == np.inf
    assert gross.tvar(0.99) == (np.inf, False)
    net = A.aggregate(m.cdf, 30, retention=20)
    bounded = integrate.quad(lambda x: float(m.sf(np.array([x]))[0]), 0, 20, points=[1])[0]
    assert net.mean_S == pytest.approx(30 * bounded, rel=1e-8)


def test_reinsurance_mean_decomposition_and_scale(fits):
    for m in fits.values():
        gross = A.aggregate(m.cdf, 197, scale=2).mean_S
        net = A.aggregate(m.cdf, 197, scale=2, retention=20).mean_S
        recovery = 197 * A.expected_recovery_per_claim(m.cdf, 20, scale=2)
        assert gross == pytest.approx(net + recovery, rel=1e-8)


def test_tail_break_world_has_infinite_mean_but_finite_quantiles():
    m = S.PiecewiseTail(S.Spliced(10, -0.5, 1.1, 0.95, 0.5, 7), 100, 1)
    assert m.stop_loss(0) == np.inf
    assert np.isfinite(A.aggregate(m.cdf, 100).var(0.995))


def test_quantile_retains_unresolved_draws():
    draws = np.r_[np.arange(1, 91), np.full(10, np.inf)]
    assert U.capital_quantiles(draws, .95) == np.inf
    assert U.capital_quantiles(draws, .5) == 50
    with pytest.raises(ValueError):
        U.capital_quantiles([1, np.nan])


def test_distribution_keeps_its_grid_after_reconfiguration():
    d = A.aggregate(S.Lomax(.5, 2).cdf, 20)
    before = (d.var(.99), float(d.cdf_at(100)), d.tvar(.99))
    old = (A.H, A.NX, A.NS)
    try:
        A.set_grid(.25, 2**16, 2**18)
        assert (d.var(.99), float(d.cdf_at(100)), d.tvar(.99)) == before
        with pytest.raises(ValueError):
            A.mix([d, A.aggregate(S.Lomax(.5, 2).cdf, 20)])
    finally:
        A.set_grid(*old)
    assert float(d.cdf_at(-1)) == 0
    assert float(d.cdf_at(np.inf)) == 1


def test_fft_tilting_prevents_circular_aliasing_against_exact_poisson():
    old = (A.H, A.NX, A.NS)
    try:
        A.set_grid(1, 32, 64)
        pmf = np.zeros(32); pmf[16] = 1
        raw = A.compound_poisson(pmf, 5, tilt=0)
        fixed = A.compound_poisson(pmf, 5)
        indices = np.arange(4) * 16
        expected = stats.poisson.pmf(np.arange(4), 5)
        assert np.max(np.abs(raw[indices] - expected)) > .1
        np.testing.assert_allclose(fixed[indices], expected, atol=4e-8)
    finally:
        A.set_grid(*old)


def test_censored_capital_has_unbounded_loss_and_unknown_breach_probability():
    d = A.aggregate(S.Lomax(.5, 2).cdf, 20)
    out = SIM.score(np.inf, d, d.var(.995))
    assert out['capped'] and np.isinf(out['rel_over_upper'])
    assert np.isnan(out['p_breach']) and out['rel_under'] == 0
    assert out['p_breach_upper'] >= 0


def test_hurwicz_endpoints_with_unresolved_capital():
    assert D.hurwicz([100, np.inf], 0) == 100
    assert D.hurwicz([100, np.inf], 1) == np.inf
    assert D.hurwicz([100, np.inf], .5) == np.inf


def test_single_claim_probability_uses_negative_binomial_pgf():
    m = S.Lomax(.5, 2)
    _, p = ST.single_loss_scenario(m, 20, 500, 100, r=3)
    sf = float(m.sf(np.array([400]))[0])
    assert p == pytest.approx(1 - (1 + 20 * sf / 3)**(-3))


@pytest.mark.parametrize('weights', [[-1, 2], [0, 0], [1], [np.nan, 1]])
def test_invalid_mixture_weights_fail_explicitly(weights):
    d = A.aggregate(S.Lomax(.5, 2).cdf, 20)
    with pytest.raises(ValueError):
        A.mix([d, d], weights)
