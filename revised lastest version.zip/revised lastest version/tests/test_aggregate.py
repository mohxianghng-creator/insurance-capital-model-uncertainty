import numpy as np, pytest
from cmu import aggregate as A, severity as S
from cmu.config import H, NX, NS, CAP


def panjer_poisson(pmf, lam, n):
    """Exact Panjer recursion for compound Poisson with pmf on the lattice (independent implementation)."""
    g = np.zeros(n)
    g[0] = np.exp(-lam * (1 - pmf[0]))
    j = np.arange(1, len(pmf))
    for s in range(1, n):
        m = min(s, len(pmf) - 1)
        k = np.arange(1, m + 1)
        g[s] = lam / s * np.sum(k * pmf[k] * g[s - k])
    return g


def test_fft_matches_panjer_exactly():
    m = S.Spliced(10.0, -0.5, 1.1, 0.95, 0.5, 7.0)
    lam = 3.0                                    # small lambda so the Panjer lattice is short
    pmf = A.severity_pmf(m.cdf)
    g_fft = A.compound_poisson(pmf, lam)
    n = 6000
    g_ref = panjer_poisson(pmf[:3000], lam, n)   # truncate severity lattice for speed (mass beyond is negligible here)
    np.testing.assert_allclose(g_fft[:n], g_ref, atol=2e-6)


def test_sub_distribution_mass_equals_exp_minus_lambda_overflow():
    m = S.Lomax(1.2, 5.0)                        # heavy: overflow beyond CAP is material
    lam = 50.0
    pmf = A.severity_pmf(m.cdf)
    p_over = 1.0 - pmf.sum()
    g = A.compound_poisson(pmf, lam)
    assert p_over > 1e-4
    assert g.sum() == pytest.approx(np.exp(-lam * p_over), rel=1e-6)


def test_mean_matches_theory_shifted_exponential():
    xi = 1e-6                                    # ~ exponential on [1, inf)
    m = S.Lomax(xi, 2.0)
    d = A.aggregate(m.cdf, 40.0)
    assert d.mean_S == pytest.approx(40.0 * (1 + 2.0), rel=2e-3)


@pytest.mark.parametrize("r", [None, 40.0])
def test_against_monte_carlo(r):
    m = S.Spliced(10.0, -0.5, 1.1, 0.95, 0.5, 7.0)
    lam = 100.0
    d = A.aggregate(m.cdf, lam, r=r)
    rng = np.random.default_rng(3)
    ns = 150000
    N = rng.poisson(lam, ns) if r is None else rng.poisson(rng.gamma(r, lam / r, ns))
    xs = m.ppf(rng.random(N.sum()))
    Ssim = np.bincount(np.repeat(np.arange(ns), N), weights=xs, minlength=ns)
    assert d.mean_S == pytest.approx(Ssim.mean(), rel=0.03)
    for a in (0.5, 0.9, 0.99):
        assert d.var(a) == pytest.approx(np.quantile(Ssim, a), rel=0.04)


def test_negbin_dominates_poisson_in_tail():
    m = S.Spliced(10.0, -0.5, 1.1, 0.95, 0.5, 7.0)
    assert A.aggregate(m.cdf, 100.0, r=20.0).var(0.995) > A.aggregate(m.cdf, 100.0).var(0.995)
    a, b = A.aggregate(m.cdf, 100.0, r=1e7), A.aggregate(m.cdf, 100.0)
    assert a.var(0.995) == b.var(0.995)


def test_var_monotone_and_tvar_ge_var():
    d = A.aggregate(S.Lomax(0.6, 1.0).cdf, 100.0)
    v = [d.var(a) for a in (0.5, 0.9, 0.99, 0.995, 0.999)]
    assert all(np.diff(v) >= 0)
    tv, ok = d.tvar(0.99)
    assert tv >= d.var(0.99)
    assert not ok  # missing tail mass does not bound its expected excess


def test_var_inf_when_capital_exceeds_cap():
    d = A.aggregate(S.Lomax(1.8, 50.0).cdf, 200.0)
    assert d.var(0.995) == float("inf")


def test_retention_reduces_tail_and_pmf_sums_to_one():
    m = S.Lomax(0.7, 1.0)
    pmf = A.retained_pmf(m.cdf, 20.0)
    assert pmf.sum() == pytest.approx(1.0, abs=1e-12)
    assert pmf[int(20 / H) + 1:].sum() == 0
    assert A.aggregate(m.cdf, 100.0, retention=20.0).var(0.995) < A.aggregate(m.cdf, 100.0).var(0.995)


def test_expected_recovery_matches_quadrature():
    from scipy import integrate
    m = S.Spliced(10.0, -0.5, 1.1, 0.95, 0.5, 7.0)
    R = 20.0
    ref = integrate.quad(lambda t: 1 - m.cdf(np.array([t]))[0], R, 5e4, limit=500)[0]
    assert A.expected_recovery_per_claim(m.cdf, R) == pytest.approx(ref, rel=0.01)


def test_mixture_of_identical_equals_original_and_weights():
    m = S.Lomax(0.6, 1.0)
    d = A.aggregate(m.cdf, 100.0)
    mx = A.mix([d, d, d])
    assert mx.var(0.995) == d.var(0.995)
    d2 = A.aggregate(m.cdf, 150.0)
    assert d.var(0.995) <= A.mix([d, d2], [0.5, 0.5]).var(0.995) <= d2.var(0.995)


def test_scale_equivariance():
    m = S.Lomax(0.6, 1.0)
    base = A.aggregate(m.cdf, 60.0).var(0.99)
    assert A.aggregate(m.cdf, 60.0, scale=2.0).var(0.99) == pytest.approx(2 * base, rel=0.03)
