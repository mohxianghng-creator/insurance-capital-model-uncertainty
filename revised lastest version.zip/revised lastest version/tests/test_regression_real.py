"""Pinned numbers on the real data: guards against silent changes in estimators / aggregator."""
import numpy as np, pytest
from cmu import aggregate as A, frequency as F, decision as D, validation as V


def test_pinned_fits(fits, x):
    sp = fits["Spliced10"]
    assert sp.xi == pytest.approx(0.497, abs=0.002) and sp.beta == pytest.approx(6.975, abs=0.02)
    assert fits["Lomax"].xi == pytest.approx(0.611, abs=0.002)
    aics = np.array([fits[k].aic(x) for k in ("LN", "Lomax", "Spliced5", "Spliced10", "Spliced20")])
    assert np.argmin(aics) == 3
    d = aics - aics.min()
    assert d[0] == pytest.approx(16.6, abs=0.2) and d[1] == pytest.approx(9.4, abs=0.2)


def test_pinned_capital(fits, df):
    c = V.annual_counts(df, list(range(1980, 1991)))
    lam = F.PoissonConst().fit(c).forecast(1)
    assert lam == 197.0
    assert A.aggregate(fits["Spliced10"].cdf, lam).var(0.995) == 1298.0
    assert A.aggregate(fits["LN"].cdf, lam).var(0.995) == pytest.approx(1136.0, abs=2)


def test_plausible_set_membership(fits, x):
    aics = [fits[k].aic(x) for k in ("LN", "Lomax", "Spliced5", "Spliced10", "Spliced20")]
    assert list(D.plausible_mask(aics, 10.0)) == [False, True, True, True, False]
