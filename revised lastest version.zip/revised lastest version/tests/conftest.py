import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import numpy as np, pytest
from cmu import data, severity as S


@pytest.fixture(scope="session")
def df():
    return data.load_danish()


@pytest.fixture(scope="session")
def x(df):
    return df.loss.to_numpy()


@pytest.fixture(scope="session")
def fits(x):
    return {m.name: m.fit(x) for m in S.default_model_set()}
