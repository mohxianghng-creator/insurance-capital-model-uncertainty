"""Capital decision rules under model uncertainty.

Decision variable: V = capital requirement expressed as the VaR_alpha *resource level* of annual aggregate retained loss.
(Economic capital above expected loss = V - E[S] is reported separately.)

Rules compared (all deterministic functions of the data):
  D0  conventional  : AIC-best single model, plug-in MLE                      (baseline)
  D1  averaging     : VaR of Akaike-weighted bootstrap-predictive mixture     (pseudo-BMA, not full Bayes)
  D2  param-aware   : AIC-best model, bootstrap-predictive V (parameter+data uncertainty only)
  D3  robust(theta) : Hurwicz/minimax-regret over the plausible set  V = theta*max_m V_m + (1-theta)*min_m V_m,
                      V_m computed from each model's bootstrap-predictive distribution
  D4  worst-case    : D3 with theta = 1
Justification of D3 (Prop. 1, proved in paper App. A): with asymmetric linear loss
 L(V,V_m)=c_u (V_m-V)+ + c_o (V-V_m)+  the minimax-regret choice over a finite set with extremes (Vmin,Vmax) is
 V* = theta*Vmax + (1-theta)*Vmin with theta=c_u/(c_u+c_o).
"""
from __future__ import annotations
import numpy as np


def akaike_weights(aics):
    a = np.asarray(aics, float)
    d = a - a.min()
    w = np.exp(-0.5 * d)
    return d, w / w.sum()


def plausible_mask(aics, delta=10.0):
    d = np.asarray(aics, float) - np.min(aics)
    return d <= delta


def hurwicz(v_list, theta):
    v = np.asarray(v_list, float)
    if v.size == 0 or np.isnan(v).any() or (v < 0).any() or not 0 <= theta <= 1:
        raise ValueError("require nonempty nonnegative capital values and theta in [0,1]")
    # Avoid 0 * infinity at endpoints. Infinity means unresolved beyond the grid.
    if theta == 0:
        return float(v.min())
    if theta == 1:
        return float(v.max())
    return float(theta * v.max() + (1 - theta) * v.min())


def theta_from_costs(c_u, c_o):
    if not np.isfinite([c_u, c_o]).all() or min(c_u, c_o) <= 0:
        raise ValueError("costs must be finite and strictly positive")
    return c_u / (c_u + c_o)


def minimax_regret_numeric(v_set, c_u, c_o, grid=20001):
    """Brute-force minimax-regret V over a grid (used by tests to verify the closed form)."""
    v_set = np.asarray(v_set, float)
    cand = np.linspace(v_set.min(), v_set.max(), grid)
    reg = np.max(np.where(v_set[None, :] > cand[:, None],
                          c_u * (v_set[None, :] - cand[:, None]),
                          c_o * (cand[:, None] - v_set[None, :])), axis=1)
    return float(cand[np.argmin(reg)])


def linear_loss(v_hat, v_true, c_u, c_o):
    return c_u * np.maximum(v_true - v_hat, 0.0) + c_o * np.maximum(v_hat - v_true, 0.0)
