"""Global constants. Every numerical setting used in reported results lives here."""
ALPHA_VAR = 0.995      # VaR level for the annual aggregate (Solvency II-style *horizon/level*, NOT the SII formula)
ALPHA_TVAR = 0.99      # TVaR level reported alongside
LOWER = 1.0            # reporting threshold of the data (claims >= 1 million DKK)
H = 0.5                # discretisation step (million DKK) of the FFT aggregator
NX = 2 ** 15           # severity grid cells  -> per-claim cap C = NX*H = 16384
NS = 2 ** 17           # aggregate grid cells -> S range = NS*H = 65536
CAP = NX * H
SPLICE_US = (5.0, 10.0, 20.0)   # a-priori splice thresholds (million DKK)
DELTA_AIC_PLAUSIBLE = 10.0      # Burnham & Anderson: models with dAIC>10 have essentially no support
COST_OF_CAPITAL = 0.06          # stylised annual cost-of-capital rate (assumption)
SEED = 20261017
