"""Data ingestion + validation for the Danish fire insurance large-loss data.

Source: R package `evir` v1.7-4 (CRAN), dataset `danish`; 2167 fire losses >= 1 million DKK,
3 Jan 1980 - 31 Dec 1990, supplied by Mette Rytgaard (Copenhagen Re) per package documentation.
Retrieved from the CRAN read-only GitHub mirror (github.com/cran/evir). Licence of package: GPL (>= 2).
Monetary units / price basis are NOT stated in the package help page -> we treat units as
"millions of DKK, price basis undocumented" and never claim currency-adjusted real values.
"""
from __future__ import annotations
import hashlib, json, warnings
from pathlib import Path
import numpy as np
import pandas as pd

RAW = Path(__file__).resolve().parents[2] / "data" / "raw" / "danish.rda"
EXPECTED_N = 2167
EXPECTED_MD5 = "9defcdbc269e50aa95a1a9e7d36d1c68"
SOURCE_URL = "https://raw.githubusercontent.com/cran/evir/master/data/danish.rda"


def md5(path: Path) -> str:
    return hashlib.md5(path.read_bytes()).hexdigest()


def load_danish(path: Path = RAW, check_hash: bool = True) -> pd.DataFrame:
    """Return DataFrame[date, loss, year] sorted by date (stable order preserved)."""
    import rdata
    if check_hash and md5(path) != EXPECTED_MD5:
        raise ValueError(f"checksum mismatch for {path}")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        parsed = rdata.parser.parse_file(str(path))
    obj = parsed.object.value[0]
    loss = np.asarray(obj.value, dtype=float)
    attr = obj.attributes  # R pairlist: value=(car, cdr...) with car = REAL vector, tag 'times'
    tag = attr.tag.value.value.decode()
    if tag != "times":
        raise ValueError(f"unexpected attribute tag {tag!r}")
    times = np.asarray(attr.value[0].value, dtype=float)
    if len(times) != len(loss):
        raise ValueError("times/loss length mismatch")
    df = pd.DataFrame({"date": pd.to_datetime(times, unit="s").normalize(), "loss": loss})
    df["year"] = df["date"].dt.year
    return df


def validate(df: pd.DataFrame) -> dict:
    """Data-quality checks. Raises on hard failures, returns a report dict."""
    rep = {}
    rep["n"] = int(len(df))
    if rep["n"] != EXPECTED_N:
        raise ValueError(f"expected {EXPECTED_N} rows, got {rep['n']}")
    if df["loss"].isna().any() or not np.isfinite(df["loss"]).all():
        raise ValueError("non-finite losses")
    rep["min_loss"] = float(df["loss"].min())
    if rep["min_loss"] < 1.0 - 1e-9:
        raise ValueError("loss below the 1m reporting threshold")
    rep["max_loss"] = float(df["loss"].max())
    rep["dates_monotone"] = bool(df["date"].is_monotonic_increasing)
    rep["first_date"] = str(df["date"].iloc[0].date())
    rep["last_date"] = str(df["date"].iloc[-1].date())
    rep["n_distinct_loss_values"] = int(df["loss"].nunique())
    rep["n_exact_duplicate_rows"] = int(df.duplicated(["date", "loss"]).sum())
    rep["claims_per_year"] = {int(k): int(v) for k, v in df.groupby("year").size().items()}
    rep["n_claims_gt_10"] = int((df["loss"] > 10).sum())
    rep["n_claims_gt_20"] = int((df["loss"] > 20).sum())
    rep["n_claims_gt_50"] = int((df["loss"] > 50).sum())
    rep["n_claims_gt_100"] = int((df["loss"] > 100).sum())
    # same-day multiple claims are legitimate (irregular series); report share
    rep["share_days_with_multiple_claims"] = float((df.groupby("date").size() > 1).mean())
    # temporal dependence / drift diagnostics on log-severity (reported, not 'fixed')
    from scipy import stats
    t = (df["date"] - df["date"].iloc[0]).dt.days.to_numpy()
    rho, p = stats.spearmanr(t, np.log(df["loss"]))
    rep["spearman_time_vs_logloss"] = {"rho": float(rho), "p": float(p)}
    ll = np.log(df["loss"].to_numpy())
    rep["lag1_autocorr_logloss"] = float(np.corrcoef(ll[:-1], ll[1:])[0, 1])
    return rep


def write_processed(out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    df = load_danish()
    rep = validate(df)
    df.to_csv(out_dir / "danish_fire_losses.csv", index=False)
    card = {
        "source": SOURCE_URL, "package": "evir 1.7-4 (CRAN, GPL>=2)", "raw_md5": EXPECTED_MD5,
        "retrieved": "2026-10-17", "units": "million DKK (price basis undocumented in package help)",
        "variables": {"date": "claim date (POSIXct normalised to day)", "loss": "claim size >= 1.0",
                      "year": "calendar year of date"},
        "coverage": "Denmark, large fire claims, 1980-01-03..1990-12-31; irregular series",
        "known_limitations": [
            "Only claims >= 1m (left-truncated): no information on attritional claims or on exposure.",
            "No exposure measure: frequency trend cannot be separated from portfolio growth/inflation.",
            "Inflation/price basis not documented in the package help page.",
            "Industry-level data for one peril and one decade; not a particular insurer's book.",
            "Only 11 annual aggregates: tail of the *aggregate* distribution is barely observed.",
        ],
        "validation": rep,
    }
    (out_dir / "data_card.json").write_text(json.dumps(card, indent=2))
    return card
