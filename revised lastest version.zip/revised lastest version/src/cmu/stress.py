"""Reverse stress testing: start from a capital level K and find the scenarios that exhaust it.

Stress parameterisation (all scenario uncertainty, outside the fitted history):
  phi  : frequency multiplier  (lambda -> phi*lambda)
  s    : severity scale multiplier (X -> s*X; e.g. claims/social inflation) - applies to every model
  dxi  : additive shift of GPD tail index (only models with a GPD tail)
Outputs: break-even values, 2-D frontier, single-loss scenario, and the *implied return period*
of the stress under every plausible model (reveals hidden disagreement about how remote the breach is).
"""
from __future__ import annotations
import numpy as np
from scipy import optimize
from . import aggregate as A
from .config import ALPHA_VAR, CAP


def _var(model, lam, phi=1.0, s=1.0, dxi=0.0, alpha=ALPHA_VAR, r=None):
    m = model.with_tail_shift(dxi) if dxi != 0.0 else model
    return A.aggregate(m.cdf, lam * phi, scale=s, r=r).var(alpha)


def breach_prob(model, lam, K, phi=1.0, s=1.0, dxi=0.0, r=None):
    m = model.with_tail_shift(dxi) if dxi != 0.0 else model
    return A.aggregate(m.cdf, lam * phi, scale=s, r=r).breach_prob(K)


def _smallest_breach(breached, lo, hi, tol=1e-5, it=80):
    """Smallest z in [lo,hi] with breached(z)=True, assuming monotonicity. lo if already breached, inf if never."""
    if breached(lo):
        return lo
    if not breached(hi):
        return float("inf")
    for _ in range(it):
        mid = 0.5 * (lo + hi)
        if breached(mid):
            hi = mid
        else:
            lo = mid
        if hi - lo < tol * max(1.0, abs(hi)):
            break
    return hi


def breakeven(model, lam, K, kind, alpha=ALPHA_VAR, hi=None, r=None):
    """Smallest stress of `kind` in {'phi','s','dxi'} such that VaR_alpha(stressed) >= K.
    VaR = +inf (capital beyond the aggregation cap) counts as breached."""
    if not np.isfinite(K) or not 0 < K < A.CAP:
        raise ValueError("resource threshold must be positive and resolved below the active grid ceiling")
    if kind not in {'phi', 's', 'dxi'}:
        raise ValueError("unknown stress kind")
    def breached(z):
        v = _var(model, lam, alpha=alpha, r=r, **{kind: z})
        return (not np.isfinite(v)) or v >= K
    if kind == "dxi":
        return _smallest_breach(breached, 0.0, hi or 1.5)
    return _smallest_breach(breached, 1.0, hi or 20.0)


def frontier(model, lam, K, phis, alpha=ALPHA_VAR, r=None):
    """For each frequency multiplier phi, the smallest severity multiplier s with VaR_alpha >= K."""
    if not np.isfinite(K) or not 0 < K < A.CAP:
        raise ValueError("resource threshold must be positive and below the active grid ceiling")
    out = []
    for p in phis:
        def breached(z, p=p):
            v = _var(model, lam, phi=p, s=z, alpha=alpha, r=r)
            return (not np.isfinite(v)) or v >= K
        out.append(_smallest_breach(breached, 0.05, 20.0))
    return np.array(out)


def single_loss_scenario(model, lam, K, expected_S, r=None):
    """Smallest single claim x* that, added to a *typical* year (expected loss), exhausts K: x* = K - E[S].
    Return x*, annual probability that at least one claim >= x* occurs under the model."""
    x_star = K - expected_S
    p = 1.0 - float(model.cdf(np.array([x_star]))[0])
    # Poisson thinning or the NB probability-generating function at (1-p).
    annual = -np.expm1(-lam * p) if r is None else -np.expm1(-r * np.log1p(lam * p / r))
    return float(x_star), float(annual)
