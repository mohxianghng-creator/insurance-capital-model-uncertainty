"""Finite per-occurrence layers; prices and annual capital budgets are assumptions."""
import numpy as np
from scipy.integrate import quad


def layer_recovery(model, retention, limit):
    """E[min((X-retention)+, limit)] including for infinite-mean gross models."""
    if not np.isfinite([retention, limit]).all() or retention < 0 or limit <= 0:
        raise ValueError('require finite retention >= 0 and limit > 0')
    points = [p for p in (1., getattr(model, 'u', 0.)) if retention < p < retention + limit]
    return float(quad(lambda x: float(model.sf(np.array([x]))[0]), retention,
                      retention + limit, points=points, epsabs=1e-9, epsrel=1e-8)[0])


class LayerRetained:
    """Y = X - min((X-R)+, L). Losses above R+L return to the insurer."""
    def __init__(self, model, retention, limit):
        self.model, self.retention, self.limit = model, float(retention), float(limit)
        self.recovery = layer_recovery(model, retention, limit)

    def cdf(self, x):
        x = np.asarray(x, float)
        return self.model.cdf(np.where(x < self.retention, x, x + self.limit))

    def stop_loss(self, retention):
        t = float(retention)
        gross = self.model.stop_loss(t)
        if not np.isfinite(gross):
            return np.inf
        if t <= self.retention:
            return max(0., gross - self.recovery)
        return self.model.stop_loss(t + self.limit)
