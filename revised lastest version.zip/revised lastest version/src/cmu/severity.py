"""Severity models for claims left-truncated at LOWER (=1m). All share one interface.

Models (a deliberately small, justified set):
  LN        truncated lognormal                       2 params  - light/medium tail benchmark
  Lomax     GPD on all excesses over LOWER            2 params  - single heavy-tail law
  Spliced_u truncated-LN body on [LOWER,u) + GPD tail  5 params  - EVT-style (Peaks-over-threshold);
            u in {5,10,20} fixed a priori (threshold choice = a source of *model* uncertainty)
GPD shape is constrained to [XI_MIN, XI_MAX]; this is a modelling restriction (positive-shape tails only).
"""
from __future__ import annotations
import numpy as np
from scipy import optimize, special
from .config import LOWER

XI_MIN, XI_MAX = 1e-6, 5.0


# ---------------------------------------------------------------- GPD helpers
def gpd_sf(y, xi, beta):
    y = np.maximum(np.asarray(y, float), 0.0)
    return np.exp(-np.log1p(xi * y / beta) / xi)


def gpd_logpdf(y, xi, beta):
    y = np.asarray(y, float)
    return -np.log(beta) - (1.0 / xi + 1.0) * np.log1p(xi * y / beta)


def gpd_ppf(u, xi, beta):
    u = np.asarray(u, float)
    return beta / xi * (np.expm1(-xi * np.log1p(-u)))


def gpd_stop_loss(y, xi, beta):
    """Unconditional E[(Y-y)+] for a GPD, including infinite-mean tails."""
    if xi >= 1:
        return float("inf")
    return float(gpd_sf(y, xi, beta) * (beta + xi * y) / (1 - xi))


def fit_gpd(y: np.ndarray) -> tuple[float, float]:
    """MLE of GPD(xi>0, beta) via 1-D profile likelihood in theta=xi/beta (Grimshaw 1993)."""
    y = np.asarray(y, float)
    n = len(y)
    if n < 8:
        raise ValueError("too few exceedances for GPD fit")
    ybar = y.mean()

    def prof(logth):
        th = np.exp(logth)
        xi = np.mean(np.log1p(th * y))
        return n * (np.log(xi / th) + xi + 1.0)  # negative profile log-lik

    grid = np.linspace(np.log(1e-8 / ybar), np.log(1e3 / ybar), 120)
    vals = np.array([prof(g) for g in grid])
    i = int(np.nanargmin(vals))
    lo, hi = grid[max(i - 1, 0)], grid[min(i + 1, len(grid) - 1)]
    r = optimize.minimize_scalar(prof, bounds=(lo, hi), method="bounded", options={"xatol": 1e-9})
    th = np.exp(r.x)
    xi = float(np.mean(np.log1p(th * y)))
    if xi < 1e-4:                      # exponential-tail boundary: constrained MLE has beta = mean excess
        return XI_MIN, float(ybar)     # (BUG FIXED: clipping xi alone made beta = xi_clipped/theta explode)
    xi = float(np.clip(xi, XI_MIN, XI_MAX))
    return xi, float(xi / th)


# ---------------------------------------------------------------- truncated lognormal
class _TruncLN:
    """Lognormal(mu, sigma) truncated to [a, b)."""

    def __init__(self, mu, sigma, a=LOWER, b=np.inf):
        self.mu, self.sigma, self.a, self.b = float(mu), float(sigma), float(a), float(b)
        self.za = (np.log(a) - mu) / sigma
        self.zb = np.inf if not np.isfinite(b) else (np.log(b) - mu) / sigma
        if np.isfinite(b):
            self.mass = special.ndtr(self.zb) - special.ndtr(self.za)
        else:
            self.mass = special.ndtr(-self.za)
        self.mass = max(self.mass, 1e-300)

    def cdf(self, x):
        x = np.asarray(x, float)
        xc = np.clip(x, self.a, self.b if np.isfinite(self.b) else np.inf)
        z = (np.log(np.maximum(xc, 1e-300)) - self.mu) / self.sigma
        if np.isfinite(self.b):
            c = (special.ndtr(z) - special.ndtr(self.za)) / self.mass
        else:
            c = 1.0 - special.ndtr(-z) / special.ndtr(-self.za)
        c = np.where(x < self.a, 0.0, c)
        return np.clip(c, 0.0, 1.0)

    def logpdf(self, x):
        x = np.asarray(x, float)
        z = (np.log(x) - self.mu) / self.sigma
        return -np.log(self.sigma * x) - 0.5 * z * z - 0.5 * np.log(2 * np.pi) - np.log(self.mass)

    def ppf(self, u):
        u = np.asarray(u, float)
        if np.isfinite(self.b):
            p = special.ndtr(self.za) + u * (special.ndtr(self.zb) - special.ndtr(self.za))
            z = special.ndtri(np.clip(p, 1e-300, 1 - 1e-16))
        else:  # use survival-side inversion for accuracy in the far tail
            z = -special.ndtri(np.clip((1.0 - u) * special.ndtr(-self.za), 1e-300, 1.0))
        return np.exp(self.mu + self.sigma * z)

    def stop_loss(self, retention):
        r = float(retention)
        if r >= self.b:
            return 0.0
        lo = max(r, self.a)
        zl = (np.log(lo) - self.mu) / self.sigma
        # Survival-side subtraction avoids cancellation in the far right tail.
        first = np.exp(self.mu + self.sigma ** 2 / 2) * (
            special.ndtr(self.sigma - zl) - special.ndtr(self.sigma - self.zb)) / self.mass
        prob = (special.ndtr(-zl) - special.ndtr(-self.zb)) / self.mass
        return float(max(first - r * prob, 0.0))


def fit_trunc_ln(x: np.ndarray, a: float = LOWER, b: float = np.inf) -> tuple[float, float]:
    x = np.asarray(x, float)
    if x.ndim != 1 or len(x) < 2 or not np.isfinite(x).all() or (x < a).any() or (x >= b).any():
        raise ValueError("require at least two finite observations inside the truncation interval")
    lx = np.log(x)

    # Analytic score avoids thousands of derivative-free evaluations in nested
    # simulations. Keep the original multi-start simplex fit as a fallback.
    def value_score(p):
        mu, ls = p
        s = np.exp(ls)
        za = (np.log(a) - mu) / s
        zb = (np.log(b) - mu) / s if np.isfinite(b) else np.inf
        if za > 0:
            lbig, lsmall = special.log_ndtr(-za), special.log_ndtr(-zb)
        else:
            lbig, lsmall = special.log_ndtr(zb), special.log_ndtr(za)
        if lsmall >= lbig:
            return 1e100, np.zeros(2)
        logmass = lbig + np.log(-np.expm1(lsmall - lbig))
        ra = np.exp(-.5 * za * za - .5 * np.log(2 * np.pi) - logmass)
        rb = 0.0 if not np.isfinite(zb) else np.exp(-.5 * zb * zb - .5 * np.log(2 * np.pi) - logmass)
        z = (lx - mu) / s
        value = len(x) * (ls + .5 * np.log(2 * np.pi) + logmass) + lx.sum() + .5 * np.dot(z, z)
        score = np.array([-z.sum() / s + len(x) * (ra - rb) / s,
                          len(x) - np.dot(z, z) + len(x) * (za * ra - (zb * rb if rb else 0.0))])
        return value, score

    m0, s0 = lx.mean(), max(lx.std(), 0.2)
    candidates = []
    for start in ([m0, np.log(s0)], [m0 - .3, np.log(s0 * 1.3)]):
        result = optimize.minimize(value_score, start, jac=True, method="L-BFGS-B",
                                   bounds=[(None, None), (np.log(1e-3), np.log(20))],
                                   options={"ftol": 1e-13, "gtol": 1e-6, "maxiter": 500})
        if result.success and np.isfinite(result.fun) and np.max(np.abs(result.jac)) < 1e-3:
            candidates.append(result)
    if candidates:
        best = min(candidates, key=lambda r: r.fun)
        return float(best.x[0]), float(np.exp(best.x[1]))

    def nll(p):
        mu, ls = p
        s = np.exp(ls)
        if s < 1e-3 or s > 20:
            return 1e12
        t = _TruncLN(mu, s, a, b)
        return -np.sum(t.logpdf(x))

    best = None
    for start in ([m0, np.log(s0)], [m0 - 0.3, np.log(s0 * 1.3)], [m0 + 0.5, np.log(s0 * 0.7)]):
        r = optimize.minimize(nll, start, method="Nelder-Mead",
                              options={"xatol": 1e-7, "fatol": 1e-9, "maxiter": 800})
        if best is None or r.fun < best.fun:
            best = r
    if not best.success or not np.isfinite(best.fun):
        raise ValueError("truncated lognormal optimisation did not converge")
    return float(best.x[0]), float(np.exp(best.x[1]))


# ---------------------------------------------------------------- model classes
class Severity:
    name = "base"
    n_params = 0
    has_gpd_tail = False

    def fit(self, x): raise NotImplementedError
    def cdf(self, x): raise NotImplementedError
    def logpdf(self, x): raise NotImplementedError
    def ppf(self, u): raise NotImplementedError
    def params(self) -> dict: raise NotImplementedError
    def stop_loss(self, retention): raise NotImplementedError

    def sf(self, x):
        return 1.0 - self.cdf(x)

    def loglik(self, x):
        return float(np.sum(self.logpdf(np.asarray(x, float))))

    def aic(self, x):
        return 2 * self.n_params - 2 * self.loglik(x)

    def with_tail_shift(self, delta):
        raise NotImplementedError(f"{self.name} has no GPD tail index")

    def clone(self):
        import copy
        return copy.deepcopy(self)


class LN(Severity):
    name, n_params = "LN", 2

    def __init__(self, mu=None, sigma=None):
        self.mu, self.sigma = mu, sigma

    def fit(self, x):
        self.mu, self.sigma = fit_trunc_ln(x)
        self._d = _TruncLN(self.mu, self.sigma)
        return self

    def _dist(self):
        return _TruncLN(self.mu, self.sigma)

    def cdf(self, x): return self._dist().cdf(x)
    def logpdf(self, x): return self._dist().logpdf(x)
    def ppf(self, u): return self._dist().ppf(u)
    def params(self): return {"mu": self.mu, "sigma": self.sigma}
    def stop_loss(self, retention): return self._dist().stop_loss(retention)


class Lomax(Severity):
    name, n_params, has_gpd_tail = "Lomax", 2, True

    def __init__(self, xi=None, beta=None):
        self.xi, self.beta = xi, beta

    def fit(self, x):
        self.xi, self.beta = fit_gpd(np.asarray(x, float) - LOWER)
        return self

    def cdf(self, x):
        x = np.asarray(x, float)
        return np.where(x <= LOWER, 0.0, 1.0 - gpd_sf(x - LOWER, self.xi, self.beta))

    def stop_loss(self, retention):
        return max(LOWER - retention, 0.0) + gpd_stop_loss(max(retention - LOWER, 0.0), self.xi, self.beta)

    def logpdf(self, x): return gpd_logpdf(np.asarray(x, float) - LOWER, self.xi, self.beta)
    def ppf(self, u): return LOWER + gpd_ppf(u, self.xi, self.beta)
    def params(self): return {"xi": self.xi, "beta": self.beta}

    def with_tail_shift(self, delta):
        m = self.clone(); m.xi = float(self.xi + delta); return m


class Spliced(Severity):
    has_gpd_tail = True
    n_params = 5  # mu, sigma, p_body, xi, beta (u fixed a priori and not counted)

    def __init__(self, u=10.0, mu=None, sigma=None, p=None, xi=None, beta=None):
        self.u, self.mu, self.sigma, self.p, self.xi, self.beta = u, mu, sigma, p, xi, beta
        self.name = f"Spliced{int(u)}"

    def fit(self, x):
        x = np.asarray(x, float)
        body, tail = x[x < self.u], x[x >= self.u]
        if len(tail) < 8 or len(body) < 20:
            raise ValueError("insufficient data on one side of the splice")
        self.p = len(body) / len(x)
        self.mu, self.sigma = fit_trunc_ln(body, LOWER, self.u)
        self.xi, self.beta = fit_gpd(tail - self.u)
        return self

    def _body(self): return _TruncLN(self.mu, self.sigma, LOWER, self.u)

    def cdf(self, x):
        x = np.asarray(x, float)
        cb = self.p * self._body().cdf(np.minimum(x, self.u))
        ct = self.p + (1 - self.p) * (1.0 - gpd_sf(np.maximum(x - self.u, 0), self.xi, self.beta))
        return np.where(x < self.u, cb, ct)

    def logpdf(self, x):
        x = np.asarray(x, float)
        out = np.empty_like(x)
        m = x < self.u
        out[m] = np.log(self.p) + self._body().logpdf(x[m])
        out[~m] = np.log1p(-self.p) + gpd_logpdf(x[~m] - self.u, self.xi, self.beta)
        return out

    def ppf(self, u):
        u = np.asarray(u, float)
        out = np.empty_like(u)
        m = u < self.p
        out[m] = self._body().ppf(u[m] / self.p)
        out[~m] = self.u + gpd_ppf((u[~m] - self.p) / (1 - self.p), self.xi, self.beta)
        return out

    def params(self):
        return {"u": self.u, "mu": self.mu, "sigma": self.sigma, "p_body": self.p, "xi": self.xi, "beta": self.beta}

    def stop_loss(self, retention):
        r = float(retention)
        if r >= self.u:
            return (1 - self.p) * gpd_stop_loss(r - self.u, self.xi, self.beta)
        return self.p * self._body().stop_loss(r) + (1 - self.p) * (
            self.u - r + gpd_stop_loss(0.0, self.xi, self.beta))

    def with_tail_shift(self, delta):
        m = self.clone(); m.xi = float(self.xi + delta); return m


class PiecewiseTail(Severity):
    """Data-generating process for the 'structural break in the tail' world (NOT in the fitted model class):
    Spliced body/tail at u, GPD(xi1) on [u, v), GPD(xi2) beyond v (continuous survival)."""
    name, n_params, has_gpd_tail = "PiecewiseTail", 7, True

    def __init__(self, base: Spliced, v: float, xi2: float):
        self.base, self.v, self.xi2 = base, v, xi2
        self.name = f"PiecewiseTail(v={v},xi2={xi2})"
        b = base
        self.sf_v = (1 - b.p) * gpd_sf(v - b.u, b.xi, b.beta)

    def cdf(self, x):
        x = np.asarray(x, float)
        b = self.base
        c1 = b.cdf(np.minimum(x, self.v))
        # beyond v: survival decays as GPD with shape xi2 and scale chosen s.t. density-continuous at v
        beta2 = b.beta + b.xi * (self.v - b.u)           # GPD scale at v under base tail
        sf2 = self.sf_v * gpd_sf(np.maximum(x - self.v, 0), self.xi2, beta2)
        return np.where(x < self.v, c1, 1.0 - sf2)

    def ppf(self, u):
        u = np.asarray(u, float)
        b = self.base
        out = np.empty_like(u)
        m = u < 1 - self.sf_v
        out[m] = b.ppf(u[m])
        beta2 = b.beta + b.xi * (self.v - b.u)
        out[~m] = self.v + gpd_ppf(1 - (1 - u[~m]) / self.sf_v, self.xi2, beta2)
        return out

    def logpdf(self, x): raise NotImplementedError
    def params(self): return {"base": self.base.params(), "v": self.v, "xi2": self.xi2}

    def stop_loss(self, retention):
        r = float(retention)
        beta2 = self.base.beta + self.base.xi * (self.v - self.base.u)
        tail = self.sf_v * gpd_stop_loss(max(r - self.v, 0.0), self.xi2, beta2)
        if r >= self.v:
            return tail
        if self.base.xi >= 1:
            from scipy.integrate import quad
            body = quad(lambda t: float(self.base.sf(t)), r, self.v)[0]
        else:
            body = self.base.stop_loss(r) - self.base.stop_loss(self.v)
        return float(body + tail)


def default_model_set() -> list[Severity]:
    from .config import SPLICE_US
    return [LN(), Lomax()] + [Spliced(u) for u in SPLICE_US]
