"""Second real dataset: Norwegian fire insurance losses (CASdatasets `norfire`).
9,181 fire losses 1972-1992 from an unknown Norwegian company, NOK thousands, priority (retention/threshold) 500 thousand NOK
(R package CASdatasets 1.2-1, GPL>=2; source: lstat.kuleuven.be; Beirlant-Teugels-Vynckier 1996).
Retrieved 2026-10-18 from https://raw.githubusercontent.com/dutangc/CASdatasets/master/data/norfire.rda
We use nominal `Loss`, window 1985-1992 (counts have grown ~6x since 1972, i.e. portfolio growth/threshold inflation; the 1985+ counts are
flat-ish), severity expressed in units of the 500k threshold so that the engine's left-truncation point is 1.0.
The CPI-adjusted `Loss2012` column is NOT used: the 500k priority is nominal, so the truncation point in 2012 money varies by year."""
from __future__ import annotations
import hashlib, json, warnings
from pathlib import Path
import numpy as np, pandas as pd

RAW = Path(__file__).resolve().parents[2] / "data" / "raw" / "norfire.rda"
EXPECTED_MD5 = "d79a19ad111bf85ae94a3d5ff746eed5"
THRESHOLD = 500.0
SOURCE_URL = "https://raw.githubusercontent.com/dutangc/CASdatasets/master/data/norfire.rda"


def load_norfire(path: Path = RAW, first_year: int = 1985) -> pd.DataFrame:
    import rdata
    if hashlib.md5(path.read_bytes()).hexdigest() != EXPECTED_MD5:
        raise ValueError("checksum mismatch for norfire.rda")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d = rdata.read_rda(str(path))["norfire"]
    d = pd.DataFrame({"year": d["Year"].astype(int).to_numpy(), "loss_nok_k": d["Loss"].astype(float).to_numpy()})
    if len(d) != 9181 or d.loss_nok_k.min() < THRESHOLD - 1e-9:
        raise ValueError("unexpected norfire content")
    d = d[d.year >= first_year].reset_index(drop=True)
    d["loss"] = d.loss_nok_k / THRESHOLD          # threshold units, >= 1
    return d


def validate(d: pd.DataFrame) -> dict:
    from scipy import stats
    c = d.groupby("year").size()
    rho, p = stats.spearmanr(d.year, np.log(d.loss))
    return {"n": int(len(d)), "years": [int(c.index.min()), int(c.index.max())], "counts": {int(k): int(v) for k, v in c.items()},
            "dispersion_index": float(c.var(ddof=1) / c.mean()), "max_loss_units": float(d.loss.max()),
            "n_gt_10_units": int((d.loss > 10).sum()), "n_gt_100_units": int((d.loss > 100).sum()),
            "spearman_year_vs_logloss": {"rho": float(rho), "p": float(p)},
            "median_by_year": {int(k): float(v) for k, v in d.groupby("year").loss.median().items()}}
