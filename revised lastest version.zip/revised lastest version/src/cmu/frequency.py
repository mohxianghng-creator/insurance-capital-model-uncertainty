"""Annual claim-count models (Poisson). F1 constant rate; F2 log-linear time trend.
No exposure data exist for this dataset, so a trend conflates portfolio growth, inflation of the
reporting threshold, and genuine frequency change -> treated as *model* uncertainty, not as truth."""
from __future__ import annotations
import numpy as np


class PoissonConst:
    name = "PoissonConst"
    r = None  # no over-dispersion parameter

    def fit(self, counts):
        c = np.asarray(counts, float)
        self.T = len(c)
        self.lam = float(c.mean())
        return self

    def forecast(self, h=1):
        return self.lam

    def fitted(self):
        return np.full(self.T, self.lam)

    def n_params(self): return 1

    def loglik(self, counts):
        from scipy.special import gammaln
        c = np.asarray(counts, float)
        return float(np.sum(c * np.log(self.lam) - self.lam - gammaln(c + 1)))

    def simulate_counts(self, rng):
        return rng.poisson(self.fitted())


class PoissonTrend:
    name = "PoissonTrend"
    r = None

    def fit(self, counts):
        c = np.asarray(counts, float)
        self.T = len(c)
        t = np.arange(self.T, dtype=float) - (self.T - 1) / 2.0   # centred time
        X = np.column_stack([np.ones(self.T), t])
        beta = np.array([np.log(c.mean()), 0.0])
        for _ in range(100):  # Newton / IRLS
            mu = np.exp(X @ beta)
            g = X.T @ (c - mu)
            Hm = X.T @ (X * mu[:, None])
            step = np.linalg.solve(Hm, g)
            beta = beta + step
            if np.max(np.abs(step)) < 1e-10:
                break
        self.beta, self._t0 = beta, (self.T - 1) / 2.0
        return self

    def _rate(self, tidx):
        return np.exp(self.beta[0] + self.beta[1] * (np.asarray(tidx, float) - self._t0))

    def forecast(self, h=1):
        return float(self._rate(self.T - 1 + h))

    def fitted(self):
        return self._rate(np.arange(self.T))

    def n_params(self): return 2

    def loglik(self, counts):
        from scipy.special import gammaln
        c = np.asarray(counts, float); mu = self.fitted()
        return float(np.sum(c * np.log(mu) - mu - gammaln(c + 1)))

    def simulate_counts(self, rng):
        return rng.poisson(self.fitted())


class NegBinConst:
    """Negative-binomial counts with constant mean, Var = m + m^2/r (method-of-moments r; r->inf is Poisson).
    Added because the annual counts are strongly over-dispersed (index ~4.9) which a constant-rate Poisson ignores."""
    name = "NegBinConst"

    def fit(self, counts):
        c = np.asarray(counts, float)
        self.T = len(c)
        self.lam = float(c.mean())
        v = float(c.var(ddof=1)) if self.T > 1 else self.lam
        self.r = float(min(self.lam ** 2 / (v - self.lam), 1e6)) if v > self.lam * 1.0001 else 1e6
        return self

    def forecast(self, h=1):
        return self.lam

    def fitted(self):
        return np.full(self.T, self.lam)

    def n_params(self): return 2

    def loglik(self, counts):
        from scipy import stats
        c = np.asarray(counts, float)
        return float(np.sum(stats.nbinom.logpmf(c, self.r, self.r / (self.r + self.lam))))

    def simulate_counts(self, rng):
        return rng.poisson(rng.gamma(self.r, self.lam / self.r, size=self.T))


FREQ_NAMES = ("PoissonConst", "NegBinConst", "PoissonTrend")


def make(name):
    return {"PoissonConst": PoissonConst, "PoissonTrend": PoissonTrend, "NegBinConst": NegBinConst}[name]()
