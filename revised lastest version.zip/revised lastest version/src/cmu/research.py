"""Expanded-grid research calculations, isolated from historical saved results.

Grid changes are process-local and restored even on failure. Do not call these
functions concurrently from threads. Independent worker processes are safe.
"""
from contextlib import contextmanager
import numpy as np
from . import aggregate as A, severity as S, uncertainty as U, decision as D, frequency as F


@contextmanager
def grid_context(h, nx, ns):
    previous = A.H, A.NX, A.NS
    try:
        A.set_grid(h, nx, ns)
        yield
    finally:
        A.set_grid(*previous)


def distribution(specs, weights=None, grid=None):
    """Reaggregate saved (severity, annual mean count, NB dispersion) draws."""
    if not specs:
        raise ValueError("empty predictive specification")
    w = np.ones(len(specs)) if weights is None else np.asarray(weights, float)
    if w.shape != (len(specs),) or not np.isfinite(w).all() or (w < 0).any() or w.sum() <= 0:
        raise ValueError("invalid predictive weights")
    w = w / w.sum()
    grid = grid or (A.H, A.NX, A.NS)
    with grid_context(*grid):
        spectrum = np.zeros(A.NS // 2 + 1, complex)
        damping = np.exp(-16 * np.arange(A.NS) / A.NS)
        severity_grid = np.arange(A.NX) * A.H
        mean = mean_grid = 0.0
        for (m, lam, r), wi in zip(specs, w):
            if wi == 0:
                continue
            pmf = A.severity_pmf(m.cdf)
            padded = np.zeros(A.NS)
            padded[:A.NX] = pmf
            phi = np.fft.rfft(padded * damping)
            pgf = np.exp(lam * (phi - 1)) if r is None or r > 1e5 else np.exp(-r * np.log(1 + lam/r * (1-phi)))
            spectrum += wi * pgf
            mean += wi * lam * m.stop_loss(0)
            mean_grid += wi * lam * np.dot(severity_grid, pmf)
        # Inverse FFT is linear: average conditional aggregate spectra, then
        # invert once. This is a predictive mixture, not average parameters.
        accum = np.maximum(np.fft.irfft(spectrum, n=A.NS) / damping, 0)
        result = A.AggDist(accum, 1, 0)
        result.mean_S, result.mean_S_grid = mean, mean_grid
        return result


def resolve_capital(specs, initial=None, weights=None, alpha=.995,
                    max_cap=2**21, tolerance=.005):
    """Resolve a predictive quantile without interpreting the old ceiling as infinity.

    Original-grid finite values are retained. Unresolved values are recomputed
    on larger domains; after resolution, halve the step at the same domain.
    Acceptance requires agreement within 0.5% by default. Failures stay censored
    at the *last evaluated* ceiling. This is numerical evidence, not calibration.
    """
    d = initial if initial is not None else distribution(specs, weights)
    q = d.var(alpha)
    info = dict(expanded=False, resolved=bool(np.isfinite(q)), ceiling=d.cap,
                h=d.h, relative_refinement_change=0.0)
    if np.isfinite(q):
        return q, info
    cap = d.cap
    while cap < max_cap:
        cap = min(cap * 4, max_cap)
        nx = min(2**18, int(round(cap / .5)))
        h = cap / nx
        coarse = distribution(specs, weights, (h, nx, nx))
        q = coarse.var(alpha)
        info.update(expanded=True, ceiling=cap, h=h, resolved=False)
        if not np.isfinite(q):
            continue
        fine = distribution(specs, weights, (h / 2, 2 * nx, 2 * nx))
        qf = fine.var(alpha)
        change = abs(qf - q) / max(qf, 1) if np.isfinite(qf) else np.inf
        info.update(h=h / 2, relative_refinement_change=float(change))
        if change <= tolerance:
            info['resolved'] = True
            return qf, info
        # A failed refinement is not evidence that capital exceeds the ceiling.
        # Scoring it as a right-censored capital would create a false loss bound.
        raise RuntimeError('expanded capital fails grid refinement; refine the domain before scoring')
    return np.inf, info


def bootstrap_specs(model, x, counts, B, rng):
    """The same bootstrap fit law as U.bootstrap_capital, without unused draw FFTs."""
    x = np.asarray(x, float)
    f0 = F.PoissonConst().fit(counts)
    specs = []
    for _ in range(B):
        xb = x[rng.integers(0, len(x), len(x))]
        try:
            fitted = model.clone().fit(xb)
        except ValueError:
            continue
        fb = F.PoissonConst().fit(f0.simulate_counts(rng))
        specs.append((fitted, fb.forecast(1), fb.r))
    if len(specs) < max(1, int(np.ceil(.9 * B))):
        raise RuntimeError(f'only {len(specs)}/{B} bootstrap fits succeeded')
    return specs


def current_decisions(x, counts, rng, B=80, max_cap=2**21):
    """Current-engine rules with cached fits and individually resolved predictives."""
    fits = U.fit_all(S.default_model_set(), x)
    aics = [m.aic(x) for m in fits]
    da, weights = D.akaike_weights(aics)
    keep = np.flatnonzero(da <= 10)
    best = int(np.argmin(aics))
    lam = float(np.mean(counts))
    plug, pi = resolve_capital([(fits[best], lam, None)], max_cap=max_cap)
    values, details, draws, mixtures = {}, {}, {}, {}
    for i in keep:
        specs = bootstrap_specs(fits[i], x, counts, B, rng)
        mixture = distribution(specs)
        values[i], details[i] = resolve_capital(specs, mixture, max_cap=max_cap)
        draws[i], mixtures[i] = specs, mixture
    idx = list(keep)
    mix = A.mix([mixtures[i] for i in idx], weights[idx])
    all_specs = [spec for i in idx for spec in draws[i]]
    all_weights = [weights[i] / len(draws[i]) for i in idx for _ in draws[i]]
    averaged, ai = resolve_capital(all_specs, mix, all_weights, max_cap=max_cap)
    out = {'D0_aic_plugin': plug, 'D1_bma_mixture': averaged,
           'D2_aic_bootpred': values[best]}
    diagnostics = {'D0_aic_plugin': pi, 'D1_bma_mixture': ai,
                   'D2_aic_bootpred': details[best]}
    for theta in (0, .5, .75, 1):
        name = f'D3_hurwicz_{theta:g}'
        out[name] = D.hurwicz(list(values.values()), theta)
        diagnostics[name] = dict(expanded=any(d['expanded'] for d in details.values()),
                                 ceiling=min(d['ceiling'] for i, d in details.items() if not np.isfinite(values[i]))
                                 if any(not np.isfinite(v) for v in values.values()) else max(d['ceiling'] for d in details.values()),
                                 resolved=bool(np.isfinite(out[name])),
                                 relative_refinement_change=max(d['relative_refinement_change'] for d in details.values()))
    return out, diagnostics


def wilson(successes, n, z=1.959963984540054):
    """Wilson interval for Monte Carlo proportions (not model uncertainty)."""
    if n < 1 or not 0 <= successes <= n:
        raise ValueError("invalid binomial sample")
    p = successes / n
    den = 1 + z*z/n
    centre = (p + z*z/(2*n)) / den
    half = z * np.sqrt(p*(1-p)/n + z*z/(4*n*n)) / den
    return (0. if successes == 0 else max(0., centre-half),
            1. if successes == n else min(1., centre+half))
