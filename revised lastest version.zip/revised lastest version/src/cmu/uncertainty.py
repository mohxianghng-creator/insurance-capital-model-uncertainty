"""Data/parameter uncertainty (bootstrap) and model uncertainty (between-model spread).

Definitions used throughout (see paper Sec. 3):
  * parameter/data uncertainty : sampling variability of a *given* model's capital figure
      -> nonparametric bootstrap of claims (iid resampling) + parametric Poisson bootstrap of annual counts
  * model uncertainty          : spread of capital figures across competing structures (severity x frequency)
  * scenario uncertainty       : stress shifts to frequency/severity not present in history (stress.py)
  * data uncertainty (quality) : reporting threshold, price basis, 11 years only (data card; not modelled numerically)
"""
from __future__ import annotations
import numpy as np
from . import aggregate as A
from . import frequency as F
from .config import ALPHA_VAR, ALPHA_TVAR


class _PredictiveAverage:
    """Streaming mixture: O(grid size) memory instead of O(B * grid size)."""
    def __init__(self):
        self.n = 0
        self.g = None
        self.mean = self.mean_grid = 0.0

    def add(self, d):
        if self.g is None:
            self.g = d.g.copy()
        else:
            self.g += d.g
        self.mean += d.mean_S
        self.mean_grid += d.mean_S_grid
        self.n += 1

    def finish(self):
        if not self.n:
            raise RuntimeError("no successful draws for predictive mixture")
        d = A.AggDist(self.g / self.n, 1.0, 0.0)
        d.mean_S, d.mean_S_grid = self.mean / self.n, self.mean_grid / self.n
        return d


def capital_quantiles(values, probs=(0.05, 0.5, 0.95)):
    """Empirical quantiles retaining +inf (unresolved beyond the grid).

    Inverse empirical CDF avoids interpolating infinity and never conditions on
    a successful finite estimate. NaNs and empty draws indicate a failed run.
    """
    v = np.asarray(values, float)
    p = np.asarray(probs, float)
    if v.ndim != 1 or not len(v) or np.isnan(v).any() or (v < 0).any():
        raise ValueError("capital draws must be nonempty, nonnegative and non-NaN")
    if not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
        raise ValueError("probabilities must lie in [0,1]")
    return np.quantile(v, p, method="inverted_cdf")


def fit_all(models, x):
    """Fit each model on x; return list of fitted clones (models that cannot be fitted are skipped)."""
    out = []
    for m in models:
        mm = m.clone()
        try:
            out.append(mm.fit(x))
        except ValueError:
            continue
    return out


def point_estimate(sev, lam, alpha=ALPHA_VAR):
    d = A.aggregate(sev.cdf, lam)
    return d, d.var(alpha)


def bootstrap_capital(sev_proto, x, counts, freq_name, B, rng, alpha=ALPHA_VAR, keep_dists=False, keep_specs=False):
    """B bootstrap refits of (severity, frequency). Returns dict with VaR draws and (optionally) the AggDists.
    Predictive distribution with parameter uncertainty = equal-weight mixture of the B bootstrap-fitted
    aggregate distributions (a bootstrap analogue of the Bayesian posterior predictive)."""
    x = np.asarray(x, float); n = len(x)
    if B < 1 or n == 0:
        raise ValueError("B and sample size must be positive")
    f0 = F.make(freq_name).fit(counts)
    vars_, lams, params, specs = [], [], [], []
    predictive = _PredictiveAverage()
    for _ in range(B):
        xb = x[rng.integers(0, n, n)]
        try:
            sb = sev_proto.clone().fit(xb)
        except ValueError:
            continue
        cb = f0.simulate_counts(rng)
        fb = F.make(freq_name).fit(cb)
        lam_b = fb.forecast(1)
        d = A.aggregate(sb.cdf, lam_b, r=fb.r)
        vars_.append(d.var(alpha)); lams.append(lam_b); params.append(sb.params())
        if keep_specs:
            specs.append((sb, lam_b, fb.r))
        if keep_dists:
            predictive.add(d)
    if len(vars_) < max(1, int(np.ceil(0.9 * B))):
        raise RuntimeError(f"only {len(vars_)}/{B} bootstrap refits succeeded")
    out = {"var": np.array(vars_), "lam": np.array(lams), "params": params,
           "n_requested": B, "n_success": len(vars_), "n_failed": B - len(vars_)}
    if keep_dists:
        out["mixture"] = predictive.finish()
    if keep_specs:
        out["specs"] = specs
    return out


def decompose(point_vars: dict, boot_vars: dict) -> dict:
    """Variance-style decomposition on log-VaR (finite values only).
    between-model: variance of point estimates across models; within-model: mean bootstrap variance."""
    names = [k for k in point_vars if np.isfinite(point_vars[k])]
    lp = np.log([point_vars[k] for k in names])
    between = float(np.var(lp, ddof=1)) if len(lp) > 1 else float("nan")
    within = float(np.mean([np.var(np.log(boot_vars[k][np.isfinite(boot_vars[k])]), ddof=1) for k in names]))
    return {"between_model_var_logVaR": between, "mean_within_model_var_logVaR": within,
            "share_model": between / (between + within), "models": names,
            "range_ratio_max_min": float(np.max(np.exp(lp)) / np.min(np.exp(lp)))}


# ----------------------------------------------------------------------------------------------
def _gpd_posterior_draws(y, n_draws, rng, xi_max=2.0, ng=110, diagnostics=None):
    """Grid posterior for GPD(xi, beta) given excesses y. Prior: xi ~ U(0, xi_max), log(beta) flat (scale-invariant).
    Finite quadrature support: xi in [0.002, xi_max], log beta within +/-3 of log mean excess.
    This data-dependent support is an empirical restriction, not an unbounded flat prior.
    Returns arrays (xi, beta). Grid resolution and prior support need sensitivity checks."""
    y = np.asarray(y, float); ybar = y.mean()
    if not np.isfinite(y).all() or (y < 0).any() or ybar <= 0 or ng < 3 or xi_max <= .002 or n_draws < 1:
        raise ValueError("invalid GPD posterior sample, grid or draw count")
    xi_g = np.linspace(2e-3, xi_max, ng)
    lb_g = np.log(ybar) + np.linspace(-3.0, 3.0, ng)
    XI, LB = np.meshgrid(xi_g, lb_g, indexing="ij")
    beta = np.exp(LB)
    ll = np.empty_like(XI)
    chunk = max(1, int(2e6 // max(len(y), 1)))
    flat_xi, flat_b = XI.ravel(), beta.ravel()
    out = np.empty(flat_xi.size)
    for i in range(0, flat_xi.size, chunk):
        xs, bs = flat_xi[i:i + chunk, None], flat_b[i:i + chunk, None]
        out[i:i + chunk] = -len(y) * np.log(bs[:, 0]) - (1 + 1 / xs[:, 0]) * np.log1p(xs * y[None, :] / bs).sum(axis=1)
    out -= out.max()
    w = np.exp(out); w /= w.sum()
    if diagnostics is not None:
        surface = w.reshape(XI.shape)
        diagnostics.update(xi_max=float(xi_max), ng=int(ng),
                           xi_upper_edge_mass=float(surface[-1].sum()),
                           xi_lower_edge_mass=float(surface[0].sum()),
                           beta_edge_mass=float(surface[:, [0, -1]].sum()),
                           log_beta_support=[float(lb_g[0]), float(lb_g[-1])])
    idx = rng.choice(w.size, size=n_draws, p=w)
    dxi, dlb = xi_g[1] - xi_g[0], lb_g[1] - lb_g[0]
    xi = np.clip(flat_xi[idx] + rng.uniform(-.5, .5, n_draws) * dxi, 1e-4, xi_max)
    b = np.exp(np.log(flat_b[idx]) + rng.uniform(-.5, .5, n_draws) * dlb)
    return xi, b


def posterior_capital(sev_proto, x, counts, freq_name, B, rng, alpha=ALPHA_VAR, xi_max=2.0, ng=110):
    """Semi-Bayesian parameter uncertainty (repairs the bootstrap's boundary failure for GPD tails).
    Tail (xi,beta): grid posterior. Body split probability: Beta(n_b+.5, n_t+.5). Spliced body (mu,sigma): nonparametric
    bootstrap of the body sample (body does not drive the tail capital). Lomax: tail only. Frequency: as bootstrap.
    Models without a GPD tail (LN) fall back to the bootstrap. Returns the same dict layout as bootstrap_capital."""
    from . import severity as S
    if not sev_proto.has_gpd_tail:
        return bootstrap_capital(sev_proto, x, counts, freq_name, B, rng, alpha, keep_dists=True)
    x = np.asarray(x, float)
    f0 = F.make(freq_name).fit(counts)
    is_sp = isinstance(sev_proto, S.Spliced)
    posterior_grid = {}
    if is_sp:
        base = sev_proto.clone().fit(x); u = base.u
        body, tail = x[x < u], x[x >= u] - u
        xi_d, b_d = _gpd_posterior_draws(tail, B, rng, xi_max=xi_max, ng=ng, diagnostics=posterior_grid)
        p_d = rng.beta(len(body) + .5, len(tail) + .5, B)
    else:
        xi_d, b_d = _gpd_posterior_draws(x - S.LOWER, B, rng, xi_max=xi_max, ng=ng, diagnostics=posterior_grid)
    if B < 1:
        raise ValueError("B must be positive")
    vars_, params = [], []
    predictive = _PredictiveAverage()
    for i in range(B):
        if is_sp:
            bb = body[rng.integers(0, len(body), len(body))]
            try:
                mu, sg = S.fit_trunc_ln(bb, S.LOWER, u)
            except Exception:
                continue
            m = S.Spliced(u, mu, sg, float(p_d[i]), float(xi_d[i]), float(b_d[i]))
        else:
            m = S.Lomax(float(xi_d[i]), float(b_d[i]))
        fb = F.make(freq_name).fit(f0.simulate_counts(rng))
        d = A.aggregate(m.cdf, fb.forecast(1), r=fb.r)
        vars_.append(d.var(alpha)); predictive.add(d); params.append(m.params())
    if len(vars_) < max(1, int(np.ceil(.9 * B))):
        raise RuntimeError(f"only {len(vars_)}/{B} posterior draws succeeded")
    return {"var": np.array(vars_), "params": params, "mixture": predictive.finish(),
            "n_requested": B, "n_success": len(vars_), "n_failed": B - len(vars_), "posterior_grid": posterior_grid}
