"""cmu: Capital management under model uncertainty and reverse stress testing."""
__version__ = "0.1.0"
