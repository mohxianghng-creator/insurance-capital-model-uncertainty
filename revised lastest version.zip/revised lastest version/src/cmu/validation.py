"""Out-of-sample validation + honest power analysis for rare-event backtests."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy import stats
from . import severity as S, aggregate as A, frequency as F
from .config import ALPHA_VAR


def annual_counts(df, years):
    c = df.groupby("year").size().reindex(years, fill_value=0)
    return c.to_numpy()


def rolling_origin(df, first_origin=1984, last_origin=1989, censor_u=10.0, models=None):
    """Expanding-window one-year-ahead evaluation. Origin t: fit on years<=t, evaluate on year t+1."""
    models = models or S.default_model_set()
    rows = []
    for t in range(first_origin, last_origin + 1):
        tr = df[df.year <= t]; te = df[df.year == t + 1]
        yrs = list(range(df.year.min(), t + 1))
        counts = annual_counts(tr, yrs)
        s_real = float(te.loss.sum())
        xtr, xte = tr.loss.to_numpy(), te.loss.to_numpy()
        for proto in models:
            try:
                m = proto.clone().fit(xtr)
            except ValueError:
                continue
            ll = m.loglik(xte)
            with np.errstate(divide="ignore"):
                cens = np.where(xte >= censor_u, m.logpdf(xte), np.log(np.maximum(m.cdf(np.array([censor_u]))[0], 1e-300)))
            q99, q999 = float(m.ppf(0.99)), float(m.ppf(0.999))
            for fname in F.FREQ_NAMES:
                fr = F.make(fname).fit(counts); lam = fr.forecast(1)
                d = A.aggregate(m.cdf, lam, r=fr.r)
                v = d.var(ALPHA_VAR)
                rows.append(dict(origin=t, test_year=t + 1, severity=m.name, freq=fname, lam=lam, n_test=len(xte),
                                 aic_train=m.aic(xtr), logscore=ll, censored_logscore=float(np.sum(cens)),
                                 exceed_q99=int((xte > q99).sum()), exceed_q999=int((xte > q999).sum()),
                                 V995=v, realised_S=s_real, breach=bool(s_real > v), pit_S=float(d.cdf_at(s_real)),
                                 mean_S_pred=d.mean_S))
    return pd.DataFrame(rows)


def kupiec_pof(n, x, p):
    """Kupiec proportion-of-failures LR test: H0 exceedance prob = p. Returns (LR, p-value)."""
    if x == 0:
        lr = -2 * n * np.log(1 - p)
    elif x == n:
        lr = -2 * n * np.log(p)
    else:
        ph = x / n
        lr = -2 * ((n - x) * np.log(1 - p) + x * np.log(p) - (n - x) * np.log(1 - ph) - x * np.log(ph))
    return float(lr), float(stats.chi2.sf(lr, 1))


def breach_test_power(n_years, p_nominal=1 - ALPHA_VAR, p_true_grid=(0.01, 0.02, 0.05, 0.10, 0.20), size=0.05):
    """Power of the exact one-sided binomial test of H0: breach prob = p_nominal using n_years annual outcomes."""
    ks = np.arange(0, n_years + 1)
    tail = stats.binom.sf(ks - 1, n_years, p_nominal)          # P(X>=k | H0)
    kstar = int(ks[np.argmax(tail <= size)]) if np.any(tail <= size) else n_years + 1
    actual_size = float(stats.binom.sf(kstar - 1, n_years, p_nominal)) if kstar <= n_years else 0.0
    rows = [dict(n_years=n_years, p_true=p, reject_if_breaches_ge=kstar, actual_size=actual_size,
                 power=float(stats.binom.sf(kstar - 1, n_years, p)) if kstar <= n_years else 0.0) for p in p_true_grid]
    return pd.DataFrame(rows)


def years_needed_for_power(p_true, p_nominal=1 - ALPHA_VAR, power=0.8, size=0.05, max_years=5000):
    for n in range(1, max_years):
        ks = np.arange(0, n + 1)
        tail = stats.binom.sf(ks - 1, n, p_nominal)
        if not np.any(tail <= size):
            continue
        k = int(ks[np.argmax(tail <= size)])
        if stats.binom.sf(k - 1, n, p_true) >= power:
            return n
    return None
