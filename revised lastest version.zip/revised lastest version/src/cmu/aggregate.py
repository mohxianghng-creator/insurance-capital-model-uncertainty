"""Compound-Poisson aggregate loss via FFT (deterministic: no Monte-Carlo noise).

S = sum_{i=1..N} X_i,  N~Poisson(lam), X_i iid severity. Characteristic-function identity
phi_S = exp(lam (phi_X - 1)). Severity is discretised on a grid of step H (cell j = [(j-1/2)H,(j+1/2)H),
mass placed at j*H). Mass beyond the per-claim cap CAP is *not* wrapped around: it is carried as
'overflow' (any claim >= CAP). The sub-distribution g = P(S=jH, no overflow claim) therefore sums to
exp(-lam * P(X>=(NX-.5)*H)) in the infinite aggregate lattice. VaR_alpha is
reported as +inf if not resolved below CAP. This is right-censoring by a
numerical ceiling, not a statement that the true quantile is infinite.
Exponential tilting suppresses circular aliasing (tilt=16 by default; tilt=0
reproduces the historical engine). Grid and ceiling sensitivity still matter.
For supported severity objects mean_S is the uncapped analytic/integrated mean;
mean_S_grid retains the finite lattice first moment for diagnosis.
"""
from __future__ import annotations
import numpy as np
from .config import H, NX, NS, CAP

_X = np.arange(NS) * H


def set_grid(h: float = H, nx: int = NX, ns: int = NS):
    """Re-configure the aggregation grid (e.g. for data with a much larger scale). Returns the new per-claim cap.
    Existing AggDist instances retain their own grid. Mixtures require a common active grid."""
    global H, NX, NS, CAP, _X
    if not np.isfinite(h) or h <= 0 or int(nx) != nx or int(ns) != ns or nx < 2 or ns < nx:
        raise ValueError("require h>0 and integer ns>=nx>=2")
    H, NX, NS = float(h), int(nx), int(ns)
    CAP = NX * H
    _X = np.arange(NS) * H
    return CAP


def severity_pmf(cdf_fn, scale: float = 1.0):
    """Discretised severity pmf on cells 0..NX-1 (unnormalised: sums to 1 - overflow)."""
    edges = (np.arange(NX + 1) - 0.5) * H
    edges[0] = 0.0
    c = cdf_fn(edges / scale)
    c[0] = 0.0
    return np.diff(c)  # length NX


def retained_pmf(cdf_fn, retention: float, scale: float = 1.0):
    """pmf of min(X, R) for an unlimited per-claim excess-of-loss with retention R (R<CAP)."""
    if not np.isfinite(retention) or not 0 <= retention < (NX - 0.5) * H:
        raise ValueError("retention must be nonnegative and below the severity grid ceiling")
    if not np.isclose(retention / H, round(retention / H)):
        raise ValueError("retention must be an exact multiple of the grid step")
    pmf = severity_pmf(cdf_fn, scale)
    jR = int(round(retention / H))
    kept = pmf[:jR].copy()
    out = np.zeros(NX)
    out[:jR] = kept
    # all mass of X >= R-ish sits at R. Includes overflow mass -> nothing overflows after retention
    out[jR] = 1.0 - kept.sum()
    return out


class AggDist:
    """Sub-distribution of S on the grid, plus helpers. Mixtures are formed by `mix`."""

    def __init__(self, g: np.ndarray, lam_mean: float, sev_mean: float):
        self.g = g
        self.h, self.nx, self.ns, self.cap = H, NX, NS, CAP
        self.mean_S = lam_mean * sev_mean
        self.mean_S_grid = self.mean_S  # severity-tail-deleted lattice first moment
        self.cum = np.cumsum(g)

    @property
    def overflow_prob(self):
        return float(max(0.0, 1.0 - self.g.sum()))

    def cdf_at(self, x):
        x = np.asarray(x, float)
        if np.isnan(x).any():
            raise ValueError("CDF argument cannot be NaN")
        j = np.floor(np.clip(x / self.h + 1e-9, 0, self.ns - 1)).astype(int)
        out = self.cum[j]
        # At finite x>=cap this is only a lower bound: overflow claims are absent.
        return np.where(x < 0, 0.0, np.where(np.isposinf(x), 1.0, np.minimum(out, 1.0)))

    def var(self, alpha):
        """Smallest grid point with cdf >= alpha; inf if not reached below CAP."""
        if not 0 < alpha < 1:
            raise ValueError("alpha must lie strictly between zero and one")
        j = int(np.searchsorted(self.cum[: self.nx], alpha, side="left"))
        if j >= self.nx:
            return float("inf")
        return j * self.h

    def tvar(self, alpha):
        """TVaR_alpha = VaR + E[(S-VaR)+]/(1-alpha). Returns (value, reliable_flag)."""
        q = self.var(alpha)
        if not np.isfinite(q):
            return float("inf"), False
        if not np.isfinite(self.mean_S):
            return float("inf"), False
        j = int(round(q / self.h))
        grid = np.arange(self.ns) * self.h
        ex = float(np.sum((grid[j + 1:] - q) * self.g[j + 1:]))
        val = q + ex / (1 - alpha)
        ov = self.overflow_prob
        # overflow claims >= CAP add at least (CAP-q)*ov, so TVaR is a lower bound; flag if material
        # A small missing probability does not bound its first moment.
        reliable = ov < 1e-12
        return val + ((self.cap - q) * ov / (1 - alpha)), reliable

    def breach_prob(self, v):
        return float(1.0 - self.cdf_at(v))


def compound_poisson(pmf: np.ndarray, lam: float, r: float | None = None, tilt: float = 16.0) -> np.ndarray:
    """Compound distribution; Poisson(lam) if r is None else NegBin(mean=lam, dispersion r): PGF (1+lam/r(1-z))^-r."""
    f = np.zeros(NS)
    if not np.isfinite(lam) or lam < 0 or (r is not None and (not np.isfinite(r) or r <= 0)):
        raise ValueError("require finite lam>=0 and finite r>0")
    if not np.isfinite(tilt) or not 0 <= tilt <= 20:
        raise ValueError("tilt must lie in [0,20]")
    f[:NX] = pmf
    damping = np.exp(-tilt * np.arange(NS) / NS)
    f *= damping
    phi = np.fft.rfft(f)
    if r is None or r > 1e5:
        pgf = np.exp(lam * (phi - 1.0))
    else:
        pgf = np.exp(-r * np.log(1.0 + (lam / r) * (1.0 - phi)))
    g = np.fft.irfft(pgf, n=NS)
    return np.maximum(g / damping, 0.0)  # tilt suppresses circular aliasing; zero preserves published runs


def aggregate(cdf_fn, lam: float, scale: float = 1.0, retention: float | None = None, r: float | None = None, tilt: float = 16.0) -> AggDist:
    if not np.isfinite(scale) or scale <= 0:
        raise ValueError("scale must be finite and positive")
    pmf = severity_pmf(cdf_fn, scale) if retention is None else retained_pmf(cdf_fn, retention, scale)
    mean_x = float(np.sum(np.arange(NX) * H * pmf))
    d = AggDist(compound_poisson(pmf, lam, r, tilt), lam, mean_x)
    owner = getattr(cdf_fn, "__self__", None)
    if owner is not None and hasattr(owner, "stop_loss"):
        mean = scale * owner.stop_loss(0.0)
        if retention is not None:
            # Integrate only the bounded layer; avoids inf-inf for xi>=1.
            from scipy.integrate import quad
            mean = quad(lambda t: float(1 - cdf_fn(np.array([t / scale]))[0]),
                        0, retention, points=[p for p in (scale, getattr(owner, "u", 0) * scale) if 0 < p < retention],
                        epsabs=1e-8)[0]
        d.mean_S = lam * mean
    return d


def mix(dists: list[AggDist], w=None) -> AggDist:
    k = len(dists)
    if not k:
        raise ValueError("cannot mix an empty distribution list")
    w = np.ones(k) if w is None else np.asarray(w, float)
    if w.shape != (k,) or not np.isfinite(w).all() or (w < 0).any() or w.sum() <= 0:
        raise ValueError("weights must be finite, nonnegative, match distributions and have positive sum")
    grids = {(d.h, d.nx, d.ns) for d in dists}
    if len(grids) != 1 or next(iter(grids)) != (H, NX, NS):
        raise ValueError("mixtures must use the active, common grid")
    w = w / w.sum()
    g = sum(wi * d.g for wi, d in zip(w, dists))
    out = AggDist(g, 1.0, 0.0)
    out.mean_S = float(sum(wi * d.mean_S for wi, d in zip(w, dists) if wi > 0))
    out.mean_S_grid = float(sum(wi * d.mean_S_grid for wi, d in zip(w, dists) if wi > 0))
    return out


def expected_recovery_per_claim(cdf_fn, retention: float, scale: float = 1.0) -> float:
    """Uncapped E[(scale*X-R)+]; infinite if the severity mean is infinite."""
    if not np.isfinite(retention) or retention < 0 or not np.isfinite(scale) or scale <= 0:
        raise ValueError("require finite retention>=0 and scale>0")
    owner = getattr(cdf_fn, "__self__", None)
    if owner is not None and hasattr(owner, "stop_loss"):
        return float(scale * owner.stop_loss(retention / scale))
    from scipy.integrate import quad
    return float(quad(lambda t: float(1 - cdf_fn(np.array([t / scale]))[0]), retention, np.inf, limit=500)[0])
