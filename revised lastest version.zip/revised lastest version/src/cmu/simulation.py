"""SIMULATION STUDY (synthetic data - NOT empirical evidence).
Purpose: because the true capital of a real portfolio is unobservable, decision rules can only be scored against a
known data-generating process (DGP). Worlds are anchored in the fitted Danish parameters for realism but are synthetic.
Each replication: draw T years -> apply each rule -> score against a deterministic
lattice-FFT approximation to the DGP VaR (no MC error, but discretisation error)."""
from __future__ import annotations
import numpy as np
from . import severity as S, aggregate as A, frequency as F, decision as D, uncertainty as U
from .config import ALPHA_VAR, DELTA_AIC_PLAUSIBLE, CAP

THETAS = (0.0, 0.25, 0.5, 0.75, 1.0)


def make_worlds(real_fits: dict, lam: float = 197.0):
    sp = real_fits["Spliced10"]; ln = real_fits["LN"]
    base = lambda xi: S.Spliced(10.0, sp.mu, sp.sigma, sp.p, xi, sp.beta)
    worlds = {
        "W1_LN": dict(truth=S.LN(ln.mu, ln.sigma), oracle=S.LN()),
        "W2_Sp10_xi0.50": dict(truth=base(sp.xi), oracle=S.Spliced(10.0)),
        "W3_Sp10_xi0.80": dict(truth=base(0.80), oracle=S.Spliced(10.0)),
        "W4_TailBreak_v100_xi1.0": dict(truth=S.PiecewiseTail(base(sp.xi), 100.0, 1.0), oracle=None),
        "W5_Sp10_xi0.25": dict(truth=base(0.25), oracle=S.Spliced(10.0)),
    }
    for w in worlds.values():
        w["lam"] = lam
    return worlds


def draw_claims(truth, n, rng):
    return truth.ppf(rng.random(n))


def truth_summary(world):
    d = A.aggregate(world["truth"].cdf, world["lam"])
    v = d.var(ALPHA_VAR)
    if not np.isfinite(v):
        raise ValueError("true capital is unresolved; expand the grid before scoring")
    return d, v


def decide(x, counts, rng, B=30, models=None, delta=DELTA_AIC_PLAUSIBLE, oracle=None):
    """Apply every rule to one training sample. Returns dict rule -> V (float, may be inf)."""
    models = models or S.default_model_set()
    fits = U.fit_all(models, x)
    aics = np.array([m.aic(x) for m in fits])
    dA, wA = D.akaike_weights(aics)
    pl = D.plausible_mask(aics, delta)
    lam = float(np.mean(counts))
    plug = np.array([A.aggregate(m.cdf, lam).var(ALPHA_VAR) for m in fits])
    best = int(np.argmin(aics))
    out = {"D0_aic_plugin": plug[best]}
    fin = np.isfinite(plug)
    # bootstrap predictive distribution for every plausible model
    Vm, mixes = {}, {}
    for i, m in enumerate(fits):
        if not pl[i]:
            continue
        bt = U.bootstrap_capital(m, x, counts, "PoissonConst", B, rng, keep_dists=True)
        mixes[i] = bt["mixture"]; Vm[i] = bt["mixture"].var(ALPHA_VAR)
    idx = sorted(mixes)
    # D1: BMA-style: Akaike-weighted mixture of the bootstrap-predictive distributions (weights renormalised on plausible set)
    out["D1_bma_mixture"] = A.mix([mixes[i] for i in idx], wA[idx]).var(ALPHA_VAR)
    out["D2_aic_bootpred"] = Vm[best]
    vs = np.array(list(Vm.values()))
    for th in THETAS:
        out[f"D3_hurwicz_{th:g}"] = D.hurwicz(vs, th)
    # sensitivity of the plausible-set convention: D3(theta=0.5) with tighter dAIC cut-offs (subsets of the bootstrapped set)
    for cut in (2.0, 4.0):
        sub = [Vm[i] for i in idx if dA[i] <= cut]
        v2 = np.array(sub)
        out[f"D3_hurwicz_0.5_dAIC{cut:g}"] = float(0.5 * v2.max() + 0.5 * v2.min()) if np.isfinite(v2).all() else np.inf
    if oracle is not None:
        o = oracle.clone().fit(x)
        out["Dorc_true_family"] = A.aggregate(o.cdf, lam).var(ALPHA_VAR)
    out["_n_plausible"] = int(pl.sum()); out["_best"] = fits[best].name
    return out


def score(v, d_true: A.AggDist, v_true: float):
    """Scores and bounds. +inf means unresolved above the numerical ceiling.

    For a censored output rel_over is a LOWER bound and rel_over_upper is
    unbounded; its actual breach probability is unknown. Never rank its lower
    bound against another rule's exact loss as if they were comparable.
    """
    if np.isnan(v) or v < 0 or not np.isfinite(v_true) or not 0 < v_true < d_true.cap:
        raise ValueError("require nonnegative capital and a resolved positive truth")
    capped = bool(v >= d_true.cap)
    lower = min(v, d_true.cap)
    over = max(lower - v_true, 0.0) / v_true
    return dict(rel_under=max(v_true - lower, 0.0) / v_true, rel_over=over,
                rel_over_upper=(np.inf if capped else over),
                p_breach=(np.nan if capped else d_true.breach_prob(v)),
                p_breach_upper=d_true.breach_prob(lower),
                shortfall=bool(lower < v_true), capped=capped)


def decide_post(x, counts, rng, B=40, models=None, delta=DELTA_AIC_PLAUSIBLE):
    """Rules built on the semi-Bayesian posterior predictive (uncertainty.posterior_capital).
    D1_post: Akaike-weighted mixture of posterior predictives over the plausible set; D2_post: AIC-best posterior predictive;
    D3post_*: Hurwicz over the plausible models' posterior-predictive V."""
    models = models or S.default_model_set()
    fits = U.fit_all(models, x); aics = np.array([m.aic(x) for m in fits])
    dA, wA = D.akaike_weights(aics); pl = D.plausible_mask(aics, delta); best = int(np.argmin(aics))
    mixes, Vm = {}, {}
    for i, m in enumerate(fits):
        if pl[i]:
            o = U.posterior_capital(m, x, counts, "PoissonConst", B, rng)
            mixes[i] = o["mixture"]; Vm[i] = o["mixture"].var(ALPHA_VAR)
    idx = sorted(mixes)
    out = {"D1_post_mixture": A.mix([mixes[i] for i in idx], wA[idx]).var(ALPHA_VAR), "D2_post_aicbest": Vm[best]}
    vs = np.array([Vm[i] for i in idx])
    for th in (0.0, 0.5):
        out[f"D3post_{th:g}"] = D.hurwicz(vs, th)
    out["_n_plausible"] = int(pl.sum()); out["_best"] = fits[best].name
    return out
