# Public distribution

Prepared 5 November 2026 from cmu_project5_v3 (package version 0.5.0). The original folder remains unchanged.

Scientific code, scripts, tests, raw datasets, processed observations and numerical evidence are retained without changing their bytes. Documentation is edited for publication, data attribution is included and a distribution-specific inventory records the files. Local environments, development files, logs and caches are excluded.

Historical simulation files remain because the paper, provenance checks and regeneration pipeline refer to them. They must not be relabelled as fresh current-engine evidence. Independent review, production operation and extreme-tail calibration are not established by this distribution.

Original-package verification passed 98 tests, 26 empirical checks, 45 current-evidence checks and all 139 original inventory hashes. The large nested study and optional browser audit were not rerun in this packaging review. Public-package verification is run separately after the new inventory is written. No remote CI pass is claimed.

Suggested GitHub repository name: `when-risk-models-disagree`.
