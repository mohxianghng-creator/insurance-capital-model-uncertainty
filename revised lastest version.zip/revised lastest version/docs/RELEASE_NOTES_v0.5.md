# Version 0.5: evidence and decision-quality improvements

This release strengthens the validation and delivery of the case study. It
claims reproducible implementation and transparent decision comparisons.

| Earlier limitation | Current evidence or change |
|---|---|
| Main simulations predated numerical safeguards | Fresh five-world decision experiment: 150 samples/world at T=11 and T=40, B=80 |
| T=40 used 30 samples/world | 150 samples/world, with pointwise Monte Carlo intervals |
| Revised interval coverage had not been measured | 200 samples/world in W2/W3/W5, two methods, B=200; coverage, width and censored endpoints reported together |
| Some decision costs were unidentified at the 16,384 ceiling | Predictive quantiles expand up to 2,097,152, with halved-step checks; all tested decision-rule capitals resolve, while coverage-study parameter endpoints can remain censored |
| Inner refit precision was unclear | Paired B=80/B=240 diagnostic and post-analysis B=960 follow-up on fixed W1/W4 samples |
| Reinsurance comparison used unlimited cover | Seven finite layers plus no cover, common feasibility constraints, hypothetical quotes, funding costs and quotation-change boundaries |
| Norwegian over-prediction was largely descriptive | Largest-claim and recent-window diagnostics, with severity and frequency changes separated |
| Derivative-free fitting dominated nested computation | Checked analytic-score optimization with a fallback and independent likelihood comparisons |
| Reviewer entry points were fragmented | Offline evidence report, updated explorer, business memo, model card and validation criteria |

## Calibration and precision findings

Nominal-90% bootstrap coverage is **85.5%, 83.5% and 89.5%** in W2/W3/W5.
Semi-Bayesian coverage is **90.0%, 90.0% and 92.5%**, but W3 has **66%** of upper
endpoints beyond the base numerical ceiling. The coverage event remains
identified because the known true quantile is below that ceiling; interval
width remains partially identified.

The B=960 follow-up confirms that inner precision needs attention. For D1 in
W1, median relative changes are **2.9% from B=80 to B=960** and **4.6% from B=240
to B=960**, while the largest B=240-to-B=960 change is **114.4%**. These twelve
selected samples do not establish uniform convergence. Main B=80 cost
comparisons remain exploratory; the higher-budget runs do not replace selected
rows in the main study.

Finite-layer action comparisons use deterministic fitted distributions and a
separate annual-cost objective. They can produce no cover or no feasible action.
The decision memo gives quotation and funding boundaries rather than a generic
instruction to add capital or buy insurance.

## Provenance and review

Current numerical evidence is under `results/current/`. Historical simulation
and review files retain their status. An exact, accepted-case cache migration
for an added failure guard has explicit source-delta and result provenance.
Automatic Git newline conversion is disabled to preserve byte inventories
across operating systems. Direct and transitive Python dependencies are pinned.

Run `python scripts/reproduce.py verify` for the Python tests and evidence
checks. Optional `node scripts/check_browser.cjs` checks displayed costs against
raw samples, all 54 treaty scenarios, browser errors, mobile overflow and
automated accessibility findings; setup is in `docs/VALIDATION.md`.

The remaining evidence boundary includes public same-peril data, missing
exposure and balance-sheet information, iid claim bootstrap, Poisson synthetic
frequency, assumed prices and decision costs, and the absence of independent
institutional validation.
