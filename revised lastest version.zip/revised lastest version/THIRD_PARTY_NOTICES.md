# Third-party data attribution

Project code and narrative do not claim ownership of the following datasets. Their upstream package licences and attribution remain applicable; the publication terms for project-authored files do not override them.

## Danish fire claims

`data/raw/danish.rda` is copied unchanged from the evir R package's `danish` dataset. `data/processed/danish_fire_losses.csv` is the project's tabular conversion, not an independent new dataset. The source has 2,167 losses; the price basis remains undocumented in the package help.

Source: https://github.com/cran/evir/blob/master/data/danish.rda

Package evir 1.7-4, licence GPL (>=2): https://www.stat.ethz.ch/CRAN/web/packages/evir/index.html

Package authors: Bernhard Pfaff and Alexander McNeil, with Eric Zivot and Alec Stephenson credited upstream. Dataset supplied by Mette Rytgaard (Copenhagen Re), as attributed in the package documentation. Original file MD5: `9defcdbc269e50aa95a1a9e7d36d1c68`.

## Norwegian fire claims

`data/raw/norfire.rda` is copied unchanged from CASdatasets `norfire`. The upstream dataset contains 9,181 records; this study uses 5,433 records from 1985–1992 and nominal threshold units, as documented in the data card.

Source: https://github.com/dutangc/CASdatasets/blob/master/data/norfire.rda

CASdatasets 1.2-1, licence GPL (>=2): https://github.com/dutangc/CASdatasets/blob/master/DESCRIPTION

Package authors: Christophe Dutang and Arthur Charpentier; additional contributors are credited upstream. Original data source and reference: Beirlant, Teugels and Vynckier (1996), as recorded in `src/cmu/data_norfire.py`. Original file MD5: `d79a19ad111bf85ae94a3d5ff746eed5`.

The included `third_party/GPL-3.0.txt` provides the GPL version 3 text, one version permitted by the upstream GPL version 2-or-later declarations. Raw data remains in its supplied editable R data format; conversion/analysis source is supplied in `src/cmu/data.py` and `src/cmu/data_norfire.py`. No additional restriction in this repository applies to rights granted by the upstream licences.
